# This script bootstraps a new region for further provisioning with Terraform. We setup an Azure Resource Group,
# Azure Storage Account and configure Customer-managed encryption using a RSA key stored in a new Keyvault.
# Please consider a dedicated Resource Group for Terraform in a separate Azure Subscription for maximum security.
# This script will fail if any of commands throws an error
# Argument1: Location westeurope
# Argument2: Location short we
# Argument3: environment
# Argument4: environmentShort
# Argument5: dmlz or usecase / projectname
# Argument6: SP name
# Argument7: region

set -e
#Assign Pipeline Variables
location="$1";
locationShort="$2";
environment="$3";
environmentShort="$4";
deploymentType="$5";
devOpsServicePrincipalName="$6";
region="$7";

# Check if all Input Variables contain Values
if [[ "$location" = "" || "$locationShort" = "" || "$environment" = "" || "$environmentShort" = "" || "$deploymentType" = "" || "$devOpsServicePrincipalName" = "" || "$region" = "" ]]
then
    echo "not all required Input Parameters are given"
    exit 1
fi

#Key Vault Secret Names
patchVersionSecretName="patch"
minorVersionSecretName="minor"
majorVersionSecretName="major"
keyVaultNameSecretName="keyVaultName"
backendResourceGroupNameSecretName="backendAzureRmResourceGroupName"
backendStorageAccountNameSecretName="backendAzureRmStorageAccountName"
backendContainerNameSecretName="backendAzureRmContainerName"
backendKeySecretName="backendAzureRmKey"
sqldbUserNameSecretName="sqldbusername"
sqldbPasswordSecretName="sqldbpassword"
hmacKeySecretName="hmacKey"

# Name of the State File
backendKey="$deploymentType-StateFile-$environment"
# Input for Instance ID creation
workload="automation"
hmac_key=$(grep -ao '[A-Za-z0-9!"#$%&]' < /dev/urandom | head -45 | tr -d '\n' ;)
env_short="$deploymentType$environment$RANDOM"
hmac_key_sha="$env_short$workload$hmac_key"
instance_ID=`echo -n $hmac_key_sha | sha256sum | head -c 4`
#Resource Names
resourceGroupName="eva-$environment-$deploymentType-rg-$region-automation"
byokKeyName="eva-$environmentShort-$locationShort-byok"
stateContainerName="eva-$environmentShort-$locationShort-$deploymentType-state-container"
keyVaultName="eva-$environmentShort-$locationShort-$deploymentType-kv-tf-$instance_ID"
storageAccountName="eva${environment}${deploymentType}sttf$instance_ID"
echo $resourceGroupName
echo $keyVaultName
echo $storageAccountName
# Resource Tags
tags="costcenter=820100 environment=$environment businessowner=zdp technicalcontact=markus.morgner@zeiss.com;reiner.rottmann@zeiss.com;jan-michael.matzkovits@zeiss.com project=eva provisioner=bashscript region=$location workload=$workload support=markus.morgner@zeiss.com;reiner.rottmann@zeiss.com;jan-michael.matzkovits@zeiss.com businessgroup=all"
resourceGroupDescriptionTag="This Resource Group contains Resources for Automation as well as the Terraform Deployment"
storageAccountDescriptionTag="This Storage Account stores the Statefile for Terraform Deployments in this Subscription"
keyVaultDescriptionTag="This Key Vault stores they Key to encrypt the Storage Account and other Secrets for the Terraform Deployment"

# Creating Azure Resource Group
az group create --location $location --resource-group $resourceGroupName --tags $tags description="$resourceGroupDescriptionTag"
# Creating Keyvault for BYOK and Variable Group for Deployment
if [[ $(az keyvault list --resource-group $resourceGroupName --query "[?name=='$keyVaultName'] | length(@)") = 0 ]] 
then
    az keyvault create --name $keyVaultName --location $location --resource-group $resourceGroupName --tags $tags description="$keyVaultDescriptionTag" --enable-purge-protection
fi
# Creating Key for Customer-managed encryption
az keyvault key create --name $byokKeyName --protection software --size 3072 --vault-name $keyVaultName
# Grant DevOps Service Connection Principal access to Get The Secrets

# devOpsServicePrincipalId=$(az ad sp list --display-name $devOpsServicePrincipalName --query [0].objectId --output tsv )
# echo $devOpsServicePrincipalId
# az keyvault set-policy --name $keyVaultName --resource-group $resourceGroupName --object-id $devOpsServicePrincipalId --secret-permissions get list set

# Creating Azure Storage Account with assigned Idenity
az storage account create --name $storageAccountName --location $location --resource-group $resourceGroupName --allow-blob-public-access --sku Standard_GRS --kind StorageV2 --assign-identity --tags $tags description="$storageAccountDescriptionTag"
# Grant access to Keyvault using Managed Identity of Azure Storage Account
storage_account_principal=$(az storage account show --name $storageAccountName --resource-group $resourceGroupName --query identity.principalId --output tsv )
az keyvault set-policy --name $keyVaultName --resource-group $resourceGroupName --object-id $storage_account_principal --key-permissions get unwrapKey wrapKey
key_vault_uri=$(az keyvault show --name $keyVaultName --resource-group $resourceGroupName --query properties.vaultUri --output tsv )
# Updating Storage Account to use Customer-managed keys
key_version=$(az keyvault key list-versions --name $byokKeyName --vault-name $keyVaultName --query [-1].kid --output tsv | cut -d '/' -f 6 )
az storage account update --name $storageAccountName --resource-group $resourceGroupName --encryption-key-name $byokKeyName --encryption-key-version $key_version --encryption-key-source Microsoft.Keyvault --encryption-key-vault $key_vault_uri
# Creating Storage Container tfstate in Azure Storage Account
sleep 30;az storage container create --name $stateContainerName --account-name $storageAccountName --auth-mode login --public-access off --resource-group $resourceGroupName

#Create Secrets for Verion Control
az keyvault secret set --name $patchVersionSecretName --vault-name $keyVaultName --value 0 --description "Contains Information about the Versioning of the Terraform Deployment"
az keyvault secret set --name $minorVersionSecretName --vault-name $keyVaultName --value 0 --description "Contains Information about the Versioning of the Terraform Deployment"
az keyvault secret set --name $majorVersionSecretName --vault-name $keyVaultName --value 0 --description "Contains Information about the Versioning of the Terraform Deployment"
az keyvault secret set --name $keyVaultNameSecretName --vault-name $keyVaultName --value $keyVaultName --description "Contains the KeyVault Name for the Versioning of the Terraform Deployment"
#Create Secrets for TF Deployment
az keyvault secret set --name $backendStorageAccountNameSecretName --vault-name $keyVaultName --value $storageAccountName --description "Contains the Storage Account for Terraform Deployments"
az keyvault secret set --name $backendContainerNameSecretName --vault-name $keyVaultName --value $stateContainerName --description "Contains the Backend Container for Terraform Deployments"
az keyvault secret set --name $backendKeySecretName --vault-name $keyVaultName --value $backendKey --description "Contains the State File for Terraform Deployments"
az keyvault secret set --name $backendResourceGroupNameSecretName --vault-name $keyVaultName --value $resourceGroupName --description "Contains the Resource Group for Terraform Deployments"
az keyvault secret set --name $hmacKeySecretName --vault-name $keyVaultName --value $hmac_key --description "HMAC Key for random generated Resource unique Identifiers"

if [[ "$deploymentType" != "dmlz"  ]]
then
    username=$(grep -ao '[a-z]' < /dev/urandom | head -10 | tr -d '\n' ;)
    password=$(grep -ao '[A-Za-z]' < /dev/urandom | head -20 | tr -d '\n' ;)
    az keyvault secret set --name $sqldbUserNameSecretName --vault-name $keyVaultName --value $username --description "Contains Username for SQL DB used for TF Deployment"
    az keyvault secret set --name $sqldbPasswordSecretName --vault-name $keyVaultName --value $password --description "Contains Password for SQL DB used for TF Deployment"
fi