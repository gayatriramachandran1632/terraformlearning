Feature: Check compliance for Azure Storage Accounts
  @namingConvention
  Scenario: Naming Standard for Azure Storage Accounts
    Given I have azurerm_storage_account defined
    When its is_hns_enabled is false
    Then it must have name
    And its value must match the "eva(d|t|p|st|sb)([A-Za-z0-9]{2,9})(fasst|st)([A-Za-z0-9]{4})" regex
    And its value must match the "^(?=.{1,24}$).*" regex
