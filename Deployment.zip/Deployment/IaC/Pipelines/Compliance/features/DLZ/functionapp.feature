Feature: Check compliance for Azure Function App
  @namingConvention
  Scenario Outline: Naming Standard for Function App
    Given I have <functionapptypes> defined
    Then it must have name
    And its value must match the "eva(d|t|p|st|sb)(cn|we|ne|cus|wus|wus2|gwc)fa[A-Za-z0-9]{1,15}([A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{6,32}$).*" regex

    Examples: 
      | functionapptypes             |
      | azurerm_linux_function_app   |
      | azurerm_windows_function_app |