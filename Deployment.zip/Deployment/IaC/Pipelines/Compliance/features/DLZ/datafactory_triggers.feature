Feature: Check compliance for Azure Data Factory Triggers
  @namingConvention
  Scenario Outline: Naming Standard for Data Factory Triggers
    Given I have <DataFactoryComponents> defined
    Then it must have name
    And its value must match the "TRG_(\S{1,50})" regex
    And its value must match the "^(?=.{10,260}$).*" regex

    Examples: 
      | DataFactoryComponents                     |
      | azurerm_data_factory_trigger_blob_event   |
      | azurerm_data_factory_trigger_custom_event |
      | azurerm_data_factory_trigger_schedule     |
