Feature: Check compliance for Azure Data Factory Linked Service
  @namingConvention
  Scenario Outline: Naming Standard for Data Factory Linked Service
    Given I have <DataFactoryComponents> defined
    Then it must have name
    And its value must match the "LS_(func|dbw|sqldb|dls|mysql|sql|kv)_(\S{1,50})" regex
    And its value must match the "^(?=.{10,260}$).*" regex
    
    Examples: 
      | DataFactoryComponents                                      | 
      | azurerm_data_factory_linked_service_azure_function         |
      | azurerm_data_factory_linked_service_azure_databricks       |
      | azurerm_data_factory_linked_service_azure_sql_database     |
      | azurerm_data_factory_linked_service_cosmosdb               |
      | azurerm_data_factory_linked_service_data_lake_storage_gen2 |
      | azurerm_data_factory_linked_service_mysql                  |
      | azurerm_data_factory_linked_service_sql_server             |
      | azurerm_data_factory_linked_service_key_vault              |

