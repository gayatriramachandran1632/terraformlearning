Feature: Check compliance for Data Factory Self-hosted Integration Runtime
  @namingConvention
  Scenario: Naming Standard for Data Factory Self-hosted Integration Runtime
    Given I have azurerm_data_factory_integration_runtime_self_hosted defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-shir(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{3,63}$).*" regex