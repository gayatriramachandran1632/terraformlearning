Feature: Check compliance for Azure Machine Learning Workspace
  @namingConvention
  Scenario: Naming Standard for Machine Learning Workspace
    Given I have azurerm_machine_learning_workspace defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-mlw(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,260}$).*" regex