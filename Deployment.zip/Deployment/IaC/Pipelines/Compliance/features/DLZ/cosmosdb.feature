Feature: Check compliance for Azure Cosmos db
  @namingConvention
  Scenario: Naming Standard for Cosmos db
    Given I have azurerm_cosmosdb_account defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-cosmos(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{3,44}$).*" regex