Feature: Check compliance for Azure Logic App
  @namingConvention
  Scenario: Naming Standard for Logic App
    Given I have azurerm_logic_app_standard defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-logic(-[A-Za-z0-9]{4})?$" regex
