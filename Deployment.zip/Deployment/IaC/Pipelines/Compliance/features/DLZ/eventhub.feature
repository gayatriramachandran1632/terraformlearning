Feature: Check compliance for Azure Event Hub
  @namingConvention
  Scenario: Naming Standard for Event Hub
    Given I have azurerm_eventhub defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-evh(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,256}$).*" regex
