Feature: Check compliance for Azure Application Insights
  @namingConvention
  Scenario: Naming Standard for Application Insights
    Given I have azurerm_application_insights defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-appi(-[A-Za-z0-9]{4})?$" regex
