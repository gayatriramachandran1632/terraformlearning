Feature: Check compliance for Azure Data Factory Datasets
  @namingConvention
  Scenario Outline: Naming Standard for Data Factory Datasets
    Given I have <DataFactoryComponents> defined
    Then it must have name
    And its value must match the "DS_(mysql|sql)_(\S{1,50})" regex
    And its value must match the "^(?=.{10,260}$).*" regex

    Examples: 
      | DataFactoryComponents                         |
      | azurerm_data_factory_dataset_mysql            |
      | azurerm_data_factory_dataset_sql_server_table |