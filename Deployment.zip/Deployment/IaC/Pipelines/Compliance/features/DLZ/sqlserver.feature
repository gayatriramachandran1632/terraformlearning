Feature: Check compliance for Azure SQL Server
  @namingConvention
  Scenario: Naming Standard for Azure SQL Server
    Given I have azurerm_mssql_server defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-sql(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,63}$).*" regex