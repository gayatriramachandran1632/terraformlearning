Feature: Check compliance for Azure Key Vault
  @namingConvention
  Scenario: Naming Standard for Key vaults
    Given I have azurerm_key_vault defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-kv(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{3,24}$).*" regex
