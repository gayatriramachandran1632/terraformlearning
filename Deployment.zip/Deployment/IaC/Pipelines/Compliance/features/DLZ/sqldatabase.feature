Feature: Check compliance for MS SQL Database
  @namingConvention
  Scenario: Naming Standard for MS SQL Database
    Given I have azurerm_mssql_database defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-(pd2i|ibase|northstar|bda|mldoc|mach1|dcc|watchdog)-sqldb(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,128}$).*" regex