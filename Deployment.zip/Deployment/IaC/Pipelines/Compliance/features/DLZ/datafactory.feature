Feature: Check compliance for Azure Data Factory
  @namingConvention
  Scenario: Naming Standard for Data Factory
    Given I have azurerm_data_factory defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-adf(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{10,63}$).*" regex
