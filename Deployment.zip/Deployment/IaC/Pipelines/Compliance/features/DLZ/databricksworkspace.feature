Feature: Check compliance for Azure Databricks Workspace
  @namingConvention
  Scenario: Naming Standard for Databricks Workspace
    Given I have azurerm_databricks_workspace defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-dbw(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{3,64}$).*" regex