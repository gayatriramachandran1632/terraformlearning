Feature: Check compliance for MySQL Database
  @namingConvention
  Scenario: Naming Standard for MySQL Database
    Given I have azurerm_mysql_database defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-mysqldb(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,63}$).*" regex