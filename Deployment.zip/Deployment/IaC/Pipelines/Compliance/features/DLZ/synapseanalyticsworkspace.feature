Feature: Check compliance for Azure Synapse Analytics Workspace
  @namingConvention
  Scenario: Naming Standard for Synapse Analytics Workspace
    Given I have azurerm_synapse_workspace defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-synw(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,50}$).*" regex