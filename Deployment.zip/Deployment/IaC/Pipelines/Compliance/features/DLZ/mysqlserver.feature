Feature: Check compliance for MySQL Server
  @namingConvention
  Scenario: Naming Standard for MySQL Server
    Given I have azurerm_mysql_server defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-mysql(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{3,63}$).*" regex