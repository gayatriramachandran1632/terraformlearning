Feature: Check compliance for Azure Data Lake Storage Gen2
  @namingConvention
  Scenario: Naming Standard for Data Lake Storage Gen2
    Given I have azurerm_storage_account defined
    When its is_hns_enabled is true
    Then it must have name
    And its value must match the "eva(d|t|p|st|sb)([A-Za-z0-9]{2,9})(raw|enr|dev)dls([A-Za-z0-9]{4})" regex
    And its value must match the "^(?=.{3,24}$).*" regex
