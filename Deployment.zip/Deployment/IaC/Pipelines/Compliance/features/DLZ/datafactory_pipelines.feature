Feature: Check compliance for Azure Data Factory Pipelines
  @namingConvention
  Scenario: Naming Standard for Data Factory Pipelines
    Given I have azurerm_data_factory_pipeline defined
    Then it must have name
    And its value must match the "PL_(network|governance|management|automation|privatedns|logging|storage|externalstorage|metadata|dataintegration|dataproduct|sharedintegration|sharedproduct)_(\S{1,50})" regex
    And its value must match the "^(?=.{10,260}$).*" regex