Feature: Check compliance for Azure Event Hub Namespace
  @namingConvention
  Scenario: Naming Standard for Event Hub Namespace
    Given I have azurerm_eventhub_namespace defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-evhns(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{6,50}$).*" regex