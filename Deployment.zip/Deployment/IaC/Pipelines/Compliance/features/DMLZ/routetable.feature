Feature: Check compliance for Route Table
  @namingConvention
  Scenario: Naming Standard for Route Table
    Given I have azurerm_route_table defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-rt(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,80}$).*" regex