Feature: Check compliance for Azure Firewall
  @namingConvention
  Scenario: Naming Standard for Firewall
    Given I have azurerm_firewall defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-afw(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,80}$).*" regex
