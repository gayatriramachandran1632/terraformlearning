Feature: Check compliance for Azure Container Registry
  @namingConvention
  Scenario: Naming Standard for Container Registry
    Given I have azurerm_container_registry defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-cr(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{5,50}$).*" regex