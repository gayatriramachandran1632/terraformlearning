Feature: Check compliance for Azure Container Instance
  @namingConvention
  Scenario: Naming Standard for Container Instance
    Given I have azurerm_storage_container defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-ci(-[A-Za-z0-9]{4})?$" regex

