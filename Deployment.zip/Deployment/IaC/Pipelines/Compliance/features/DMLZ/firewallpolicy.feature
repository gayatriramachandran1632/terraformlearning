Feature: Check compliance for Azure Firewall Policy
  @namingConvention
  Scenario: Naming Standard for Firewall Policy
    Given I have azurerm_firewall_policy defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-afwp(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,80}$).*" regex
