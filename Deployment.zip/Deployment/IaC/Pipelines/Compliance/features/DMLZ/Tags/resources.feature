Feature: Test tagging compliance all resources except resource groups

  Scenario: Ensure all resources have tags
    Given I have resource that supports tags defined
    Then it must contain tags
    And its value must not be null

  @ignore_module.resourcegroup.azurerm_resource_group.rg*
  Scenario Outline: Ensure that mandatory tags are defined correctly for resources
    Given I have resource that supports tags defined
    When it has tags
    Then it must contain <tags>
    And its value must match the "<value>" regex

    Examples: 
      | tags             | value                                                                                                                                                             |
      | description      | ^(?=.{1,200}$).*                                                                                                                                                  |
      | environment      | ^(prod\|dev\|staging\|sandbox\|test)$                                                                                                                                                |
      | project          | ^(eva\|eva-pd2i\|eva-ibase\|eva-northstar\|eva-bda\|eva-mldoc\|eva-mach1\|eva-dcc\|eva-watchdog)$                                                                               |
      | workload         | ^(network\|governance\|connectivity\|management\|automation\|privatedns\|logging\|storage\|externalstorage\|metadata\|dataintegration\|dataproduct\|sharedintegration\|sharedproduct\|apps)$ |
      | businessowner    | ^(([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5}){1,25})+([;.](([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5}){1,25})+)*$             |
      | businessgroup    | ^(all\|iqs\|cop\|rms\|med\|vis\|smt\|mcs\|opt\|pcs\|smo\|com)$                                                                                                    |
      | technicalcontact | ^(([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5}){1,25})+([;.](([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5}){1,25})+)*$             |
      | provisioner      | ^(terraform\|bashscript)$                                                                                                                                         |
      | region           | ^(china\|europe\|america)$                                                                                                                                        |

  @ignore_module.resourcegroup.azurerm_resource_group.rg*
  Scenario Outline: Ensure that when optional tags are defined, they are defined correctly for resources
    Given I have resource that supports tags defined
    Then it must contain <tags> 
    And its value must match the "<value>" regex

    Examples: 
      | tags               | value                                                                                                                                                 |
      | costcenter         | ^[0-9]{1,6}$                                                                                                                                          |
      | internalorder      | ^[0-9]{1,10}$                                                                                                                                          |
      | serviceprincipalid | ^[0-9a-fA-F]{8}\\b-[0-9a-fA-F]{4}\\b-[0-9a-fA-F]{4}\\b-[0-9a-fA-F]{4}\\b-[0-9a-fA-F]{12}$                                                             |
      | repo               | .+                                                                                                                                                    |
      | support            | ^(([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5}){1,25})+([;.](([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5}){1,25})+)*$ |
