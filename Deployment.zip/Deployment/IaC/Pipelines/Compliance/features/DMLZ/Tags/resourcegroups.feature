Feature: Test tagging compliance for resource groups

  Scenario Outline: Ensure that specific tags are defined
    Given I have azurerm_resource_group defined
    When it has tags
    Then it must contain <tags>
    And its value must match the "<value>" regex

    Examples: 
      | tags             | value                                                                                                                                                             |
      | description      | ^(?=.{1,200}$).*                                                                                                                                                  |
      | environment      | ^(prod\|dev\|staging\|sandbox\|test)$                                                                                                                                                |
      | project          | ^(eva\|eva-pd2i\|eva-ibase\|eva-northstar\|eva-bda\|eva-mldoc\|eva-mach1\|eva-dcc\|eva-watchdog)$                                                                                     |
      | workload         | ^(network\|governance\|connectivity\|management\|automation\|privatedns\|logging\|storage\|externalstorage\|metadata\|dataintegration\|dataproduct\|sharedintegration\|sharedproduct\|apps)$ |
      | businessowner    | ^(([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5}){1,25})+([;.](([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5}){1,25})+)*$             |
      | businessgroup    | ^(all\|iqs\|cop\|rms\|med\|vis\|smt\|mcs\|opt\|pcs\|smo\|com)$                                                                                                    |
      | technicalcontact | ^(([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5}){1,25})+([;.](([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5}){1,25})+)*$             |
      | provisioner      | ^(terraform\|bashscript)$                                                                                                                                         |
