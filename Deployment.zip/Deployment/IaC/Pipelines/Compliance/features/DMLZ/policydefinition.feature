Feature: Check compliance for Policy Definition
  @namingConvention
  Scenario: Naming Standard for Policy Definition
    Given I have azurerm_policy_definition defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-policy(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,64}$).*" regex
