Feature: Check compliance for Azure Log Analytics workspace
  @namingConvention
  Scenario: Naming Standard for Log Analytics workspace
    Given I have azurerm_log_analytics_workspace defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb|npc|npm)-(cn|we|ne|cus|wus|wus2|gwc)-log(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{4,63}$).*" regex
