Feature: Check compliance for Azure Automation Accounts
  @namingConvention
  Scenario: Naming Standard for automation accounts
    Given I have azurerm_automation_account defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-aa(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{6,50}$).*" regex
