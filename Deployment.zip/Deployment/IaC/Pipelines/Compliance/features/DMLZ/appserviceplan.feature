Feature: Check compliance for App Service Plan
  @namingConvention
  Scenario Outline: Naming Standard for App Service Plan
    Given I have <appserviceplan> defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2|gwc)-plan(-[A-Za-z0-9]{4})?$" regex

    Examples: 
      | appserviceplan           |
      | azurerm_app_service_plan |
      | azurerm_service_plan     |
