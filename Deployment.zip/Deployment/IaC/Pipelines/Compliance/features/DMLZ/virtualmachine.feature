Feature: Check compliance for Virtual Machines
  @namingConvention
  Scenario Outline: Naming Standard for Virtual Machines
    Given I have <vms> defined
    Then it must have name
    And its value must match the "vm-(d|t|p|st|sb)-([a-zA-Z0-9]{1,5})-([A-Za-z0-9]{4})" regex
    And its value must match the "^(?=.{1,15}$).*" regex

    Examples: 
      | vms                             |
      | azurerm_virtual_machine         |
      | azurerm_linux_virtual_machine   |
      | azurerm_windows_virtual_machine |
