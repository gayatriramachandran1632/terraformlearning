Feature: Check compliance for Private end points
  @namingConvention
  Scenario: Naming Standard for Private end points
    Given I have azurerm_private_endpoint defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb|npc|npm)-(cn|we|ne|cus|wus|wus2|gwc)-pep(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,80}$).*" regex