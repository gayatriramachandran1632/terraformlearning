Feature: Check compliance for Network Interface
  @namingConvention
  Scenario: Naming Standard for Network interface
    Given I have azurerm_network_interface defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb|npc|npm)-(cn|we|ne|cus|wus|wus2|gwc)-ni(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,80}$).*" regex