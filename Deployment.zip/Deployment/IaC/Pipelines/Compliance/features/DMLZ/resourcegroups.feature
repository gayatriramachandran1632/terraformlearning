Feature: Check compliance for Resource Groups

  @tagresourcegroup 
  @namingConvention
  Scenario: Naming Standard for resource groups
    Given I have azurerm_resource_group defined
    Then it must have name
    And its value must match the "eva-(dev|test|prod|staging|sandbox|nonprod)-(mgc|dmlz|pd2i|ibase|northstar|bda|mldoc|mach1|dcc|watchdog)-rg-(china|europe|america)-(network|connectivity|governance|management|automation|privatedns|logging|storage|externalstorage|metadata|dataintegration|dataproduct|sharedintegration|sharedproduct|apps)" regex
    And its value must match the "^(?=.{1,90}$).*" regex
