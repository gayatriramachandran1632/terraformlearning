Feature: Check compliance for Private DNS zones
  @namingConvention
  Scenario: Naming Standard for Private DNS zones
    Given I have azurerm_private_dns_zone defined
    Then it must have name
    And its value must match the "privatelink\.(.*)\.(com|net|io|cn|ms)$" regex