Feature: Check compliance for Microsoft Purview
  @namingConvention
  Scenario: Naming Standard for Microsoft Purview
    Given I have azurerm_purview_account defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb)-(cn|we|ne|cus|wus|wus2)-pview(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{5,50}$).*" regex