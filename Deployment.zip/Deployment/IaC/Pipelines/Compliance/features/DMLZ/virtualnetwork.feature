Feature: Check compliance for Virtual Network
  @namingConvention
  Scenario: Naming Standard for Virtual Network
    Given I have azurerm_virtual_network defined
    Then it must have name
    And its value must match the "eva-(d|t|p|st|sb|npc|npm)-(cn|we|ne|cus|wus|wus2|gwc)-vnet(-[A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{2,64}$).*" regex