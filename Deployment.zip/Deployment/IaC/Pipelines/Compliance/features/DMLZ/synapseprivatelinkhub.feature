Feature: Check compliance for Azure Synapse Private Link Hub
  @namingConvention
  Scenario: Naming Standard for Synapse Private Link Hub
    Given I have azurerm_synapse_private_link_hub defined
    Then it must have name
    And its value must match the "eva(d|t|p|st|sb)(cn|we|ne|cus|wus|wus2|gwc)synpl([A-Za-z0-9]{4})?$" regex
    And its value must match the "^(?=.{1,80}$).*" regex