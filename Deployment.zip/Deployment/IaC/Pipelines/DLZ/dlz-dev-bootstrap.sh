# This script bootstraps a new region for further provisioning with Terraform. We setup an Azure Resource Group,
# Azure Storage Account and configure Customer-managed encryption using a RSA key stored in a new Keyvault.
# Please consider a dedicated Resource Group for Terraform in a separate Azure Subscription for maximum security.
# This script will fail if any of commands throws an error
set -e 
location="westeurope"
tenantId="28042244-bb51-4cd6-8034-7776fa3703e8"
subscriptionId="6f6efb40-ce6e-4556-95e9-9af5f2621bfb"
devOpsServicePrincipalName="zdp-ap-ag-eva-we-dev-sp-dlz1-devops"
resourceGroupName="eva-dev-dlz-rg-europe-automation"
byokKeyName="eva-d-we-byok"
stateContainerName="eva-d-we-state-container"
patchVersionSecretName="patch"
minorVersionSecretName="minor"
majorVersionSecretName="major"
keyVaultNameSecretName="keyVaultName"
backendResourceGroupNameSecretName="backendAzureRmResourceGroupName"
backendResourceGroupName="eva-dev-dlz-rg-europe-automation"
backendStorageAccountNameSecretName="backendAzureRmStorageAccountName"
backendContainerNameSecretName="backendAzureRmContainerName"
backendKeySecretName="backendAzureRmKey"
backendKey="DLZ-StateFile-Dev"
sqldbUserNameSecretName="sqldbusername"
sqldbPasswordSecretName="sqldbpassword"

env_short="dlzdev"
workload="automation"
hmac_key="2kvBxC/3ZtZQ9ZVz9TLRclGPamRXwh/W06F6+kvacKtU="
hmac_key_sha="$env_short$workload$hmac_key"
instance_ID=`echo -n $hmac_key_sha | sha256sum | head -c 4`

keyVaultName="eva-d-we-kv-tf-$instance_ID"
storageAccountName="evadevsttf$instance_ID"

# Set correct Subscription
az account set --subscription $subscriptionId
# Creating Azure Resource Group
az group create --location $location --resourceGroup $resourceGroupName --subscription $subscriptionId
# Creating Keyvault for BYOK and Variable Group for Deployment
az keyvault create --name $keyVaultName --location $location --resourceGroup $resourceGroupName --enable-purge-protection
# Creating Key for Customer-managed encryption
az keyvault key create --name $byokKeyName --protection software --size 3072 --vault-name $keyVaultName
# Grant DevOps Service Connection Principal access to Get The Secrets
devOpsServicePrincipalId=$(az ad sp list --display-name $devOpsServicePrincipalName --query [0].objectId --output tsv)
az keyvault set-policy --name $keyVaultName --resourceGroup $resourceGroupName --object-id $devOpsServicePrincipalId --secret-permissions get list set
# Creating Azure Storage Account with assigned Idenity
az storage account create --name $storageAccountName --location $location --resourceGroup $resourceGroupName --allow-blob-public-access --sku Standard_GRS --kind StorageV2 --assign-identity
# Grant access to Keyvault using Managed Identity of Azure Storage Account
storage_account_principal=$(az storage account show --name $storageAccountName --resourceGroup $resourceGroupName --query identity.principalId --output tsv)
az keyvault set-policy --name $keyVaultName --resourceGroup $resourceGroupName --object-id $storage_account_principal --key-permissions get unwrapKey wrapKey
key_vault_uri=$(az keyvault show --name $keyVaultName --resourceGroup $resourceGroupName --query properties.vaultUri --output tsv)
# Updating Storage Account to use Customer-managed keys
key_version=$(az keyvault key list-versions --name $byokKeyName --vault-name $keyVaultName --query [-1].kid --output tsv | cut -d '/' -f 6)
az storage account update --name $storageAccountName --resourceGroup $resourceGroupName --encryption-key-name $byokKeyName --encryption-key-version $key_version --encryption-key-source Microsoft.Keyvault --encryption-key-vault $key_vault_uri
# Creating Storage Container tfstate in Azure Storage Account
sleep 30;az storage container create --name $stateContainerName --account-name $storageAccountName --auth-mode login --public-access off --resourceGroup $resourceGroupName

#Create Secrets for Verion Control
az keyvault secret set --name $patchVersionSecretName --vault-name $keyVaultName --value 0 --description "Contains Information about the Versioning of the Terraform Deployment"
az keyvault secret set --name $minorVersionSecretName --vault-name $keyVaultName --value 0 --description "Contains Information about the Versioning of the Terraform Deployment"
az keyvault secret set --name $majorVersionSecretName --vault-name $keyVaultName --value 0 --description "Contains Information about the Versioning of the Terraform Deployment"
az keyvault secret set --name $keyVaultNameSecretName --vault-name $keyVaultName --value $keyVaultName --description "Contains the KeyVault Name for the Versioning of the Terraform Deployment"
#Create Secrets for TF Deployment
az keyvault secret set --name $backendStorageAccountNameSecretName --vault-name $keyVaultName --value $storageAccountName --description "Contains the Storage Account for Terraform Deployments"
az keyvault secret set --name $backendContainerNameSecretName --vault-name $keyVaultName --value $stateContainerName --description "Contains the Backend Container for Terraform Deployments"
az keyvault secret set --name $backendKeySecretName --vault-name $keyVaultName --value $backendKey --description "Contains the State File for Terraform Deployments"
az keyvault secret set --name $backendResourceGroupNameSecretName --vault-name $keyVaultName --value $backendResourceGroupName --description "Contains the Resource Group for Terraform Deployments"

# keyvalut username & pw 20 Charakters
$username = -join (((48..57)+(65..90)+(97..122)) * 80 |Get-Random -Count 12 |%{[char]$_})
$password = -join (((48..57)+(65..90)+(97..122)) * 80 |Get-Random -Count 12 |%{[char]$_})
az keyvault secret set --name $sqldbUserNameSecretName --vault-name $keyVaultName --value $username --description "Contains Username for SQL DB used for TF Deployment"
az keyvault secret set --name $sqldbPasswordSecretName --vault-name $keyVaultName --value $password --description "Contains Password for SQL DB used for TF Deployment"