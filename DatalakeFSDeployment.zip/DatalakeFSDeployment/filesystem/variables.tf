variable "resource_group_name" {
  type = string
}
variable "storage_id" {
  type = string
}
variable "container_path" {
  type = string
}