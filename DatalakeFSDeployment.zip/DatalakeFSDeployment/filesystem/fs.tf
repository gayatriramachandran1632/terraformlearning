locals {
  environment_settings = jsondecode(file(var.container_path)).datalake
}

resource "azurerm_storage_data_lake_gen2_filesystem" "storagefs" {
  for_each           = length(regexall("raw", var.storage_id)) > 0 ? { for p in local.environment_settings[0].raw : tostring(p.container) => p } : length(regexall("enr", var.storage_id)) > 0 ? { for p in local.environment_settings[0].enr : tostring(p.container) => p } : { for p in local.environment_settings[0].dev : tostring(p.container) => p }
  name               = each.key
  storage_account_id = var.storage_id
}