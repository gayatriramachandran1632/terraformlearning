output "raw_containers" {
  value = local.environment_settings[*].raw
}
output "enriched_containers" {
  value = local.environment_settings[*].enr
}
output "development_containers" {
  value = local.environment_settings[*].dev
}
