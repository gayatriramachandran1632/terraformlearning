variable "container_filepath" {
  type = string
}
variable "resource_group" {
  type = string
}
variable "datalake_names" {
  type = string
}