output "storageid" {
  value = [for n in module.storage : n.storageid]
}
output "fs" {
  value = module.fs
}
