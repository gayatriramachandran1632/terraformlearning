output "storageid" {
  value = data.azurerm_storage_account.storage.id
}