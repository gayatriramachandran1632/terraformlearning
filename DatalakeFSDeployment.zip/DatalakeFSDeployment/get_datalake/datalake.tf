
data "azurerm_storage_account" "storage" {
  name                = var.datalakename
  resource_group_name = var.resource_group_name
}