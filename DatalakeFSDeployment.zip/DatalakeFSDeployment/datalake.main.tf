terraform {
  required_version = ">= 0.15"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.18.0"
    }
  }
  backend "azurerm" {
  }
}

provider "azurerm" {
  features {}
}

locals {
  datalakes = jsondecode(file(var.datalake_names))
}

data "azurerm_resource_group" "rsg" {
  name = var.resource_group
}

module "storage" {
  for_each            = { for p in ((local.datalakes == null) ? toset([]) : local.datalakes) : p => p }
  source              = "./get_datalake"
  datalakename        = each.key
  resource_group_name = data.azurerm_resource_group.rsg.name
}

module "fs" {
  for_each            = { for p in module.storage : tostring(p.storageid) => p }
  container_path      = var.container_filepath
  source              = "./filesystem"
  storage_id          = each.key
  resource_group_name = data.azurerm_resource_group.rsg.name
}
