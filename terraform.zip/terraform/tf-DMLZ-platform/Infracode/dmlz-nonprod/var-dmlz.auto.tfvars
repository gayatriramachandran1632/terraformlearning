productname     = "eva"
landingzonetype = "dmlz"
regionlong      = "europe"
regionshort     = "gwc"

rsg_tags = {
  description         = "DMLZ resources"
  environment         = "dev"
  businessowner       = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  technicalcontact    = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  project             = "eva"
  provisioner         = "terraform"
  businessgroup       = "all"
  ContactEmailAddress = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com;jan-michael.matzkovits@zeiss.com"
}

ars_tags = {
  costcenter         = "000000"
  internalorder      = "0000000000"
  region             = "europe"
  serviceprincipalid = "NA"
  repo               = "ZDP-AP_eVA_MS_MVP"
  support            = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
}


resource_groups = {
  0 = {
    location     = "Germany West Central"
    workload     = "governance"
    resourcetype = "rg"
    rg_tags = {
      workload = "governance"
    }
  }
  1 = {
    location     = "Germany West Central"
    workload     = "network"
    resourcetype = "rg"
    rg_tags = {
      workload = "network"
    }
  }
  2 = {
    location     = "Germany West Central"
    workload     = "storage"
    resourcetype = "rg"
    rg_tags = {
      workload = "storage"
    }
  }
  3 = {
    location     = "Germany West Central"
    workload     = "management"
    resourcetype = "rg"
    rg_tags = {
      workload = "management"
    }
  }
}

keyvault = {
  0 = {
    resourcetype                    = "kv"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    purge_protection_enabled        = true
    sku_name                        = "standard"
    rand_value                      = "kvtnpdmlz01p" # Please check wiki
  }
}

virtual_networks = {
  0 = {
    resourcetype    = "vnet"
    subresourcetype = "snet"
    rand_value_vnet = "vnetnpdmlz01" # Please check wiki
    rand_value_snet = "snetnpdmlz01" # Please check wiki
  }
}

network_security_groups = {
  0 = {
    resourcetype = "nsg"
    rand_value   = "nsg01" # Please check wiki
  }
}

pview = {
  0 = {
    resourcetype = "pview"
    rand_value   = "pview01" # Please check wiki
  }
}

synapse_private_link_hub = {
  0 = {
    resourcetype = "synpl"
    rand_value   = "synpl01" # Please check wiki
  }
}

private_endpoints = {
  0 = {
    name       = "pe"
    rand_value = "pe01" # Please check wiki
  }
}

application_insights = {
  0 = {
    application_type     = "web"
    retention_in_days    = 60
    daily_data_cap_in_gb = 10
    resourcetype         = "appi"
    rand_value           = "appi01" # Please check wiki
  }
}

storage_accounts = {
  0 = {
    resourcetype             = "st"
    account_replication_type = "LRS"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_tier             = "Standard"
    rand_value               = "st01" # As mentioned at the start of the file.
    min_tls_version          = "TLS1_2"
  }
}

statabledeployment = 0
staqueuedeployment = 0
