data "azurerm_subscription" "config" {}
//**********************************************************
//  Resource Group
//**********************************************************
module "resourcegroup" {
  source          = "../../../tf-core-module/resource-group"
  resource_groups = var.resource_groups
  productname     = var.productname
  environmentlong = var.environmentlong
  landingzonetype = var.landingzonetype
  regionlong      = var.regionlong
  rsg_tags        = var.rsg_tags
}

module "use-role" {
  source = "../../../tf-core-module/network-iam-role/use-role"
  depends_on = [
    module.resourcegroup
  ]
}
module "networkIAM_network" {
  for_each    = { for n in split(",", var.networking_sp_id) : n => n }
  source      = "../../../tf-core-module/network-iam-role"
  scope_id    = [for n in module.resourcegroup.rgid : n if can(regex("network", n))][0]
  principleID = each.key
  depends_on = [
    module.use-role
  ]
}
module "networkIAM_peering" {
  for_each    = { for n in split(",", var.networking_sp_id) : n => n }
  source      = "../../../tf-core-module/network-iam-role"
  scope_id    = [for n in module.resourcegroup.rgid : n if can(regex("storage", n))][0]
  principleID = each.key
  depends_on = [
    module.networkIAM_network
  ]
}
module "networkIAM_management" {
  for_each    = { for n in split(",", var.networking_sp_id) : n => n }
  source      = "../../../tf-core-module/network-iam-role"
  scope_id    = [for n in module.resourcegroup.rgid : n if can(regex("management", n))][0]
  principleID = each.key
  depends_on = [
    module.networkIAM_peering
  ]
}
module "networkIAM_governance" {
  for_each    = { for n in split(",", var.networking_sp_id) : n => n }
  source      = "../../../tf-core-module/network-iam-role"
  scope_id    = [for n in module.resourcegroup.rgid : n if can(regex("governance", n))][0]
  principleID = each.key
  depends_on = [
    module.networkIAM_peering
  ]
}

//*********************************
//  Network
//*********************************
module "get_network" {
  source                  = "../../../tf-core-module/network/reference_vnet"
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = "nonprod"
  dest_landingzonetype    = "mgc"
  productname             = var.productname
  regionlong              = var.regionlong
  providers = {
    azurerm.destination = azurerm.destination
  }
}

//*********************************
//  Network
//*********************************
module "network" {
  source              = "../../../tf-core-module/network"
  virtual_networks    = var.virtual_networks
  productname         = var.productname
  environmentshort    = var.environmentshort
  regionshort         = var.regionshort
  resourcegpname      = module.resourcegroup.rgname.1
  resourcelocation    = module.resourcegroup.rglocation.1
  ars_tags            = var.ars_tags
  rgtags              = module.resourcegroup.rgtags.1
  hmac_key            = var.hmac_key
  networking_filepath = var.networking_filepath
  platform            = var.platform
  depends_on = [
    module.resourcegroup,
    module.networkIAM_peering
  ]
  network_security_groups = var.network_security_groups
}

//*************************************************************
// Peer DMLZ non-prod mgmt to non-prod connectivity
//
// HUB service principal should have Network contributor access
// to DMLZ mgmt, connectivity and DMLZ subscription
//*************************************************************
module "peering" {
  source                   = "../../../tf-core-module/network/peering"
  productname              = var.productname
  regionlong               = var.regionlong
  src_vnet_id              = [for n in module.network.vnetid : n[0]][1]["id"]
  src_vnet_name            = [for n in module.network.vnetid : n[0]][1]["name"]
  src_vnet_rsg_name        = module.resourcegroup.rgname.1
  dest_vnet_required_tags  = "eva"
  dest_environmentlong     = "nonprod"
  dest_landingzonetype     = "mgc"
  dest_clientid            = var.peering_clientid
  dest_clientsecret        = var.peering_clientsecret
  dest_subscriptionid      = var.peering_subscriptionid
  peering_name_src_to_dest = "nonprod_dmlz_to_nonprod_connectivity"
  peering_name_dest_to_src = "connectivity_to_dmlz_nonprod"
  rsg_tags                 = module.resourcegroup.rgtags.1
}

module "pvtlink" {
  source                 = "../../../tf-core-module/network/private-endpoint/pvtlink"
  dest_clientid          = var.peering_clientid
  dest_clientsecret      = var.peering_clientsecret
  dest_subscriptionid    = var.peering_subscriptionid
  productname            = var.productname
  regionlong             = var.regionlong
  dest_environmentlong   = "nonprod"
  dest_landingzonetype   = "mgc"
  source_landingzonetype = var.landingzonetype
  dns                    = [for n in split(",", var.alldnssecretsaslist) : n]
  src_vnet_id            = [for n in module.network.vnetid : n[0]][1]["id"]
}

//**********************************************************
//  Keyvault
//**********************************************************
module "keyvault" {
  source           = "../../../tf-core-module/keyvault"
  keyvault         = var.keyvault
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.3
  resourcelocation = module.resourcegroup.rglocation.3
  rgtags           = module.resourcegroup.rgtags.3
  ars_tags         = var.ars_tags
  hmac_key         = var.hmac_key

  depends_on = [
    module.network
  ]
}

module "resource-loop-kvt" {
  for_each            = { for p in flatten(module.keyvault.key_vault_name) : tostring(p) => p }
  source              = "../../../tf-core-module/keyvault/resource_loop"
  name                = [join("", ["/subscriptions/", data.azurerm_subscription.config.subscription_id, "/resourceGroups/${module.resourcegroup.rgname.3}/providers/Microsoft.KeyVault/vaults/", each.value])]
  hmac                = substr(each.value, -4, 0)
  pvtendpointrsg      = split("/", var.connectivity_subscription_vnet_id)[4]
  pvtendpointlocation = module.resourcegroup.rglocation.3
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.get_network : n][0]["resources"][0]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("vaultcore", n))]
  rg_location         = module.resourcegroup.rglocation.3
  rg_name             = split("/", var.connectivity_subscription_vnet_id)[4]
  providers = {
    azurerm.destination = azurerm.destination
  }
}
module "dns_zone_a_record_keyvault" {
  source                  = "../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = "nonprod"
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-kvt : n][0]["subres"]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-kvt : n][0]["subres"]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "vaultcore"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}

//**********************************************************
//  Storage
//**********************************************************
module "storage" {
  source           = "../../../tf-core-module/storage"
  storage_accounts = var.storage_accounts
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.2
  resourcelocation = module.resourcegroup.rglocation.2
  ars_tags         = var.ars_tags
  rgtags           = module.resourcegroup.rgtags.2
  hmac_key         = var.hmac_key
  landingzonetype  = var.landingzonetype

  deployqueue = var.staqueuedeployment
  deploytable = var.statabledeployment
  depends_on = [
    module.network
  ]
}
module "resource-loop-storage" {
  for_each            = { for n in module.storage.sa_name : n => n }
  source              = "../../../tf-core-module/storage/resource_loop"
  name                = [join("", ["/subscriptions/", data.azurerm_subscription.config.subscription_id, "/resourceGroups/${module.resourcegroup.rgname.2}/providers/Microsoft.Storage/storageAccounts/", each.value])]
  hmac                = substr(module.storage.sa_name[0], -4, 0)
  pvtendpointrsg      = split("/", var.connectivity_subscription_vnet_id)[4]
  pvtendpointlocation = module.resourcegroup.rglocation.2
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.get_network : n][0]["resources"][0]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("blob.core|file.core|queue.core|table.core", n))]
  rg_location         = module.resourcegroup.rglocation.2
  rg_name             = split("/", var.connectivity_subscription_vnet_id)[4]
  providers = {
    azurerm.destination = azurerm.destination
  }
}

module "dns_zone_a_record_storage_blob" {
  source                  = "../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = "nonprod"
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-storage : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-storage : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "blob.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}

module "dns_zone_a_record_storage_file" {
  source                  = "../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = "nonprod"
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-storage : n][0]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-storage : n][0]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "file.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}

module "dns_zone_a_record_storage_queue" {
  source                  = "../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = "nonprod"
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-storage : n][0]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-storage : n][0]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "queue.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}

module "dns_zone_a_record_storage_table" {
  source                  = "../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = "nonprod"
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-storage : n][0]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-storage : n][0]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "table.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}


//*********************************
//  Purview
//*********************************
module "purview" {
  source           = "../../../tf-core-module/purview"
  pview            = var.pview
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = "we"
  resourcegpname   = module.resourcegroup.rgname.0
  resourcelocation = "west europe"
  ars_tags         = var.ars_tags
  rgtags           = module.resourcegroup.rgtags.0
  hmac_key         = var.hmac_key
}

module "resource-loop-purview" {
  source              = "../../../tf-core-module/purview/resource_loop"
  name                = module.purview.pview_acc_id
  hmac                = substr(module.purview.pview_acc_name[0], -4, 0)
  pvtendpointrsg      = split("/", var.connectivity_subscription_vnet_id)[4]
  pvtendpointlocation = module.resourcegroup.rglocation.1
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.get_network : n][0]["resources"][0]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("purview.azure|purviewstudio", n))]
  rg_location         = module.resourcegroup.rglocation.1
  rg_name             = split("/", var.connectivity_subscription_vnet_id)[4]
  providers = {
    azurerm.destination = azurerm.destination
  }
}

//**********************************************************************************
// Create dnszone a_record for purview
//**********************************************************************************
module "dns_zone_a_record_purview" {
  source                  = "../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = "nonprod"
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-purview : n][0][0]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-purview : n][0][0]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "purview.azure"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_purview_web_studio" {
  source                  = "../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = "nonprod"
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-purview : n][0][0]["subres"][1]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-purview : n][0][0]["subres"][1]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "purviewstudio"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}

module "keyvault_pview" {
  source      = "../../../tf-core-module/keyvault/keyvault_secret"
  secretvalue = module.purview["pview_acc_id"]
  keyvault_id = module.keyvault.key_vault_id.0
}
module "keyvault_pview_MID" {
  source      = "../../../tf-core-module/keyvault/keyvault_secret"
  secretvalue = [[for n in module.purview : n][0][0]["identity"][0]["principal_id"]]
  isService   = true
  serviceName = format("%s-%s", [for n in module.purview["pview_acc_name"] : n][0], "mid")
  keyvault_id = module.keyvault.key_vault_id.0
}

module "synapse_private_link_hub" {
  source                   = "../../../tf-core-module/synapse-private-link"
  synapse_private_link_hub = var.synapse_private_link_hub
  productname              = var.productname
  environmentshort         = var.environmentshort
  regionshort              = var.regionshort
  resourcegpname           = module.resourcegroup.rgname.1
  resourcelocation         = module.resourcegroup.rglocation.1
  ars_tags                 = var.ars_tags
  rgtags                   = module.resourcegroup.rgtags.1
  hmac_key                 = var.hmac_key
}

module "resource-loop-synapse-pvt-link" {
  source              = "../../../tf-core-module/synapse-private-link/resource_loop"
  name                = [[for n in module.synapse_private_link_hub : n][0][0]["id"]]
  hmac                = substr([for n in module.synapse_private_link_hub : n][0][0]["id"], -4, 0)
  pvtendpointrsg      = split("/", var.connectivity_subscription_vnet_id)[4]
  pvtendpointlocation = module.resourcegroup.rglocation.1
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.get_network : n][0]["resources"][0]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("azuresynapse", n))]
  rg_location         = module.resourcegroup.rglocation.1
  rg_name             = split("/", var.connectivity_subscription_vnet_id)[4]
  providers = {
    azurerm.destination = azurerm.destination
  }
}