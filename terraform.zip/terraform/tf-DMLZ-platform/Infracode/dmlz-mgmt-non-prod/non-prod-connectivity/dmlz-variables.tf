//**********************************************************
//  Common variables that are used in all resource's names
//**********************************************************
variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "environmentlong" {
  type = string
}
variable "regionlong" {
  type = string
}
variable "landingzonetype" {
  type = string
}
variable "networking_filepath" {
  type = string
}
variable "platform" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rsg_tags" {
  type = map(string)
}
variable "networking_sp_id" {
  type = string
}
variable "ars_tags" {
  type = map(any)
}

//**********************************************************
//  Resource Group variables
//**********************************************************
variable "resource_groups" {
  description = "Resource groups"
  type = map(object({
    location = string
    #name              = string   
    workload     = string
    resourcetype = string
    rg_tags      = map(string)
  }))
}

################################################################
## Private DNS Zones variables
##############################################################
variable "private_dns_zones" {
  description = "Private DNS Zones"
  type = map(object({
    dns_zone_name        = string
    zone_exists          = bool
    registration_enabled = bool
    rand_value           = string
  }))
}

##############################################################
## Virtual Network variables
##############################################################
variable "virtual_networks" {
  type = map(object({
    resourcetype    = string
    subresourcetype = string
    rand_value_vnet = string
    rand_value_snet = string
  }))
}

############################################
# NSG Variables
###########################################
variable "network_security_groups" {
  description = "network security group"
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}

#############################################################
# Private Endpoint
#############################################################
variable "private_endpoints" {
  type = map(object({
    name       = string
    rand_value = string
  }))
}


//**********************************************************
//  Keyvault Variables
//**********************************************************
variable "keyvault" {
  type = map(object({
    enabled_for_deployment          = bool
    enabled_for_disk_encryption     = bool
    enabled_for_template_deployment = bool
    purge_protection_enabled        = bool
    sku_name                        = string
    resourcetype                    = string
    rand_value                      = string
  }))
}
variable "windows_virtual_machine" {
  type = map(object({
    rand_value_vm        = string
    resourcetype         = string
    publisher            = string
    offer                = string
    sku                  = string
    version              = string
    storage_account_type = string
    caching              = string
    size                 = string
    admin_username       = string
  }))
}

variable "linux_virtual_machine" {
  type = map(object({
    rand_value_vm           = string
    admin_username          = string
    resourcetype            = string
    network_interface_short = string
    size                    = string
    publisher               = string
    offer                   = string
    sku                     = string
    version                 = string
  }))
}