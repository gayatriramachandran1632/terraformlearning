data "azurerm_subscription" "config" {}
//**********************************************************
//  Resource Group
//**********************************************************
module "resourcegroup" {
  source          = "../../../../tf-core-module/resource-group"
  resource_groups = var.resource_groups
  productname     = var.productname
  environmentlong = var.environmentlong
  landingzonetype = var.landingzonetype
  regionlong      = var.regionlong
  rsg_tags        = var.rsg_tags
}

module "create-role" {
  source = "../../../../tf-core-module/network-iam-role/create-role"
}
module "networkIAM_network" {
  for_each    = { for n in split(",", var.networking_sp_id) : n => n }
  source      = "../../../../tf-core-module/network-iam-role"
  scope_id    = [for n in module.resourcegroup.rgid : n if can(regex("network", n))][0]
  principleID = each.key
  depends_on = [
    module.create-role
  ]
}

module "networkIAM_privatedns" {
  for_each    = { for n in split(",", var.networking_sp_id) : n => n }
  source      = "../../../../tf-core-module/network-iam-role"
  scope_id    = [for n in module.resourcegroup.rgid : n if can(regex("privatedns", n))][0]
  principleID = each.key
  depends_on = [
    module.create-role
  ]
}

//*********************************
//  Network
//*********************************
module "network" {
  source                  = "../../../../tf-core-module/network"
  virtual_networks        = var.virtual_networks
  productname             = var.productname
  environmentshort        = var.environmentshort
  regionshort             = var.regionshort
  resourcegpname          = module.resourcegroup.rgname.1
  resourcelocation        = module.resourcegroup.rglocation.1
  ars_tags                = var.ars_tags
  rgtags                  = module.resourcegroup.rgtags.1
  hmac_key                = var.hmac_key
  networking_filepath     = var.networking_filepath
  platform                = var.platform
  network_security_groups = var.network_security_groups
  depends_on = [
    module.networkIAM_network,
    module.networkIAM_privatedns
  ]
}

//*********************************
//  Global DNS
//*********************************
module "dns" {
  source            = "../../../../tf-core-module/dns"
  private_dns_zones = var.private_dns_zones
  resourcegpname    = module.resourcegroup.rgname.0
  ars_tags          = var.ars_tags
  rgtags            = module.resourcegroup.rgtags.0
  environmentshort  = var.environmentshort
  hmac_key          = var.hmac_key
  productname       = var.productname
  regionshort       = var.regionshort
  vnet_id           = [for n in module.network.vnetid : n[0]][1]["id"]
  depends_on = [
    module.network
  ]
}

//**********************************************************
//  Keyvault
//**********************************************************
module "keyvault" {
  source           = "../../../../tf-core-module/keyvault"
  keyvault         = var.keyvault
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.2
  resourcelocation = module.resourcegroup.rglocation.2
  rgtags           = module.resourcegroup.rgtags.2
  ars_tags         = var.ars_tags
  hmac_key         = var.hmac_key

  depends_on = [
    module.dns
  ]
}

module "resource-loop-kvt" {
  for_each            = { for p in flatten(module.keyvault.key_vault_name) : tostring(p) => p }
  source              = "../../../../tf-core-module/keyvault/resource_loop"
  name                = [join("", ["/subscriptions/", data.azurerm_subscription.config.subscription_id, "/resourceGroups/${module.resourcegroup.rgname.2}/providers/Microsoft.KeyVault/vaults/", each.value])]
  hmac                = substr(each.value, -4, 0)
  pvtendpointrsg      = module.resourcegroup.rgname.1
  pvtendpointlocation = module.resourcegroup.rglocation.1
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.network : n][1]["vnetname"][0]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in module.dns["dns_zone_ids"] : n if can(regex("vaultcore", n))]
  rg_location         = module.resourcegroup.rglocation.1
  rg_name             = module.resourcegroup.rgname.1
  providers = {
    azurerm.destination = azurerm
  }
}

module "dns_zone_a_record_vault" {
  source               = "../../../../tf-core-module/dns/dns-a-record-connectivity/"
  productname          = var.productname
  regionlong           = var.regionlong
  dest_environmentlong = "nonprod"
  dest_landingzonetype = "mgc"
  fqdn                 = split(".", [for n in module.resource-loop-kvt : n][0]["subres"]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress            = [for n in module.resource-loop-kvt : n][0]["subres"]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                  = [for n in module.dns["dns_zone_ids"] : n]
  filter               = "vaultcore"
  depends_on = [
    module.keyvault
  ]
}

module "keyvault_dns" {
  source      = "../../../../tf-core-module/keyvault/keyvault_secret"
  secretvalue = module.dns["dns_zone_ids"]
  keyvault_id = module.keyvault.key_vault_id[0]
  depends_on = [
    module.dns_zone_a_record_vault
  ]
}
module "keyvault_vnet_id" {
  source      = "../../../../tf-core-module/keyvault/keyvault_secret"
  secretvalue = [[for n in module.network : n][1]["vnetname"][0]["id"]]
  keyvault_id = module.keyvault.key_vault_id[0]
  depends_on = [
    module.keyvault
  ]
}

module "windows_vm" {
  source                  = "../../../../tf-core-module/virtual-machine/windows-virtual-machine"
  ars_tags                = var.ars_tags
  environmentshort        = var.environmentshort
  hmac_key                = var.hmac_key
  productname             = var.productname
  regionshort             = var.regionshort
  resourcegpname          = module.resourcegroup.rgname.1
  resourcelocation        = module.resourcegroup.rglocation.1
  rgtags                  = module.resourcegroup.rgtags.1
  subnet_id               = length(regexall("VirtualMachine", [for n in module.network : n][0][2]["subnetserviceid"])) > 0 ? [for n in module.network : n][0][2]["subnetserviceid"] : length(regexall("VirtualMachine", [for n in module.network : n][0][1]["subnetserviceid"])) > 0 ? [for n in module.network : n][0][1]["subnetserviceid"] : [for n in module.network : n][0][0]["subnetserviceid"]
  windows_virtual_machine = var.windows_virtual_machine
  keyvault_id             = module.keyvault.key_vault_id.0
}

module "bastion" {
  source           = "../../../../tf-core-module/virtual-machine/bastion"
  ars_tags         = var.ars_tags
  environmentshort = var.environmentshort
  hmac_key         = var.hmac_key
  productname      = var.productname
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.1
  resourcelocation = module.resourcegroup.rglocation.1
  rgtags           = module.resourcegroup.rgtags.1
  subnet_id        = length(regexall("AzureBastionSubnet", [for n in module.network : n][0][2]["subnetserviceid"])) > 0 ? [for n in module.network : n][0][2]["subnetserviceid"] : length(regexall("AzureBastionSubnet", [for n in module.network : n][0][1]["subnetserviceid"])) > 0 ? [for n in module.network : n][0][1]["subnetserviceid"] : [for n in module.network : n][0][0]["subnetserviceid"]
}

module "linux_vm" {
  source                = "../../../../tf-core-module/virtual-machine/linux-virtual-machine"
  ars_tags              = var.ars_tags
  environmentshort      = var.environmentshort
  hmac_key              = var.hmac_key
  productname           = var.productname
  regionshort           = var.regionshort
  resourcegpname        = module.resourcegroup.rgname.1
  resourcelocation      = module.resourcegroup.rglocation.1
  rgtags                = module.resourcegroup.rgtags.1
  subnet_id             = length(regexall("VirtualMachine", [for n in module.network : n][0][2]["subnetserviceid"])) > 0 ? [for n in module.network : n][0][2]["subnetserviceid"] : length(regexall("VirtualMachine", [for n in module.network : n][0][1]["subnetserviceid"])) > 0 ? [for n in module.network : n][0][1]["subnetserviceid"] : [for n in module.network : n][0][0]["subnetserviceid"]
  linux_virtual_machine = var.linux_virtual_machine
  keyvault_id           = module.keyvault.key_vault_id.0
}
