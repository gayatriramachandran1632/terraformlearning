output "network" {
  value = [for item in module.network : item]
}
output "dmlznetworkid" {
  value = [for n in module.network.vnetid : n[0]][1]["id"]
}
output "storage" {
  value = module.storage
}