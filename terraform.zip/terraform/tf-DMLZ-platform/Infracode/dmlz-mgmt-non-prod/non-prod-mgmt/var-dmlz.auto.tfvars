productname     = "eva"
landingzonetype = "mgmt"
regionlong      = "europe"
regionshort     = "gwc"

rsg_tags = {
  description         = "DMLZ Mgmt Non-Prod resources"
  environment         = "mgmt-non-prod"
  businessowner       = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  technicalcontact    = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  project             = "eva"
  provisioner         = "terraform"
  businessgroup       = "all"
  ContactEmailAddress = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com;jan-michael.matzkovits@zeiss.com"
}

ars_tags = {
  costcenter         = "000000"
  internalorder      = "0000000000"
  region             = "europe"
  serviceprincipalid = "NA"
  repo               = "ZDP-AP_eVA_MS_MVP"
  support            = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
}

storage_accounts = {
  0 = {
    resourcetype             = "st"
    account_replication_type = "LRS"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_tier             = "Standard"
    rand_value               = "st01" # As mentioned at the start of the file.
    min_tls_version          = "TLS1_2"
  }
}

resource_groups = {
  0 = {
    location     = "Germany West Central"
    workload     = "management"
    resourcetype = "rg"
    rg_tags = {
      workload = "management"
    }
  }
  1 = {
    location     = "Germany West Central"
    workload     = "network"
    resourcetype = "rg"
    rg_tags = {
      workload = "network"
    }
  }
  2 = {
    location     = "Germany West Central"
    workload     = "logging"
    resourcetype = "rg"
    rg_tags = {
      workload = "logging"
    }
  }
  3 = {
    location     = "Germany West Central"
    workload     = "storage"
    resourcetype = "rg"
    rg_tags = {
      workload = "storage"
    }
  }
}

keyvault = {
  0 = {
    resourcetype                    = "kv"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    purge_protection_enabled        = true
    sku_name                        = "standard"
    rand_value                      = "kvtnpmgmtdmlz00" # Please check wiki
  }
}

virtual_networks = {
  0 = {
    resourcetype    = "vnet"
    subresourcetype = "snet"
    rand_value_vnet = "vnet01" # Please check wiki
    rand_value_snet = "snet01" # Please check wiki
  }
}

network_security_groups = {
  0 = {
    resourcetype = "nsg"
    rand_value   = "nsg01" # Please check wiki
  }
}

# pview = {
#   0 = {
#     resourcetype = "pview"
#     rand_value   = "pview01" # Please check wiki
#   }
# }

log_analytics = {
  0 = {
    resourcetype      = "log"
    subresourcetype   = "snet"
    address_space     = ["10.0.0.0/16"]
    sku_name          = "PerGB2018"
    rand_value        = "log01" # Please check wiki
    retention_in_days = 30
  }
}

private_endpoints = {
  0 = {
    name       = "pe"
    rand_value = "pe01" # Please check wiki
  }
}

eventhub = {
  0 = {
    resourcetype = "evh"
    rand_value   = "evhnpmgmt01" # Please check wiki
  }
}
eventhubnamespace = {
  0 = {
    resourcetype = "evhns"
    rand_value   = "evhnsnpmgmt01" # Please check wiki
  }
}
statabledeployment = 0
staqueuedeployment = 0