
variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "environmentlong" {
  type = string
}
variable "regionlong" {
  type = string
}
variable "landingzonetype" {
  type = string
}
variable "networking_filepath" {
  type = string
}
variable "platform" {
  type = string
}
variable "rsg_tags" {
  type = map(string)
}
variable "networking_sp_id" {
  type = string
}
variable "ars_tags" {
  type = map(any)
}
variable "hmac_key" {
  type = string
}


variable "resource_groups" {
  description = "Resource groups"
  type = map(object({
    location = string
    #name              = string
    workload     = string
    resourcetype = string
    rg_tags      = map(string)
  }))
}

#########################################
#Storage Account
#########################################

variable "storage_accounts" {
  description = "storageaccounts"
  type = map(object({
    account_tier             = string
    account_replication_type = string
    access_tier              = string
    account_kind             = string
    resourcetype             = string
    rand_value               = string
    min_tls_version          = string
  }))
}


variable "keyvault" {
  type = map(object({
    enabled_for_deployment          = bool
    enabled_for_disk_encryption     = bool
    enabled_for_template_deployment = bool
    purge_protection_enabled        = bool
    sku_name                        = string
    resourcetype                    = string
    rand_value                      = string
  }))
}



variable "virtual_networks" {
  type = map(object({
    resourcetype    = string
    subresourcetype = string
    rand_value_vnet = string
    rand_value_snet = string
  }))
}

############################################
# NSG Variables
###########################################
variable "network_security_groups" {
  description = "network security group"
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}

############################################
# Log Analytics Workspace
###########################################
variable "log_analytics" {
  type = map(object({
    resourcetype      = string
    subresourcetype   = string
    address_space     = list(string)
    sku_name          = string
    rand_value        = string
    retention_in_days = number
  }))
}

#############################################################
# Private Endpoint
#############################################################
variable "private_endpoints" {
  type = map(object({
    name       = string
    rand_value = string
  }))
}

#############################################################
# Event Hub
#############################################################
variable "eventhub" {
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}

#############################################################
# Event Hub Namespace
#############################################################
variable "eventhubnamespace" {
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}

variable "statabledeployment" {
  type = string
}
variable "staqueuedeployment" {
  type = string
}

variable "peering_subscriptionid" {
  type = string
}
variable "peering_clientid" {
  type = string
}
variable "peering_clientsecret" {
  type = string
}

variable "alldnssecretsaslist" {
  type = string
}

variable "connectivity_subscription_vnet_id" {
  type = string
}