productname     = "eva"
landingzonetype = "mgc"
regionlong      = "europe"
regionshort     = "gwc"

rsg_tags = {
  description         = "DMLZ Mgmt Prod resources"
  environment         = "mgmt-prod-connectivity"
  businessowner       = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  technicalcontact    = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  project             = "eva"
  provisioner         = "terraform"
  businessgroup       = "all"
  ContactEmailAddress = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com;jan-michael.matzkovits@zeiss.com"
}

ars_tags = {
  costcenter         = "000000"
  internalorder      = "0000000000"
  region             = "europe"
  serviceprincipalid = "NA"
  repo               = "ZDP-AP_eVA_MS_MVP"
  support            = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
}

resource_groups = {
  0 = {
    location     = "Germany West Central"
    workload     = "privatedns"
    resourcetype = "rg"
    rg_tags = {
      workload = "privatedns"
    }
  }
  1 = {
    location     = "Germany West Central"
    workload     = "network"
    resourcetype = "rg"
    rg_tags = {
      workload = "network"
    }
  }
}

keyvault = {
  0 = {
    resourcetype                    = "kv"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    purge_protection_enabled        = true
    sku_name                        = "standard"
    rand_value                      = "kvttest01" # Please check wiki
  }
}

private_dns_zones = {
  zone1 = {
    dns_zone_name        = "privatelink.vaultcore.azure.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsvault01" # Please check wiki
  }
  zone2 = {
    dns_zone_name        = "privatelink.purview.azure.com"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnspview02" # Please check wiki
  }
  zone3 = {
    dns_zone_name        = "privatelink.purviewstudio.azure.com"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnspviewstd03" # Please check wiki
  }
  zone4 = {
    dns_zone_name        = "privatelink.blob.core.windows.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsblob04" # Please check wiki
  }
  zone5 = {
    dns_zone_name        = "privatelink.file.core.windows.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsfile05" # Please check wiki
  }
  zone6 = {
    dns_zone_name        = "privatelink.azuresynapse.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnssyn06" # Please check wiki
  }
  zone7 = {
    dns_zone_name        = "privatelink.monitor.azure.com"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsmonitor01" # Please check wiki
  }
  zone8 = {
    dns_zone_name        = "privatelink.oms.opinsights.azure.com"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsmonitoroms01" # Please check wiki
  }
  zone9 = {
    dns_zone_name        = "privatelink.ods.opinsights.azure.com"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsmonitorods01" # Please check wiki
  }
  zone10 = {
    dns_zone_name        = "privatelink.agentsvc.azure-automation.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsmonitoragentsvc01" # Please check wiki
  }
  zone11 = {
    dns_zone_name        = "privatelink.api.azureml.ms"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "apiaml01" # Please check wiki
  }
  zone12 = {
    dns_zone_name        = "privatelink.notebooks.azure.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "notebooksaz01" # Please check wiki
  }
  zone13 = {
    dns_zone_name        = "privatelink.sql.azuresynapse.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "synapsesql01" # Please check wiki
  }
  zone14 = {
    dns_zone_name        = "privatelink.dev.azuresynapse.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "synapsedev01" # Please check wiki
  }
  zone15 = {
    dns_zone_name        = "privatelink.azurewebsites.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "webapps01" # Please check wiki
  }
  zone16 = {
    dns_zone_name        = "privatelink.queue.core.windows.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsqueue07" # Please check wiki
  }
  zone17 = {
    dns_zone_name        = "privatelink.table.core.windows.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnstable08" # Please check wiki
  }
}

virtual_networks = {
  0 = {
    resourcetype    = "vnet"
    subresourcetype = "snet"
    rand_value_vnet = "vnet01" # Please check wiki
    rand_value_snet = "snet01" # Please check wiki
  }
}

network_security_groups = {
  0 = {
    resourcetype = "nsg"
    rand_value   = "nsg01" # Please check wiki
  }
}

private_endpoints = {
  0 = {
    name       = "pe"
    rand_value = "pe01" # Please check wiki
  }
}
