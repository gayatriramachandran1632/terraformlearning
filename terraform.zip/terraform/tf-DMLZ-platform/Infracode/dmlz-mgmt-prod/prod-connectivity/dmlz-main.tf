//**********************************************************
//  Resource Group
//**********************************************************
module "resourcegroup" {
  source          = "../../../../tf-core-module/resource-group"
  resource_groups = var.resource_groups
  productname     = var.productname
  environmentlong = var.environmentlong
  landingzonetype = var.landingzonetype
  regionlong      = var.regionlong
  rsg_tags        = var.rsg_tags
}

//*********************************
//  Prvate DNS
//*********************************
module "dns" {
  source            = "../../../../tf-core-module/dns"
  private_dns_zones = var.private_dns_zones
  resourcegpname    = module.resourcegroup.rgname.0
  ars_tags          = var.ars_tags
  rgtags            = module.resourcegroup.rgtags.0
  environmentshort  = var.environmentshort
  hmac_key          = var.hmac_key
  productname       = var.productname
  regionshort       = var.regionshort
  vnet_id           = [for n in module.network.vnetid : n[0]][1]["id"]
  depends_on = [
    module.network,
    module.networksecuritygroup
  ]
}

//*********************************
//  Network
//*********************************
module "network" {
  source              = "../../../../tf-core-module/network"
  virtual_networks    = var.virtual_networks
  productname         = var.productname
  environmentshort    = var.environmentshort
  regionshort         = var.regionshort
  resourcegpname      = module.resourcegroup.rgname.1
  resourcelocation    = module.resourcegroup.rglocation.1
  ars_tags            = var.ars_tags
  rgtags              = module.resourcegroup.rgtags.1
  hmac_key            = var.hmac_key
  networking_filepath = var.networking_filepath
  platform            = var.platform
}

//*********************************
// Network Security Group
//*********************************

module "networksecuritygroup" {
  source                  = "../../../../tf-core-module/network-security-group"
  network_security_groups = var.network_security_groups
  productname             = var.productname
  environmentshort        = var.environmentshort
  regionshort             = var.regionshort
  resourcegpname          = module.resourcegroup.rgname.1
  resourcelocation        = module.resourcegroup.rglocation.1
  vnet_id                 = [for n in module.network.vnetid : n[0]][1]["id"]
  subnet_name             = "service"
  ars_tags                = var.ars_tags
  rgtags                  = module.resourcegroup.rgtags.1
  hmac_key                = var.hmac_key
  depends_on = [
    module.network
  ]
}
