//**********************************************************
//  Resource Group
//**********************************************************
module "resourcegroup" {
  source          = "../../../tf-core-module/resource-group"
  resource_groups = var.resource_groups
  productname     = var.productname
  environmentlong = var.environmentlong
  landingzonetype = var.landingzonetype
  regionlong      = var.regionlong
  rsg_tags        = var.rsg_tags
}

//*********************************
//  Keyvault
//*********************************
module "keyvault" {
  source              = "../../../tf-core-module/keyvault"
  keyvault            = var.keyvault
  productname         = var.productname
  environmentshort    = var.environmentshort
  regionshort         = var.regionshort
  resourcegpname      = module.resourcegroup.rgname.0
  resourcelocation    = module.resourcegroup.rglocation.0
  ars_tags            = var.ars_tags
  rgtags              = module.resourcegroup.rgtags.0
  hmac_key            = var.hmac_key
  pvtendpointrsg      = module.resourcegroup.rgname.2
  pvtendpointlocation = module.resourcegroup.rglocation.2
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  private_endpoints   = var.private_endpoints
  dns                 = [for n in module.dns["dns_zone_ids"] : n if can(regex("vaultcore", n))]
  depends_on = [
    module.network
  ]
  loganalyticsworkspace_id = module.loganalyticsworkspace.ana_id.0
}

//*********************************
//  Purview
//*********************************
module "purview" {
  source              = "../../../tf-core-module/purview"
  pview               = var.pview
  productname         = var.productname
  environmentshort    = var.environmentshort
  regionshort         = "we"
  resourcegpname      = module.resourcegroup.rgname.0
  resourcelocation    = "west europe"
  ars_tags            = var.ars_tags
  rgtags              = module.resourcegroup.rgtags.0
  hmac_key            = var.hmac_key
  pvtendpointrsg      = module.resourcegroup.rgname.2
  pvtendpointlocation = module.resourcegroup.rglocation.2
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  private_endpoints   = var.private_endpoints
  dns                 = [for n in module.dns["dns_zone_ids"] : n if can(regex("purview.azure|purviewstudio", n))]
}

//*********************************
//  Global DNS
//*********************************
module "dns" {
  source            = "../../../tf-core-module/dns"
  private_dns_zones = var.private_dns_zones
  resourcegpname    = module.resourcegroup.rgname.1
  ars_tags          = var.ars_tags
  rgtags            = module.resourcegroup.rgtags.1
  environmentshort  = var.environmentshort
  hmac_key          = var.hmac_key
  productname       = var.productname
  regionshort       = var.regionshort
  vnet_id           = [for n in module.network.vnetid : n[0]][1]["id"]
  depends_on = [
    module.network,
    module.networksecuritygroup
  ]
}

//*********************************
//  Network
//*********************************
module "network" {
  source              = "../../../tf-core-module/network"
  virtual_networks    = var.virtual_networks
  productname         = var.productname
  environmentshort    = var.environmentshort
  regionshort         = var.regionshort
  resourcegpname      = module.resourcegroup.rgname.2
  resourcelocation    = module.resourcegroup.rglocation.2
  ars_tags            = var.ars_tags
  rgtags              = module.resourcegroup.rgtags.2
  hmac_key            = var.hmac_key
  networking_filepath = var.networking_filepath
  platform            = var.platform
}

//*********************************
// Network Security Group
//*********************************

module "networksecuritygroup" {
  source                  = "../../../tf-core-module/network-security-group"
  network_security_groups = var.network_security_groups
  productname             = var.productname
  environmentshort        = var.environmentshort
  regionshort             = var.regionshort
  resourcegpname          = module.resourcegroup.rgname.2
  resourcelocation        = module.resourcegroup.rglocation.2
  vnet_id                 = [for n in module.network.vnetid : n[0]][1]["id"]
  subnet_name             = "service"
  ars_tags                = var.ars_tags
  rgtags                  = module.resourcegroup.rgtags.2
  hmac_key                = var.hmac_key
  depends_on = [
    module.network
  ]
}

//*********************************
// Consumption
//*********************************

module "synapse_private_link_hub" {
  source                   = "../../../tf-core-module/synapse-private-link"
  synapse_private_link_hub = var.synapse_private_link_hub
  productname              = var.productname
  environmentshort         = var.environmentshort
  regionshort              = var.regionshort
  resourcegpname           = module.resourcegroup.rgname.0
  resourcelocation         = module.resourcegroup.rglocation.0
  ars_tags                 = var.ars_tags
  rgtags                   = module.resourcegroup.rgtags.0
  hmac_key                 = var.hmac_key
  pvtendpointrsg           = module.resourcegroup.rgname.2
  pvtendpointlocation      = module.resourcegroup.rglocation.2
  vnet_id                  = [for n in module.network.vnetid : n[0]][1]["id"]
  private_endpoints        = var.private_endpoints
  dns                      = [for n in module.dns["dns_zone_ids"] : n if can(regex("azuresynapse", n))]
}

# //*********************************
# // Log Analytics
# //*********************************

module "loganalyticsworkspace" {
  source           = "../../../tf-core-module/log-analytics-workspace"
  log_analytics    = var.log_analytics
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.3
  resourcelocation = module.resourcegroup.rglocation.3
  ars_tags         = var.ars_tags
  rgtags           = module.resourcegroup.rgtags.3
  hmac_key         = var.hmac_key
}

# //*********************************
# // Application Insights
# //*********************************
module "applicationinsights" {
  source               = "../../../tf-core-module/application-insights"
  application_insights = var.application_insights
  productname          = var.productname
  environmentshort     = var.environmentshort
  regionshort          = var.regionshort
  resourcegpname       = module.resourcegroup.rgname.1
  resourcelocation     = module.resourcegroup.rglocation.1
  ars_tags             = var.ars_tags
  rgtags               = module.resourcegroup.rgtags.1
  hmac_key             = var.hmac_key
}
