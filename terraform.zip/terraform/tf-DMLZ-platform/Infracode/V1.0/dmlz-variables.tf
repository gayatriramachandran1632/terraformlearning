//**********************************************************
//  Common variables that are used in all resource's names
//**********************************************************
variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "environmentlong" {
  type = string
}
variable "regionlong" {
  type = string
}
variable "landingzonetype" {
  type = string
}
variable "networking_filepath" {
  type = string
}
variable "platform" {
  type = string
}
variable "rsg_tags" {
  type = map(string)
}

variable "ars_tags" {
  type = map(any)
}
variable "hmac_key" {
  type = string
}

//**********************************************************
//  Resource Group variables
//**********************************************************
variable "resource_groups" {
  description = "Resource groups"
  type = map(object({
    location = string
    #name              = string   
    workload     = string
    resourcetype = string
    rg_tags      = map(string)
  }))
}

//**********************************************************
//  Keyvault Variables
//**********************************************************
variable "keyvault" {
  type = map(object({
    enabled_for_deployment          = bool
    enabled_for_disk_encryption     = bool
    enabled_for_template_deployment = bool
    purge_protection_enabled        = bool
    sku_name                        = string
    resourcetype                    = string
    rand_value                      = string
  }))
}

//**********************************************************
//  Purview Variables
//**********************************************************
variable "pview" {
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}

################################################################
## Private DNS Zones variables
##############################################################
variable "private_dns_zones" {
  description = "Private DNS Zones"
  type = map(object({
    dns_zone_name        = string
    zone_exists          = bool
    registration_enabled = bool
    rand_value           = string
  }))
}


################################################################
## Virtual Network variables
##############################################################

variable "virtual_networks" {
  type = map(object({
    resourcetype    = string
    subresourcetype = string
    rand_value_vnet = string
    rand_value_snet = string
  }))
}

############################################
# NSG Variables
###########################################
variable "network_security_groups" {
  description = "network security group"
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}
############################################
# Firewall Variables
###########################################
variable "firewalls" {
  type = map(object({
    resourcetypefw              = string
    resourcetypevnet            = string
    resourcetypepip             = string
    address_space               = list(string)
    public_ip_allocation_method = string
    public_ip_sku               = string
    fw_sku                      = string
    fw_sku_name                 = string
    rand_value_pip              = string
    rand_value_firewall         = string
  }))
}
############################################
# Synapse Private Link
###########################################
variable "synapse_private_link_hub" {
  description = "synapse private link"
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}

############################################
# Log Analytics Workspace
###########################################
variable "log_analytics" {
  type = map(object({
    resourcetype      = string
    subresourcetype   = string
    address_space     = list(string)
    sku_name          = string
    rand_value        = string
    retention_in_days = number
  }))
}

#############################################################
# Private Endpoint
#############################################################
variable "private_endpoints" {
  type = map(object({
    name       = string
    rand_value = string
  }))
}

############################################
# Application Insights
###########################################
variable "application_insights" {
  type = map(object({
    application_type     = string
    retention_in_days    = number
    daily_data_cap_in_gb = number
    resourcetype         = string
    rand_value           = string
  }))
}
