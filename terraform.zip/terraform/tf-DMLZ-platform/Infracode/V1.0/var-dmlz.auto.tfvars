productname     = "eva"
landingzonetype = "dmlz"
regionlong      = "europe"
regionshort     = "gwc"

rsg_tags = {
  description         = "DMLZ resources"
  environment         = "dev"
  businessowner       = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  technicalcontact    = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  project             = "eva"
  provisioner         = "terraform"
  businessgroup       = "all"
  ContactEmailAddress = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com;jan-michael.matzkovits@zeiss.com"
}

ars_tags = {
  costcenter         = "000000"
  internalorder      = "0000000000"
  region             = "europe"
  serviceprincipalid = "NA"
  repo               = "ZDP-AP_eVA_MS_MVP"
  support            = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
}


resource_groups = {
  0 = {
    location     = "Germany West Central"
    workload     = "governance"
    resourcetype = "rg"
    rg_tags = {
      workload = "governance"
    }
  }
  1 = {
    location     = "Germany West Central"
    workload     = "privatedns"
    resourcetype = "rg"
    rg_tags = {
      workload = "privatedns"
    }
  }
  2 = {
    location     = "Germany West Central"
    workload     = "network"
    resourcetype = "rg"
    rg_tags = {
      workload = "network"
    }
  }
  3 = {
    location     = "Germany West Central"
    workload     = "logging"
    resourcetype = "rg"
    rg_tags = {
      workload = "logging"
    }
  }
}

keyvault = {
  0 = {
    resourcetype                    = "kv"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    purge_protection_enabled        = true
    sku_name                        = "standard"
    rand_value                      = "kvttest01" # Please check wiki
  }
}

private_dns_zones = {
  zone1 = {
    dns_zone_name        = "privatelink.vaultcore.azure.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsvault01" # Please check wiki
  }
  zone2 = {
    dns_zone_name        = "privatelink.purview.azure.com"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnspview02" # Please check wiki
  }
  zone3 = {
    dns_zone_name        = "privatelink.purviewstudio.azure.com"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnspviewstd03" # Please check wiki
  }
  zone4 = {
    dns_zone_name        = "privatelink.blob.core.windows.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsblob04" # Please check wiki
  }
  zone5 = {
    dns_zone_name        = "privatelink.file.core.windows.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsfile05" # Please check wiki
  }
  zone6 = {
    dns_zone_name        = "privatelink.azuresynapse.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnssyn06" # Please check wiki
  }
  zone7 = {
    dns_zone_name        = "privatelink.monitor.azure.com"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsmonitor01" # Please check wiki
  }
  zone8 = {
    dns_zone_name        = "privatelink.oms.opinsights.azure.com"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsmonitoroms01" # Please check wiki
  }
  zone9 = {
    dns_zone_name        = "privatelink.ods.opinsights.azure.com"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsmonitorods01" # Please check wiki
  }
  zone10 = {
    dns_zone_name        = "privatelink.agentsvc.azure-automation.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsmonitoragentsvc01" # Please check wiki
  }
}

virtual_networks = {
  0 = {
    resourcetype    = "vnet"
    subresourcetype = "snet"
    rand_value_vnet = "vnet01" # Please check wiki
    rand_value_snet = "snet01" # Please check wiki
  }
}

network_security_groups = {
  0 = {
    resourcetype = "nsg"
    rand_value   = "nsg01" # Please check wiki
  }
}

pview = {
  0 = {
    resourcetype = "pview"
    rand_value   = "pview01" # Please check wiki
  }
}

firewalls = {
  0 = {
    resourcetypefw              = "afw"
    resourcetypepip             = "pip"
    public_ip_allocation_method = "Static"
    public_ip_sku               = "Standard"
    fw_sku                      = "Standard"
    fw_sku_name                 = "AZFW_VNet"
    rand_value_pip              = "pip01"
    rand_value_firewall         = "afw01"
    resourcetypevnet            = "vnet"
    subresourcetype             = "snet"
    address_space               = ["10.0.0.0/16"]
    rand_value_vnet             = "vnet02" # Please check wiki
    rand_value_snet             = "snet02" # Please check wiki
  }
}

synapse_private_link_hub = {
  0 = {
    resourcetype = "synpl"
    rand_value   = "synpl01" # Please check wiki
  }
}

log_analytics = {
  0 = {
    resourcetype      = "log"
    subresourcetype   = "snet"
    address_space     = ["10.0.0.0/16"]
    sku_name          = "standard"
    rand_value        = "log01" # Please check wiki
    retention_in_days = 30
  }
}

private_endpoints = {
  0 = {
    name       = "pe"
    rand_value = "pe01" # Please check wiki
  }
}

application_insights = {
  0 = {
    application_type     = "web"
    retention_in_days    = 60
    daily_data_cap_in_gb = 10
    resourcetype         = "appi"
    rand_value           = "appi01" # Please check wiki
  }
}