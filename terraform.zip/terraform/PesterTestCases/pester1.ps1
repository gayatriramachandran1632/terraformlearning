#$userPassword = ConvertTo-SecureString -String "udS8Q~8rIzknkxjyLrumQP~dV_IU~3WHQCsjtaeK" -AsPlainText -Force
#$userCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList "ae3aa76d-63ec-41fb-878a-4da4e7995d54", $userPassword
#
#$Credential = New-Object  System.Management.Automation.PSCredential ( "e42c3f27-9f56-4e86-898e-fcbf68e66143", "udS8Q~8rIzknkxjyLrumQP~dV_IU~3WHQCsjtaeK")
#Connect-AzAccount  -serviceprincipal -TenantId "72f988bf-86f1-41af-91ab-2d7cd011db47" -Credential $userCredential
#
#
#Get-Azadgroup -DisplayName "securitygroupgy"

#BeforeDiscovery {    
#$azrglist = @{        
#Location = (Get-AzResourceGroup -Name "demorg").Location        
#}}    
#Describe "Validation: Approved Regions Deployment" -Tags CoreInfrastructure {    
#Context "_Resource Groups" {        
#it "Resource Group" -TestCases $azrglist {            
#$Location | Should -Be "eastus"         }    }}
#$setcontext = 
Set-AzContext -Subscription fd10c0eb-52aa-4f42-999b-1f3c60518d69
#$getcontext = Get-AzContext -Name $setcontext
BeforeDiscovery {
    # Testcases are hashtable-arrays
    $azrglist = Get-AzResourceGroup | ForEach-Object {
        @{
            Name     = $_.ResourceGroupName
            Location = $_.Location
        }
    }
    [System.Collections.ArrayList]$allowedRegions = @("eastus","eastus2","westus2","northeurope","centralus","westus","westeurope","centralindia","global")
    $azresourcelist = Get-Azresource | ForEach-Object {
        @{
            Name     = $_.ResourceGroupName
            Location = $_.Location
        }
    }
    $keyvaults =  Get-AzKeyVault | ForEach-Object {
        @{
            Name     = $_.VaultName 
            }  
                
        }
   $vaultdetails = Foreach ( $i in $keyvaults.Name) {
    $details = Get-Azkeyvault -VaultName $i
    $details.sku
    $details.EnablePurgeProtection
   }
}
#Describe "Validation: Approved Regions Deployment" -Tags CoreInfrastructure {
#    Context "_Resource Groups" {
#        # <> are used to reference a variable in a test case
#        it "Resource Group <ResourceGroupName> (<Location>) must be deployed in one of the regions approved by Zeiss" -TestCases $azrglist {
#            # Inside It, the hashtable keys (line5 and line6 become variables)       
#            $allowedRegions | Should -Contain $Location
#            #Write-Host $Location
#        }
#    }
#}
#
#Describe "Validation: Approved Regions Deployment of resources" -Tags CoreInfrastructure {
#    Context "_Resource Groups" {
#        # <> are used to reference a variable in a test case
#        it "Resources <ResourceGroupName> (<Location>) must be deployed in one of the regions approved by Zeiss" -TestCases $azresourcelist {
#            # Inside It, the hashtable keys (line5 and line6 become variables)       
#            $allowedRegions | Should -Contain $Location
#            #Write-Host $Location
#        }
#    }
#}

Describe "Validation: Azure Key Vault" -Tags CoreInfrastructure {

	
	Context "_Checking Subscription for Key-Vault" {
		It "$($getcontext).Subscription.Name)" -TestCases $keyvaults {
			$keyvaults.Count | Should -Not -Be 0
#write-Host ($details.sku)
		}
	}


#	Context "_Key Vault Soft Delete must be enabled" {
#		foreach ($kv in $keyvaults)
#		{
#			$kvtemp = Get-AzKeyVault -VaultName $kv.vaultname
#			It "The key vault $($kvtemp.vaultname) must be configured with soft deletion" {
#				$kvtemp.EnableSoftDelete | Should -Be $true
#			}
#
#			if (($kvtemp.SoftDeleteRetentionInDays -ne $null) -and ($kvtemp.EnableSoftDelete -eq $true))
#			{
#				It "The key vault $($kvtemp.vaultname) must be configured with soft deletion of 90 days" {
#					$kvtemp.SoftDeleteRetentionInDays | Should -Be 90
#				}
#			}
#		}
#	}

	Context "_Checking Key Vault purge protection must be enabled" {
		
			
			It "The key vault $($kvtemp.vaultname) must be configured with purge protection" -TestCases $vaultdetails {
				$details.EnablePurgeProtection | Should -Be $true
			
		}
	}

	Context "_Key Vault SKU must be premium" {
		
			
			It "The key vault $($vaultdetails.vaultname) must be deployed with standard SKU" -TestCases $vaultdetails{
				$details.sku | Should -Be 'Premium'
			
		}
	}
}
# End - Key Vault Tests