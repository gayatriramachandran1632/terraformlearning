
output "subres" {
  value = [for n in module.sub-resource-keyvault : n][0]
}