output "subres" {
  value = [for n in module.sub-resource-kvt : n][0]["subres"]
}