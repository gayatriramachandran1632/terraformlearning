#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "hmac_key" {
  type = string
}
variable "ars_tags" {
  type = map(string)
}
############################
# keyvault
############################
variable "keyvault" {
  type = map(object({
    enabled_for_deployment          = bool
    enabled_for_disk_encryption     = bool
    enabled_for_template_deployment = bool
    purge_protection_enabled        = bool
    sku_name                        = string
    resourcetype                    = string
    rand_value                      = string
  }))
}