locals {
  id = 0
  secret_obj = flatten([
    for val in var.secretvalue : {
      id           = local.id + 1
      secret_value = val
    }
  ])
  obj = [for n in local.secret_obj : n]
}

//**********************************************************
//      Upload the Password to Keyvault
//**********************************************************
resource "azurerm_key_vault_secret" "vault" {
  for_each        = { for x, y in local.obj : x => { id = y.id, secret_value = tostring(y.secret_value) } }
  name            = var.isService == true ? var.serviceName : replace(split("/", each.value["secret_value"])[8], ".", "-")
  value           = each.value["secret_value"]
  key_vault_id    = var.keyvault_id
  content_type    = "text/plain"
  expiration_date = timeadd(timestamp(), "9640h")
  lifecycle {
    ignore_changes = [
      expiration_date
    ]
  }
}