variable "keyvault_id" {
  type = string
}

variable "secretvalue" {
  type = list(string)
}
variable "isService" {
  type    = bool
  default = false
}
variable "serviceName" {
  type    = string
  default = "default"
}