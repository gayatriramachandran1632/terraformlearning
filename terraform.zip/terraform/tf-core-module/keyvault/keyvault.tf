//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

locals {
  subresource_names = ["vault"]
}

//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "keyvault_unique_suffix" {
  for_each = var.keyvault
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//      Retrieving current client config data
//**********************************************************
data "azurerm_client_config" "current" {}

//**********************************************************
//      Key Vault creation
//**********************************************************
# NOTE: purge_protection_enabled and soft_delete_retention_days is active - the keyvault cannot be deleted permanently

resource "azurerm_key_vault" "kvt" {
  for_each                        = var.keyvault
  name                            = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.keyvault_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name             = var.resourcegpname
  location                        = var.resourcelocation
  tenant_id                       = data.azurerm_client_config.current.tenant_id
  enabled_for_deployment          = each.value["enabled_for_deployment"]
  enabled_for_disk_encryption     = each.value["enabled_for_disk_encryption"]
  enabled_for_template_deployment = each.value["enabled_for_template_deployment"]
  purge_protection_enabled        = each.value["purge_protection_enabled"]
  sku_name                        = each.value["sku_name"]

  soft_delete_retention_days = 30
  network_acls {
    bypass         = "AzureServices"
    default_action = "Allow"
    #virtual_network_subnet_ids = [join("", [var.vnet_id, "/subnets/service"])]
    #ip_rules = ["51.138.48.35"]
  }
  access_policy {
    tenant_id = data.azurerm_client_config.current.tenant_id
    object_id = data.azurerm_client_config.current.object_id

    key_permissions = [
      "Get", "List", "Update", "Create", "Delete", "Recover"
    ]

    secret_permissions = [
      "Get", "List", "Delete", "Recover", "Backup", "Set",
    ]
  }
  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags, access_policy, tenant_id, access_policy
    ]
  }
}


#
#//**********************************************************
#//  Azure Monitor Diagnostic Categories - keyvault
#//**********************************************************
#data "azurerm_monitor_diagnostic_categories" "kvt" {
#  for_each    = var.keyvault
#  resource_id = azurerm_key_vault.kvt[each.key].id
#}
#
#//**********************************************************
#//  Azure Monitor Diagnostic Setting
#//**********************************************************
#resource "azurerm_monitor_diagnostic_setting" "kvt_diagonistics" {
#  for_each                   = var.keyvault
#  name                       = "${azurerm_key_vault.kvt[each.key].name}-diagnostics"
#  target_resource_id         = azurerm_key_vault.kvt[each.key].id
#  log_analytics_workspace_id = var.loganalyticsworkspace_id
#
#  dynamic "log" {
#    for_each = data.azurerm_monitor_diagnostic_categories.kvt[each.key].logs
#    content {
#      category = log.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 30
#      }
#    }
#  }
#
#  dynamic "metric" {
#    for_each = data.azurerm_monitor_diagnostic_categories.kvt[each.key].metrics
#    content {
#      category = metric.value
#      enabled  = false
#
#      retention_policy {
#        enabled = true
#        days    = 15
#      }
#    }
#  }
#}
