# #############################################################################
# # OUTPUTS Key Vault
# #############################################################################

##output "key_vault_id" {
##  value       = values(azurerm_key_vault.this).*.id
##}

##output "key_vault_name" {

## value  = values(azurerm_key_vault.this).*.name
#}

output "key_vault_id" {
  value = [for x in azurerm_key_vault.kvt : x.id]
}

output "key_vault_name" {
  value = [for x in azurerm_key_vault.kvt : x.name]
}



