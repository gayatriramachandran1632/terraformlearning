variable "keyvault_id" {
  type = string
}
variable "managed_id" {
  type    = string
  default = null
}
variable "resourcegpname" {
  type = string
}
