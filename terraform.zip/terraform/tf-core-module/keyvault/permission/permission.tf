//******************************************************
//  Module to provide KeyVault permissions
//  This gives READ and GET secret access to resource
//******************************************************

# NOTE:  data function is used to get data from already available resources
data "azurerm_subscription" "primary" {}

data "azurerm_client_config" "current" {}

//*******************************************
//  Key Vault assign permissions to resource
//*******************************************
# NOTE: Managed_id is object ID of resource

resource "azurerm_key_vault_access_policy" "keyvaultpolicy" {
  key_vault_id = var.keyvault_id
  tenant_id    = data.azurerm_client_config.current.tenant_id
  object_id    = var.managed_id

  secret_permissions = [
    "Get",
    "List"
  ]
}