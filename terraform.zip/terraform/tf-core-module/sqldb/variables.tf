#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "sqldb" {
  type = map(object({
    resourcetype         = string
    max_size_gb          = number
    sku_name             = string
    storage_account_type = string
    rand_value           = string
  }))
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "sqlserverid" {
  type = string
}
variable "landingzonetype" {
  type = string
}

