//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}


//**********************************************************
//   HMAC Key
//**********************************************************
resource "random_id" "database_unique_suffix" {
  for_each = var.sqldb
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//   SQL DB
//**********************************************************
resource "azurerm_mssql_database" "sqldb" {
  for_each             = var.sqldb
  name                 = "${var.productname}-${var.environmentshort}-${var.regionshort}-${var.landingzonetype}-${each.value.resourcetype}-${substr(random_id.database_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  server_id            = var.sqlserverid
  storage_account_type = each.value["storage_account_type"]
  max_size_gb          = each.value["max_size_gb"]
  sku_name             = each.value["sku_name"]


  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}
