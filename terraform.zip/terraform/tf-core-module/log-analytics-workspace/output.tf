output "ana_loc" {
  description = "The Azure region"
  value       = values(azurerm_log_analytics_workspace.loganalyticscommon).*.location
}
output "ana_name" {
  description = "Log Analytics Workspace name"
  value       = values(azurerm_log_analytics_workspace.loganalyticscommon).*.name
}
output "ana_id" {
  description = "Log Analytics Workspace id"
  value       = values(azurerm_log_analytics_workspace.loganalyticscommon).*.id
}