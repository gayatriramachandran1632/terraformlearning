#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}

variable "environmentshort" {
  type = string
}

variable "regionshort" {
  type = string
}

variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}

variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}

variable "hmac_key" {
  type = string
}

variable "log_analytics" {
  type = map(object({
    resourcetype      = string
    subresourcetype   = string
    address_space     = list(string)
    sku_name          = string
    rand_value        = string
    retention_in_days = number
  }))
}