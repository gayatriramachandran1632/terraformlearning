//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "analytics_resource_unique_suffix" {
  for_each = var.log_analytics
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//      Log Analytics
//**********************************************************

resource "azurerm_log_analytics_workspace" "loganalyticscommon" {
  for_each            = var.log_analytics
  name                = "${var.productname}${var.environmentshort}${var.regionshort}${each.value.resourcetype}${substr(random_id.analytics_resource_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  location            = var.resourcelocation
  resource_group_name = var.resourcegpname
  sku                 = each.value["sku_name"]
  retention_in_days   = each.value["retention_in_days"]

  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}
