//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "firewalls_unique_suffix" {
  for_each = var.firewalls
  keepers = {
    hmac   = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value_firewall"]}")
    subnet = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value_pip"]}")
  }
  byte_length = 4
}

//**********************************************************
//      Azure Firewall and PIP
//**********************************************************
resource "azurerm_public_ip" "pip_fw" {
  for_each            = var.firewalls
  name                = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetypepip}-${substr(random_id.firewalls_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  location            = var.resourcelocation
  resource_group_name = var.resourcegpname
  allocation_method   = each.value.public_ip_allocation_method
  sku                 = each.value.public_ip_sku
  tags                = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

resource "azurerm_firewall" "fw" {
  for_each            = var.firewalls
  name                = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetypefw}-${substr(random_id.firewalls_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  location            = var.resourcelocation
  resource_group_name = var.resourcegpname
  tags                = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  sku_tier            = each.value.fw_sku
  sku_name            = each.value.fw_sku_name
  ip_configuration {
    name                 = "AzureFirewallSubnet"
    subnet_id            = var.subnetid
    public_ip_address_id = azurerm_public_ip.pip_fw[each.key].id
  }
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}