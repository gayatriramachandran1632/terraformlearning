#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "subnetid" {
  type = string
}
variable "firewalls" {
  type = map(object({
    resourcetypefw              = string
    resourcetypevnet            = string
    resourcetypepip             = string
    address_space               = list(string)
    public_ip_allocation_method = string
    public_ip_sku               = string
    fw_sku                      = string
    fw_sku_name                 = string
    rand_value_pip              = string
    rand_value_firewall         = string
  }))
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}

