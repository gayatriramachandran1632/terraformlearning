//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "eventgrid_unique_suffix" {
  for_each = var.eventgrid
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//      Storage Queue
//**********************************************************
resource "azurerm_storage_queue" "storagequeue" {
  for_each             = var.queue
  name                 = each.value["name"]
  storage_account_name = var.storage_account_name
}

//**********************************************************
//      Resource for event grid subscription
//**********************************************************
resource "azurerm_eventgrid_event_subscription" "eventgridsubscription" {
  for_each = var.eventgrid
  name     = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.eventgrid_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  scope    = var.rgid

  storage_queue_endpoint {
    storage_account_id = var.storage_account_id
    queue_name         = azurerm_storage_queue.storagequeue[each.value["queue_name"]].name
  }

  depends_on = [
    azurerm_storage_queue.storagequeue
  ]
}