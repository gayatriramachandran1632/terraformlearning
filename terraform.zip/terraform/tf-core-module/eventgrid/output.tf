output "qa_name" {
  value = values(azurerm_storage_queue.storagequeue).*.name
}

output "egrid" {
  value = values(azurerm_eventgrid_event_subscription.eventgridsubscription).*.name
}