#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rgid" {
  type = string
}

variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}

variable "storage_account_name" {
  type = string
}

variable "storage_account_id" {
  type = string
}
variable "queue" {
  type = map(object({
    name                 = string
    storage_account_name = string
    rand_value           = string
  }))
}

variable "eventgrid" {
  type = map(object({
    queue_name   = string
    resourcetype = string
    rand_value   = string
  }))
}