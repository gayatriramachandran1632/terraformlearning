//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}


//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "datafactory_unique_suffix" {
  for_each = var.datafactory
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//      Datafactory
//**********************************************************
# NOTE: Managed Identity is active - it can be used to give access to storage or databricks or synapse etc

resource "azurerm_data_factory" "datafactory" {
  for_each = var.datafactory
  #provider = azurerm.Personalaccount
  name                            = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.datafactory_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name             = var.resourcegpname
  location                        = var.resourcelocation
  public_network_enabled          = false
  managed_virtual_network_enabled = true

  identity {
    type = "SystemAssigned"
  }
  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

//**********************************************************
//  Azure Monitor Diagnostic Categories - datafactory
//**********************************************************
data "azurerm_monitor_diagnostic_categories" "datafactory" {
  for_each    = var.datafactory
  resource_id = azurerm_data_factory.datafactory[each.key].id
}

#
#//**********************************************************
#//  Azure Monitor Diagnostic Setting
#//**********************************************************
#resource "azurerm_monitor_diagnostic_setting" "datafactory_diagonistics" {
#  for_each                   = var.datafactory
#  name                       = "${azurerm_data_factory.datafactory[each.key].name}-diagnostics"
#  target_resource_id         = azurerm_data_factory.datafactory[each.key].id
#  log_analytics_workspace_id = var.loganalyticsworkspace_id
#
#  dynamic "log" {
#    for_each = data.azurerm_monitor_diagnostic_categories.datafactory[each.key].logs
#    content {
#      category = log.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 30
#      }
#    }
#  }
#
#  dynamic "metric" {
#    for_each = data.azurerm_monitor_diagnostic_categories.datafactory[each.key].metrics
#    content {
#      category = metric.value
#      enabled  = false
#
#      retention_policy {
#        enabled = true
#        days    = 15
#      }
#    }
#  }
#}
