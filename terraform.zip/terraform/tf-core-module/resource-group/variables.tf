#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentlong" {
  type = string
}
variable "regionlong" {
  type = string
}
variable "landingzonetype" {
  type = string
}

variable "rsg_tags" {
  type        = map(any)
  description = "Map of Default Tags"
}

#############################################################
## Resource Group variables
#############################################################
variable "resource_groups" {
  description = "Resource groups"
  type = map(object({
    resourcetype = string
    workload     = string
    rg_tags      = map(string)
  }))
}
variable "deploymentregion" {
  type = string
}
