output "rgname" {
  value = values(azurerm_resource_group.rg).*.name
}

output "rglocation" {
  value = values(azurerm_resource_group.rg).*.location
}

output "rgtags" {
  value = values(azurerm_resource_group.rg).*.tags
}

output "rgid" {
  value = values(azurerm_resource_group.rg).*.id
}
    