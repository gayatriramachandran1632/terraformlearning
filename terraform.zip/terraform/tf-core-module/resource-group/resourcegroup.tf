//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

//**********************************************************
//      Resource Group
//**********************************************************
resource "azurerm_resource_group" "rg" {
  #provider = azurerm.Personalaccount
  for_each = var.resource_groups
  name     = "${var.productname}-${var.environmentlong}-${var.landingzonetype}-${each.value.resourcetype}-${var.regionlong}-${each.value.workload}"
  location = var.deploymentregion

  tags = merge(var.rsg_tags, each.value["rg_tags"], { serviceprincipalid = data.azurerm_client_config.config.object_id })

  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}
/*

/*/
/**********************************************************
// Resource Group - locks
// CanNotDelete resource lock level is applied at resource
// group level. CanNotDelete means authorized users can read
// and modify a resource, but they can't delete it.
// All resources under the resource group will automatically
// inherit this lock.
/*/
/**********************************************************
resource "azurerm_management_lock" "rglock" {
  for_each   = var.resource_groups
  name       = "${azurerm_resource_group.rg[each.key].name}-locks"
  scope      = azurerm_resource_group.rg[each.key].id
  lock_level = "CanNotDelete"
  notes      = "This Resource Group cannot be deleted"
}*/
