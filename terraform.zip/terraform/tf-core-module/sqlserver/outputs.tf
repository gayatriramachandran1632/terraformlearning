output "sqlserverid" {
  value = values(azurerm_mssql_server.sqlserver).*.id
}