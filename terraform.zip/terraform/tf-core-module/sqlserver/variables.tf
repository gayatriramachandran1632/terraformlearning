#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "sqlserver" {
  type = map(object({
    resourcetype                  = string
    public_network_access_enabled = bool
    rand_value                    = string
  }))

}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
# variable "loganalyticsworkspace_id" {
#   type = string  
# }
variable "keyvault_id" {
  type = string
}