//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}


//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "sqlserver_unique_suffix" {
  for_each = var.sqlserver
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//*****************************************************************************
//          Random string for SQL server username
//*****************************************************************************
resource "random_string" "username" {
  for_each = var.sqlserver
  keepers = {
    refid = random_id.sqlserver_unique_suffix[each.key].keepers.hmac
  }
  length  = 16
  special = false
}

//*****************************************************************************
//          Random password for SQL server password
//*****************************************************************************
resource "random_password" "password" {
  for_each = var.sqlserver
  keepers = {
    refid = random_id.sqlserver_unique_suffix[each.key].keepers.hmac
  }
  length           = 16
  override_special = "!#$%"
  special          = true
}

//**********************************************************
//             SQL Server
//**********************************************************
resource "azurerm_mssql_server" "sqlserver" {
  for_each                      = var.sqlserver
  name                          = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.sqlserver_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name           = var.resourcegpname
  location                      = var.resourcelocation
  version                       = "12.0"
  administrator_login           = random_string.username[each.key].result
  administrator_login_password  = random_password.password[each.key].result
  public_network_access_enabled = each.value["public_network_access_enabled"]
  minimum_tls_version           = "1.2"

  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

//**********************************************************
//            Add Keyvault secret
//**********************************************************
resource "azurerm_key_vault_secret" "sqlusername" {
  for_each        = var.sqlserver
  name            = "${azurerm_mssql_server.sqlserver[each.key].name}-username"
  value           = random_string.username[each.key].result
  key_vault_id    = var.keyvault_id
  content_type    = "User name for sql server ${azurerm_mssql_server.sqlserver[each.key].name}"
  expiration_date = timeadd(timestamp(), "8760h")

  lifecycle {
    ignore_changes = [
      expiration_date
    ]
  }
}

//**********************************************************
//            Add Keyvault secret
//**********************************************************
resource "azurerm_key_vault_secret" "sqlpassword" {
  for_each        = var.sqlserver
  name            = "${azurerm_mssql_server.sqlserver[each.key].name}-password"
  value           = random_password.password[each.key].result
  key_vault_id    = var.keyvault_id
  content_type    = "Password for the sql server ${azurerm_mssql_server.sqlserver[each.key].name}"
  expiration_date = timeadd(timestamp(), "8760h")

  lifecycle {
    ignore_changes = [
      expiration_date
    ]
  }
}

#//**********************************************************
#//  Azure Monitor Diagnostic Categories - sqlserver
#//**********************************************************
#data "azurerm_monitor_diagnostic_categories" "sqlserver" {
#  for_each    = var.sqlserver
#  resource_id = azurerm_mssql_server.sqlserver[each.key].id
#}
#
#//**********************************************************
#//  Azure Monitor Diagnostic Setting
#//**********************************************************
#resource "azurerm_monitor_diagnostic_setting" "sqlserver_diagonistics" {
#  for_each                   = var.sqlserver
#  name                       = "${azurerm_mssql_server.sqlserver[each.key].name}-diagnostics"
#  target_resource_id         = azurerm_mssql_server.sqlserver[each.key].id
#  log_analytics_workspace_id = var.loganalyticsworkspace_id
#
#  dynamic "log" {
#    for_each = data.azurerm_monitor_diagnostic_categories.sqlserver[each.key].logs
#    content {
#      category = log.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 30
#      }
#    }
#  }
#
#  dynamic "metric" {
#    for_each = data.azurerm_monitor_diagnostic_categories.sqlserver[each.key].metrics
#    content {
#      category = metric.value
#      enabled  = false
#
#      retention_policy {
#        enabled = true
#        days    = 15
#      }
#    }
#  }
#}
