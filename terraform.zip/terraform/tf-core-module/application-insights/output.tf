output "ai_id" {
  value = values(azurerm_application_insights.appinsights).*.id
}
output "ai_name" {
  value = values(azurerm_application_insights.appinsights).*.name
}
output "key" {
  value = values(azurerm_application_insights.appinsights).*.instrumentation_key
}