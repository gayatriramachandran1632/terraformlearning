#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "loganalyticsworkspaceid" {
  type = string
}
variable "application_insights" {
  type = map(object({
    application_type     = string
    retention_in_days    = number
    daily_data_cap_in_gb = number
    resourcetype         = string
    rand_value           = string
  }))
}

variable "hmac_key" {
  type = string
}

variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
