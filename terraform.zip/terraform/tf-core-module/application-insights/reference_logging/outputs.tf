output "appsinsights" {
  value = data.azurerm_resources.dest_app_ins
}
output "application_insights_instrumentation_key" {
  value = data.azurerm_application_insights.get_app_ins.instrumentation_key
}