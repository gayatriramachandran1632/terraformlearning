data "azurerm_resources" "dest_app_ins" {
  provider            = azurerm.destination
  type                = "Microsoft.Insights/components"
  resource_group_name = "${var.productname}-${var.dest_environmentlong}-${var.dest_landingzonetype}-rg-${var.regionlong}-logging"
  required_tags = {
    "project" = var.dest_vnet_required_tags
  }
}
data "azurerm_application_insights" "get_app_ins" {
  provider            = azurerm.destination
  name                = data.azurerm_resources.dest_app_ins.resources[0].name
  resource_group_name = data.azurerm_resources.dest_app_ins.resource_group_name
}

