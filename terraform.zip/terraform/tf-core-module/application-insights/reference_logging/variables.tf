variable "regionlong" {
  type = string
}
variable "productname" {
  type = string
}
variable "dest_vnet_required_tags" {
  type = string
}
variable "dest_landingzonetype" {
  type = string
}
variable "dest_environmentlong" {
  type = string
}
