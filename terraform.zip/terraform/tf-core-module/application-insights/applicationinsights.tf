//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "application_insights_unique_suffix" {
  for_each = var.application_insights
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//      Application Insights
//**********************************************************
# NOTE 1: retention_in_days - number of days the logs are retained
# NOTE 2: daily_data_cap_in_gb - daily data volume cap in GB

resource "azurerm_application_insights" "appinsights" {
  for_each            = var.application_insights
  name                = "${var.productname}-${var.environmentshort}-${var.regionshort}-appi-${substr(random_id.application_insights_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  location            = var.resourcelocation
  resource_group_name = var.resourcegpname
  workspace_id        = var.loganalyticsworkspaceid

  application_type     = each.value["application_type"]
  retention_in_days    = each.value["retention_in_days"]
  daily_data_cap_in_gb = each.value["daily_data_cap_in_gb"]
  tags                 = merge(var.rgtags, var.ars_tags, { serviceprincipalid = "${data.azurerm_client_config.config.object_id}" })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

resource "azurerm_application_insights_workbook" "example" {
  for_each            = var.application_insights
  resource_group_name = var.resourcegpname
  location            = var.resourcelocation
  name                = "${substr(random_id.application_insights_unique_suffix[each.key].keepers.hmac, 0, 8)}-${substr(random_id.application_insights_unique_suffix[each.key].keepers.hmac, 0, 4)}-${substr(random_id.application_insights_unique_suffix[each.key].keepers.hmac, 2, 4)}-${substr(random_id.application_insights_unique_suffix[each.key].keepers.hmac, 1, 4)}-${substr(random_id.application_insights_unique_suffix[each.key].keepers.hmac, 0, 12)}" #random_uuid.random_uid.0.id
  display_name        = "${var.productname}-${var.environmentshort}-${var.regionshort}-wbk-${substr(random_id.application_insights_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  data_json = jsonencode({
    "version" = "Notebook/1.0"
  })

  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = "${data.azurerm_client_config.config.object_id}" })
  lifecycle {
    ignore_changes = [
      tags, data_json
    ]
  }
}