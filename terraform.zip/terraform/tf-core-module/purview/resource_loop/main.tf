locals {
  id = 0
  secret_obj = flatten([
    for val in var.name : {
      id           = local.id + 1
      secret_value = val
    }
  ])
  obj = [for n in local.secret_obj : n]
}

//*********************************
//  loop over subresource names
//*********************************
module "sub-resource-purview" {
  source              = "../sub-resource-names"
  for_each            = { for x, y in local.obj : x => { id = y.id, secret_value = tostring(y.secret_value) } }
  subresource_names   = ["account", "portal"]
  name                = split("/", each.value["secret_value"])[8]
  hmac                = var.hmac
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = var.vnet_id
  hmac_key            = var.hmac_key
  resource_name       = split("/", each.value["secret_value"])[4]
  resource_id         = each.value["secret_value"]
  environmentshort    = var.environmentshort
  dns                 = var.dns
  rg_location         = var.rg_location
  rg_name             = var.rg_name
  pvtendpointlocation = var.pvtendpointlocation
  pvtendpointrsg      = var.pvtendpointrsg
  providers = {
    azurerm.destination = azurerm.destination
  }
}