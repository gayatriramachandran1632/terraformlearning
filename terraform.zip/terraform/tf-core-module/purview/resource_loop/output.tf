
output "subres" {
  value = [for n in module.sub-resource-purview : n]
}