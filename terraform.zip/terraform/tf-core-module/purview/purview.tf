//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "pview_unique_suffix" {
  for_each = var.pview
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}
//**********************************************************
//      Azure Purview.
//**********************************************************
# This core module creates a Purview account which is used to access the Purview Governance portal.
# NOTE: Managed Identity is active - it can be used to give access to storage etc

resource "azurerm_purview_account" "pview" {
  for_each               = var.pview
  name                   = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value["resourcetype"]}-${substr(random_id.pview_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name    = var.resourcegpname
  location               = var.resourcelocation
  public_network_enabled = false

  managed_resource_group_name = "${var.productname}-${var.environmentshort}-${var.regionshort}-mg-${each.value["resourcetype"]}-${substr(random_id.pview_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  tags                        = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  identity {
    type = "SystemAssigned"
  }
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}