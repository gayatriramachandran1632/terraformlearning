output "pview_acc_name" {
  value = [for x in azurerm_purview_account.pview : x.name]
}
output "pview_acc_id" {
  value = [for x in azurerm_purview_account.pview : x.id]
}
output "pview" {
  value = [for x in azurerm_purview_account.pview : x]
}