output "eventhub" {
  value = values(azurerm_eventhub_namespace.namespace).*.name
}