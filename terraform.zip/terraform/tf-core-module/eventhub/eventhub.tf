//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

locals {
  subresource_names = ["Microsoft.EventHub/namespaces"]
}
//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "eventhub_unique_suffix" {
  for_each = var.eventhub
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//      Event Hub Namespace
//**********************************************************

resource "azurerm_eventhub_namespace" "namespace" {
  for_each            = var.eventhubnamespace
  name                = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.eventhub_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  location            = var.resourcelocation
  resource_group_name = var.resourcegpname
  sku                 = "Standard"
  capacity            = 1

  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

//**********************************************************
//      Event Hub
//**********************************************************
resource "azurerm_eventhub" "eventhub" {
  for_each            = var.eventhub
  name                = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.eventhub_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name = var.resourcegpname

  message_retention = 1
  namespace_name    = azurerm_eventhub_namespace.namespace[each.key].name
  partition_count   = 1
}
