//*********************************
//  loop over subresource names
//*********************************
module "sub-resource-storage" {
  source            = "../../network/private-endpoint"
  for_each          = { for n in var.subresource_names : n => n }
  subresource_names = each.key
  name              = var.name
  hmac              = var.hmac
  private_endpoints = var.private_endpoints
  productname       = var.productname
  regionshort       = var.regionshort
  vnet_id           = var.vnet_id
  hmac_key          = var.hmac_key
  resource_name     = var.resource_name
  resource_id       = var.resource_id
  environmentshort  = var.environmentshort
  subnet_name       = "Service"
  dns               = [for n in var.dns : n][0]
  rg_location       = var.rg_location
  rg_name           = var.rg_name
  providers = {
    azurerm.destination = azurerm.destination
  }
}