output "subres" {
  value = flatten([for n in module.sub-resource-names : n][0]["subres"])
}