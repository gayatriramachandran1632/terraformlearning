//*********************************************************
//   Client Config
//*********************************************************

# NOTE:  data function is used to get data from already available resources
data "azurerm_client_config" "config" {}
data "azurerm_subscription" "primary" {}

locals {
  subresource_names = ["SQL", "SqlOnDemand", "Dev"]
}
//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "synapse_workspace_unique_suffix" {
  for_each = var.synapse_workspace
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

resource "azurerm_storage_data_lake_gen2_filesystem" "fsdeploy" {
  name               = var.adlsfilesystems
  storage_account_id = var.storage_data_lake_id
}


//*****************************************************************************
//          Random string for Synapse workspace username
//*****************************************************************************
resource "random_string" "username" {
  for_each = var.synapse_workspace
  keepers = {
    refid = random_id.synapse_workspace_unique_suffix[each.key].keepers.hmac
  }
  length  = 16
  special = false
}

//*****************************************************************************
//          Random password for Synapse worskpace password
//*****************************************************************************
resource "random_password" "password" {
  for_each = var.synapse_workspace
  keepers = {
    refid = random_id.synapse_workspace_unique_suffix[each.key].keepers.hmac
  }
  length           = 16
  override_special = "!#$%"
  special          = true
}

//**********************************************************
//      Synapse Analytics Workspace
//**********************************************************
# NOTE: Managed Identity is active - it can be used to give access to storage etc

resource "azurerm_synapse_workspace" "synw" {
  for_each                             = var.synapse_workspace
  name                                 = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value["resourcetype"]}-${substr(random_id.synapse_workspace_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name                  = var.resourcegpname
  location                             = var.resourcelocation
  sql_administrator_login              = random_string.username[each.key].result
  sql_administrator_login_password     = random_password.password[each.key].result
  storage_data_lake_gen2_filesystem_id = azurerm_storage_data_lake_gen2_filesystem.fsdeploy.id
  managed_virtual_network_enabled      = true
  data_exfiltration_protection_enabled = true
  public_network_access_enabled        = false
  managed_resource_group_name          = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value["resourcetype"]}-mg-${substr(random_id.synapse_workspace_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  identity {
    type = "SystemAssigned"
  }
  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}


//**********************************************************
//            Add Keyvault secret
//**********************************************************
resource "azurerm_key_vault_secret" "sqlusername" {
  for_each        = var.synapse_workspace
  name            = "${azurerm_synapse_workspace.synw[each.key].name}-username"
  value           = random_string.username[each.key].result
  key_vault_id    = var.keyvault_id
  content_type    = "User name for Synapse workspace ${azurerm_synapse_workspace.synw[each.key].name}"
  expiration_date = timeadd(timestamp(), "8760h")

  lifecycle {
    ignore_changes = [
      expiration_date
    ]
  }
}

//**********************************************************
//            Add Keyvault secret
//**********************************************************
resource "azurerm_key_vault_secret" "sqlpassword" {
  for_each        = var.synapse_workspace
  name            = "${azurerm_synapse_workspace.synw[each.key].name}-password"
  value           = random_password.password[each.key].result
  key_vault_id    = var.keyvault_id
  content_type    = "Password for the Synapse workspace ${azurerm_synapse_workspace.synw[each.key].name}"
  expiration_date = timeadd(timestamp(), "8760h")

  lifecycle {
    ignore_changes = [
      expiration_date
    ]
  }
}

//*********************************
//  loop over subresource names
//*********************************
module "sub-resource-names" {
  for_each            = var.synapse_workspace
  source              = "./sub-recource-names"
  subresource_names   = local.subresource_names
  name                = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value["resourcetype"]}"
  hmac                = substr(random_id.synapse_workspace_unique_suffix[each.key].keepers.hmac, 0, 4)
  pvtendpointrsg      = var.pvtendpointrsg
  pvtendpointlocation = var.pvtendpointlocation
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = var.vnet_id
  hmac_key            = var.hmac_key
  resource_name       = azurerm_synapse_workspace.synw.0.name
  resource_id         = azurerm_synapse_workspace.synw.0.id
  environmentshort    = var.environmentshort
  dns                 = var.dns
  rg_location         = var.pvtendpointlocation
  rg_name             = var.pvtendpointrsg
}

// //**********************************************************
// //      Synapse Role Assignment
// //**********************************************************
// # NOTE: We need to provide this role for deployments using pipelines
// resource "azurerm_synapse_role_assignment" "synw_roleassignment" {
//   for_each             = var.synapse_workspace
//   synapse_workspace_id = azurerm_synapse_workspace.synw[each.key].id
//   role_name            = "Synapse Artifact Publisher"
//   principal_id         = data.azurerm_client_config.config.object_id

//   depends_on = [azurerm_synapse_workspace.synw,
//   azurerm_synapse_firewall_rule.synw_firewallrule]
// }

//**********************************************************
//      Synapse Spark Pool
//**********************************************************
# NOTE 1: We create spark pool for all the synapse environments
# We can change the Node according to requirements
# By default : Small cluster is created, but we can change it to Medium or Large

# NOTE 2: libraries can bw installed directly using the setting.
#
resource "azurerm_synapse_spark_pool" "syn_sparkpool" {
  for_each                            = var.synapse_workspace
  name                                = "${var.landingzonetype}synsp"
  synapse_workspace_id                = azurerm_synapse_workspace.synw[each.key].id
  node_size_family                    = "MemoryOptimized"
  node_size                           = each.value["synsp_nodesize"]
  cache_size                          = 100
  dynamic_executor_allocation_enabled = false

  auto_scale {
    max_node_count = 10
    min_node_count = 3
  }

  auto_pause {
    delay_in_minutes = 10
  }

  library_requirement {
    content  = <<EOF
pyarrow
EOF
    filename = "requirements.txt"
  }

  spark_config {
    content  = <<EOF
spark.shuffle.spill                true
EOF
    filename = "config.txt"
  }

  depends_on = [azurerm_synapse_workspace.synw]
  tags       = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}
#
#//**********************************************************
#//  Azure Monitor Diagnostic Categories - synapse workspace
#//**********************************************************
#data "azurerm_monitor_diagnostic_categories" "synw" {
#  for_each    = var.synapse_workspace
#  resource_id = azurerm_synapse_workspace.synw[each.key].id
#}
#
#//**********************************************************
#//  Azure Monitor Diagnostic Setting
#//**********************************************************
#resource "azurerm_monitor_diagnostic_setting" "synapseworkspace_diagonistics" {
#  for_each                   = var.synapse_workspace
#  name                       = "${azurerm_synapse_workspace.synw[each.key].name}-diagnostics"
#  target_resource_id         = azurerm_synapse_workspace.synw[each.key].id
#  log_analytics_workspace_id = var.loganalyticsworkspace_id
#
#  dynamic "log" {
#    for_each = data.azurerm_monitor_diagnostic_categories.synw[each.key].logs
#    content {
#      category = log.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 30
#      }
#    }
#  }
#
#  dynamic "metric" {
#    for_each = data.azurerm_monitor_diagnostic_categories.synw[each.key].metrics
#    content {
#      category = metric.value
#
#      retention_policy {
#        enabled = true
#        days    = 15
#      }
#    }
#  }
#}
