#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "hmac_key" {
  type = string
}

#############################################################
## Synapse Analytics Workspace
#############################################################
variable "synapse_workspace" {
  type = map(object({
    resourcetype   = string
    rand_value     = string
    synsp_nodesize = string
  }))
}
variable "storage_data_lake_id" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "adlsfilesystems" {
  type = string
}
variable "landingzonetype" {
  type = string
}

variable "vnet_id" {
  type = string
}
variable "private_endpoints" {
  type = map(object({
    name       = string
    rand_value = string
  }))
}
variable "pvtendpointrsg" {
  type = string
}
variable "pvtendpointlocation" {
  type = string
}
variable "dns" {
  type = list(string)
}
variable "keyvault_id" {
  type = string
}