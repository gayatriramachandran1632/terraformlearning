module "sub-resource-synapse" {
  source            = "../../network/private-endpoint"
  for_each          = { for n in var.subresource_names : n => n }
  subresource_names = each.key
  name              = "${var.name}${each.value}"
  hmac              = var.hmac
  private_endpoints = var.private_endpoints
  productname       = var.productname
  regionshort       = var.regionshort
  vnet_id           = var.vnet_id
  hmac_key          = var.hmac_key
  resource_name     = var.resource_name
  resource_id       = var.resource_id
  environmentshort  = var.environmentshort
  subnet_name       = "service"
  dns               = length(regexall("SQL|SqlOnDemand", each.key)) > 0 ? [for n in var.dns : n if can(regex("sql.azuresynapse", n))][0] : [for n in var.dns : n if can(regex("dev.azuresynapse", n))][0]
  rg_location       = var.rg_location
  rg_name           = var.rg_name
}
