output "function_app_mi" {
  value = flatten([for item in azurerm_linux_function_app.functionapp : item.identity])
}
output "funcapp" {
  value = [for item in azurerm_linux_function_app.functionapp : item]
}