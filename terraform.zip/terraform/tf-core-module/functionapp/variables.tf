#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "storageaccountname" {
  type = string
}
variable "storageaccesskey" {
  type      = string
  sensitive = true
}
variable "appserviceplanid" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "functionapp" {
  type = map(object({
    resourcetype    = string
    serviceplan_key = string
    project_area    = string
    ostype          = string
    rand_value      = string
  }))
}

variable "instrumentation_key" {
  type = string
}
variable "subnet_id" {
  type = string
}
