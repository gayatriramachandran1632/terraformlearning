
output "subres" {
  value = [for n in module.sub-resource-fapp : n][0]
}