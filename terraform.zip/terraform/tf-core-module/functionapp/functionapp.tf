//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

locals {
  subresource_names = ["sites"]
}
//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "functionapp_unique_suffix" {
  for_each = var.functionapp
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value.project_area}${each.value["rand_value"]}")
  }
  byte_length = 4
}


//**********************************************************
//  Azure Function App
//**********************************************************
# NOTE: Managed Identity is active - it can be used to give access to storage etc

resource "azurerm_linux_function_app" "functionapp" {
  for_each                   = var.functionapp
  name                       = "${var.productname}${var.environmentshort}${var.regionshort}${each.value.resourcetype}${each.value.project_area}${substr(random_id.functionapp_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  location                   = var.resourcelocation
  resource_group_name        = var.resourcegpname
  storage_account_name       = var.storageaccountname
  storage_account_access_key = var.storageaccesskey
  service_plan_id            = var.appserviceplanid
  virtual_network_subnet_id  = var.subnet_id

  site_config {
    always_on                = true
    application_insights_key = var.instrumentation_key
    vnet_route_all_enabled   = true
    application_stack {
      python_version = "3.9"
    }
  }
  app_settings = {
    "WEBSITE_ENABLE_SYNC_UPDATE_SITE" = "false"
  }
  identity {
    type = "SystemAssigned"
  }

  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags, identity, app_settings
    ]
  }
}

#//**********************************************************
#//  Azure Monitor Diagnostic Categories - functionapp
#//**********************************************************
#data "azurerm_monitor_diagnostic_categories" "functionapp" {
#  for_each    = var.functionapp
#  resource_id = azurerm_linux_function_app.functionapp[each.key].id
#}
#
#
#//**********************************************************
#//  Azure Monitor Diagnostic Setting
#//**********************************************************
#resource "azurerm_monitor_diagnostic_setting" "functionapp_diagonistics" {
#  for_each                   = var.functionapp
#  name                       = "${azurerm_linux_function_app.functionapp[each.key].name}-diagnostics"
#  target_resource_id         = azurerm_linux_function_app.functionapp[each.key].id
#  log_analytics_workspace_id = var.loganalyticsworkspace_id
#
#
#  dynamic "log" {
#    for_each = data.azurerm_monitor_diagnostic_categories.functionapp[each.key].logs
#    content {
#      category = log.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 30
#      }
#    }
#  }
#
#  dynamic "metric" {
#    for_each = data.azurerm_monitor_diagnostic_categories.functionapp[each.key].metrics
#    content {
#      category = metric.value
#      enabled  = false
#
#      retention_policy {
#        enabled = true
#        days    = 15
#      }
#    }
#  }
#}
#
