//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "storage_accounts_unique_suffix" {
  for_each = var.storage_accounts
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//  Storage account creation
//**********************************************************
resource "azurerm_storage_account" "azstorage" {
  for_each                          = var.storage_accounts
  name                              = "${var.productname}${var.environmentshort}${var.landingzonetype}${each.value.resourcetype}${substr(random_id.storage_accounts_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name               = var.resourcegpname
  location                          = var.resourcelocation
  account_tier                      = each.value["account_tier"]
  account_replication_type          = each.value["account_replication_type"]
  account_kind                      = each.value["account_kind"]
  access_tier                       = each.value["access_tier"]
  enable_https_traffic_only         = true
  is_hns_enabled                    = false
  infrastructure_encryption_enabled = true
  allow_nested_items_to_be_public   = false
  min_tls_version                   = each.value["min_tls_version"]

  identity {
    type = "SystemAssigned"
  }
  network_rules {
    default_action = "Allow"
    bypass         = ["AzureServices"]
    #ip_rules = ["51.138.48.35"]
  }

  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

resource "azurerm_storage_table" "statable" {
  count                = var.deploytable ? 1 : 0
  name                 = "${var.productname}${var.environmentshort}${var.landingzonetype}tbl"
  storage_account_name = [for x in azurerm_storage_account.azstorage : x.name][0]
  depends_on = [
    azurerm_storage_account.azstorage
  ]
}

resource "azurerm_storage_queue" "staqueue" {
  count                = var.deployqueue ? 1 : 0
  name                 = "${var.productname}${var.environmentshort}${var.landingzonetype}que"
  storage_account_name = [for x in azurerm_storage_account.azstorage : x.name][0]
  depends_on = [
    azurerm_storage_table.statable
  ]
}


#//**********************************************************
#//  Azure Monitor Diagnostic Categories - storage account
#//**********************************************************
#data "azurerm_monitor_diagnostic_categories" "storageaccount" {
#  for_each    = var.storage_accounts
#  resource_id = azurerm_storage_account.azstorage[each.key].id
#}
#
#//**********************************************************
#//  Azure Monitor Diagnostic Setting
#//**********************************************************
#resource "azurerm_monitor_diagnostic_setting" "storageaccount_diagonistics" {
#  for_each                   = var.storage_accounts
#  name                       = "${azurerm_storage_account.azstorage[each.key].name}-diagnostics"
#  target_resource_id         = azurerm_storage_account.azstorage[each.key].id
#  log_analytics_workspace_id = var.loganalyticsworkspace_id
#
#  dynamic "log" {
#    for_each = data.azurerm_monitor_diagnostic_categories.storageaccount[each.key].logs
#    content {
#      category = log.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 30
#      }
#    }
#  }
#
#  dynamic "metric" {
#    for_each = data.azurerm_monitor_diagnostic_categories.storageaccount[each.key].metrics
#    content {
#      category = metric.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 15
#      }
#    }
#  }
#}
