output "sa_name" {
  value = values(azurerm_storage_account.azstorage).*.name
}

output "sa_id" {
  value = values(azurerm_storage_account.azstorage).*.id
}
