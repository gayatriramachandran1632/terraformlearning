#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "landingzonetype" {
  type = string
}

#########################################
#Storage Account
#########################################

variable "storage_accounts" {
  description = "storageaccounts"
  type = map(object({
    account_tier             = string
    account_replication_type = string
    access_tier              = string
    account_kind             = string
    resourcetype             = string
    rand_value               = string
    min_tls_version          = string
  }))
}

variable "deployqueue" {
  type = string
}
variable "deploytable" {
  type = string
}