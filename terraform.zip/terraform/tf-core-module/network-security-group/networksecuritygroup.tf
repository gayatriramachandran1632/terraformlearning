//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

resource "time_sleep" "sleep" {
  create_duration = "40s"
}
//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "network_security_groups_unique_suffix" {
  for_each = var.network_security_groups
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//      Network Security Group
//**********************************************************
resource "azurerm_network_security_group" "nsg" {
  for_each            = var.network_security_groups
  name                = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${lower(var.subnet_name)}-${substr(random_id.network_security_groups_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  location            = var.resourcelocation
  resource_group_name = var.resourcegpname
  tags                = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })

  security_rule {
    name                       = "AllowHttpsInbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "Internet"
    destination_address_prefix = "*"
  }
  security_rule {
    name                       = "AllowGatewayManagerInbound"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "GatewayManager"
    destination_address_prefix = "*"
  }
  security_rule {
    name                       = "AllowSshRdpOutbound"
    priority                   = 100
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_ranges    = ["22", "3389"]
    source_address_prefix      = "*"
    destination_address_prefix = "VirtualNetwork"
  }
  security_rule {
    name                       = "AllowAzureCloudOutbound"
    priority                   = 110
    direction                  = "Outbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "*"
    destination_address_prefix = "AzureCloud"
  }
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

//**********************************************************************************
// Associates a Network Security Group with a subnet within a Virtual Network
//**********************************************************************************
resource "azurerm_subnet_network_security_group_association" "subnetnsgassociation" {
  for_each                  = var.network_security_groups
  network_security_group_id = azurerm_network_security_group.nsg[each.key].id
  subnet_id                 = join("", [var.vnet_id, "/subnets/", var.subnet_name])
  depends_on = [
    time_sleep.sleep
  ]
}