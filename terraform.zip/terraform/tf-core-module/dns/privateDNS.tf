//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "privatedns_unique_suffix" {
  for_each = var.private_dns_zones
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//      Private DNS Zone
//**********************************************************
resource "azurerm_private_dns_zone" "privatednszone" {
  for_each            = var.private_dns_zones
  name                = each.value.dns_zone_name
  resource_group_name = var.resourcegpname
  tags                = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

//**********************************************************
//      Private DNS Zone Virtual Network Link
//**********************************************************
resource "azurerm_private_dns_zone_virtual_network_link" "pdnsz_vnet_link" {
  for_each              = var.private_dns_zones
  name                  = azurerm_private_dns_zone.privatednszone[each.key].name
  resource_group_name   = var.resourcegpname
  private_dns_zone_name = azurerm_private_dns_zone.privatednszone[each.key].name
  virtual_network_id    = var.vnet_id
  tags                  = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}
