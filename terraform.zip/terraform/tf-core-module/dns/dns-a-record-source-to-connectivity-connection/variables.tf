variable "regionlong" {
  type = string
}
variable "productname" {
  type = string
}
# Destination variables for peering
variable "dest_subscriptionid" {
  type = string
}
variable "dest_clientid" {
  type = string
}
variable "dest_clientsecret" {
  type = string
}
variable "dest_vnet_required_tags" {
  type = string

}
variable "dest_landingzonetype" {
  type = string
}
variable "dest_environmentlong" {
  type = string
}
variable "dns" {
  type = list(string)
}
variable "ipaddress" {
  type = string
}
variable "fqdn" {
  type = string
}
variable "filter" {
  type = string
}

