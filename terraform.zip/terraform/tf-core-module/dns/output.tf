

# #############################################################################
# # OUTPUTS Private DNS Zone
# #############################################################################

output "dns_zone_ids" {
  value = [for d in azurerm_private_dns_zone.privatednszone : d.id]
}
output "dns_zone_name" {
  value = [for d in azurerm_private_dns_zone.privatednszone : d.name]
}
output "dns" {
  value = [for d in azurerm_private_dns_zone.privatednszone : d]
}

