variable "regionlong" {
  type = string
}
variable "productname" {
  type = string
}
variable "dest_landingzonetype" {
  type = string
}
variable "dest_environmentlong" {
  type = string
}
variable "dns" {
  type = list(string)
}
variable "ipaddress" {
  type = string
}
variable "fqdn" {
  type = string
}
variable "filter" {
  type = string
}
