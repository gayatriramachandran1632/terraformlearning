
locals {
  val = { for n in var.dns : n => n if can(regex(var.filter, n)) }
}
################################################################
# Private DNS Records
################################################################
resource "azurerm_private_dns_a_record" "dns_a_record" {
  name                = var.fqdn
  zone_name           = split("/", var.dns[0])[8]
  resource_group_name = "${var.productname}-${var.dest_environmentlong}-${var.dest_landingzonetype}-rg-${var.regionlong}-privatedns"
  ttl                 = 300
  records             = [var.ipaddress]
  lifecycle {
    ignore_changes = [
      tags, records
    ]
  }
}
