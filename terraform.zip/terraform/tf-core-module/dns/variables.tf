variable "resourcegpname" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "hmac_key" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "vnet_id" {
  type = string
}
variable "private_dns_zones" {
  type = map(object({
    dns_zone_name        = string
    zone_exists          = bool
    registration_enabled = bool
    rand_value           = string
  }))
}
