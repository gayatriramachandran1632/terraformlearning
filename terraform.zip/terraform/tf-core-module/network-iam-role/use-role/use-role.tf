data "azurerm_subscription" "primary" {}
data "azurerm_role_definition" "use_role" {
  name  = "Network Contributor Custom Role"
  scope = data.azurerm_subscription.primary.id
}