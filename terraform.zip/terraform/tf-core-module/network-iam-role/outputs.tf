output "value" {
  value = azurerm_role_assignment.assign_role
}