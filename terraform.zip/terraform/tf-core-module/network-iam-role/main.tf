
resource "azurerm_role_assignment" "assign_role" {
  scope                = var.scope_id
  role_definition_name = "Network Contributor Custom Role"
  principal_id         = var.principleID
  lifecycle {
    ignore_changes = [
      skip_service_principal_aad_check
    ]
  }
}
