variable "principleID" {
  type = string
}
variable "scope_id" {
  type = string
}