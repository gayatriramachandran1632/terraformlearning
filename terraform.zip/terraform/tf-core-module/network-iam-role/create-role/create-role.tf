data "azurerm_subscription" "primary" {}
resource "azurerm_role_definition" "create_new_role" {
  name        = "Network Contributor Custom Role"
  scope       = data.azurerm_subscription.primary.id
  description = "This is a custom role created for ZDP-AP-AG-EVA for Network Peering. Please reach out Reiner Rottman Or Pranay Tare for more info."
  permissions {
    actions = [
      "Microsoft.Authorization/*/read",
      "Microsoft.Insights/alertRules/*",
      "Microsoft.Network/*",
      "Microsoft.ResourceHealth/availabilityStatuses/read",
      "Microsoft.Resources/deployments/*",
      "Microsoft.Support/*",
      "Microsoft.Resources/subscriptions/resourceGroups/read",
      "Microsoft.Network/virtualNetworks/read",
      "Microsoft.Network/virtualNetworks/peer/action",
      "Microsoft.Network/virtualNetworks/join/action",
      "Microsoft.Network/virtualNetworks/subnets/read",
      "Microsoft.Network/virtualNetworks/subnets/join/action",
      "Microsoft.Network/virtualNetworks/virtualNetworkPeerings/write",
      "Microsoft.Network/virtualNetworks/virtualNetworkPeerings/read",
      "Microsoft.Network/privateDnsZones/virtualNetworkLinks/read",
      "Microsoft.Network/privateDnsZones/virtualNetworkLinks/write",
      "Microsoft.Network/virtualNetworks/subnets/join/action",
      "Microsoft.Network/virtualNetworks/subnets/joinViaServiceEndpoint/action",
      "Microsoft.Network/privateDnsZones/join/action",
      "Microsoft.Authorization/roleDefinitions/write",
      "Microsoft.Resources/subscriptions/providers/read",
      "Microsoft.Storage/storageAccounts/PrivateEndpointConnectionsApproval/action",
      "Microsoft.KeyVault/vaults/PrivateEndpointConnectionsApproval/action",
      "Microsoft.Purview/accounts/PrivateEndpointConnectionsApproval/action",
      "Microsoft.Synapse/privateLinkHubs/privateEndpointConnectionsApproval/action",
      "Microsoft.Synapse/workspaces/privateEndpointConnectionsApproval/action",
      "Microsoft.EventHub/namespaces/privateEndpointConnectionsApproval/action",
      "Microsoft.Network/privateEndpoints/write",
      "Microsoft.Purview/accounts/privateEndpointConnections/write",
      "Microsoft.Purview/accounts/privateEndpointConnections/read"
    ]
    not_actions = []
  }
  assignable_scopes = [
    data.azurerm_subscription.primary.id,
    "/providers/Microsoft.Management/managementGroups/a7ddea7c-53df-46bf-aa3e-72c5123d39c4"
  ]
}