output "subres" {
  value = [for n in module.sub-resource-functionapp : n]
}