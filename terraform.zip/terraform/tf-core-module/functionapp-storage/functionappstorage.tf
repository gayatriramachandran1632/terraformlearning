//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

locals {
  subresource_names = ["file", "blob"]
}

//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "function_storage_accounts_unique_suffix" {
  for_each = var.function_storage_accounts
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//  Storage account creation
//**********************************************************
resource "azurerm_storage_account" "functionappsa" {
  for_each                          = var.function_storage_accounts
  name                              = "${var.productname}${var.environmentshort}${var.landingzonetype}${each.value.resourcetype}st${substr(random_id.function_storage_accounts_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name               = var.resourcegpname
  location                          = var.resourcelocation
  account_tier                      = each.value["account_tier"]
  account_replication_type          = each.value["account_replication_type"]
  account_kind                      = each.value["account_kind"]
  access_tier                       = each.value["access_tier"]
  enable_https_traffic_only         = true
  is_hns_enabled                    = false
  infrastructure_encryption_enabled = true
  tags                              = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })

  allow_nested_items_to_be_public = false
  identity {
    type = "SystemAssigned"
  }
  network_rules {
    bypass                     = ["AzureServices"]
    default_action             = "Deny"
    ip_rules                   = []
    virtual_network_subnet_ids = []
  }

  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

#
#//**********************************************************
#//  Azure Monitor Diagnostic Categories - Function app storage
#//**********************************************************
#data "azurerm_monitor_diagnostic_categories" "functionappsa" {
#  for_each    = var.function_storage_accounts
#  resource_id = azurerm_storage_account.functionappsa[each.key].id
#}
#
#//**********************************************************
#//  Azure Monitor Diagnostic Setting
#//**********************************************************
#resource "azurerm_monitor_diagnostic_setting" "functionappsa_diagonistics" {
#  for_each                   = var.function_storage_accounts
#  name                       = "${azurerm_storage_account.functionappsa[each.key].name}-diagnostics"
#  target_resource_id         = azurerm_storage_account.functionappsa[each.key].id
#  log_analytics_workspace_id = var.loganalyticsworkspace_id
#
#  dynamic "log" {
#    for_each = data.azurerm_monitor_diagnostic_categories.functionappsa[each.key].logs
#    content {
#      category = log.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 30
#      }
#    }
#  }
#
#  dynamic "metric" {
#    for_each = data.azurerm_monitor_diagnostic_categories.functionappsa[each.key].metrics
#    content {
#      category = metric.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 15
#      }
#    }
#  }
#}
