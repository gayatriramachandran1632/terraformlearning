#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
#########################################
#Storage Account
#########################################

variable "function_storage_accounts" {
  description = "function storage accounts"
  type = map(object({
    account_tier             = string
    account_replication_type = string
    access_tier              = string
    account_kind             = string
    resourcetype             = string
    rand_value               = string
  }))
}
variable "landingzonetype" {
  type = string
}