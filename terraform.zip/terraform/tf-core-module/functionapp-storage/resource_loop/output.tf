
output "subres" {
  value = [for n in module.sub-resource-fapp-storage : n][0]
}