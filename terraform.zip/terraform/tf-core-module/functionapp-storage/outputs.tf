output "functionappsaname" {
  value = values(azurerm_storage_account.functionappsa).*.name
}
output "functionappsakey" {
  value = values(azurerm_storage_account.functionappsa).*.primary_access_key
}
output "functionappid" {
  value = values(azurerm_storage_account.functionappsa).*.id
}