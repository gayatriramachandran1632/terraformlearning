//**********************************************************
//   Random Password Generation for Mongodb Database User
//**********************************************************
resource "random_password" "mongodbpassword" {
  for_each         = var.mongodbatlas
  length           = 32
  min_upper        = 2
  min_lower        = 2
  min_special      = 2
  numeric          = true
  special          = true
  override_special = "!@#$%&"
}

//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "mongodbatlas_unique_suffix" {
  for_each = var.mongodbatlas
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value_mongodbatlas"]}")
  }
  byte_length = 4
}

//**********************************************************
//      Mongodb Project
//**********************************************************
resource "mongodbatlas_project" "mongodbproject" {
  provider         = mongodbatlas
  for_each         = var.mongodbatlas
  name             = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.projectresourcetype}-${substr(random_id.mongodbatlas_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  org_id           = var.orgid
  project_owner_id = var.ownerid
  api_keys {
    api_key_id = var.apikeyid
    role_names = [each.value.rolename]
  }
  is_collect_database_specifics_statistics_enabled = coalesce(each.value.is_collect_database_specifics_statistics_enabled, true)
  is_data_explorer_enabled                         = coalesce(each.value.is_data_explorer_enabled, true)
  is_performance_advisor_enabled                   = coalesce(each.value.is_performance_advisor_enabled, true)
  is_realtime_performance_panel_enabled            = coalesce(each.value.is_realtime_performance_panel_enabled, true)
  is_schema_advisor_enabled                        = coalesce(each.value.is_schema_advisor_enabled, true)
}

//**********************************************************
//      Retrieve Project Details
//**********************************************************
data "mongodbatlas_project" "mongodbproject" {
  provider   = mongodbatlas
  for_each   = var.mongodbatlas
  project_id = mongodbatlas_project.mongodbproject[each.key].id
}

//**********************************************************
//      MongoDB Cluster
//**********************************************************
resource "mongodbatlas_cluster" "mongodbcluster" {
  provider     = mongodbatlas
  for_each     = var.mongodbatlas
  project_id   = data.mongodbatlas_project.mongodbproject[each.key].project_id
  name         = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.clusterresourcetype}-${substr(random_id.mongodbatlas_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  cluster_type = each.value.clustertype
  replication_specs {
    num_shards = 1
    regions_config {
      region_name     = each.value.location
      electable_nodes = coalesce(each.value.electable_nodes, 3)
      priority        = coalesce(each.value.priority, 7)
      read_only_nodes = coalesce(each.value.read_only_nodes, 0)
    }
  }
  cloud_backup                 = coalesce(each.value.cloud_backup, true)
  auto_scaling_disk_gb_enabled = coalesce(each.value.auto_scaling_disk_gb_enabled, true)
  mongo_db_major_version       = each.value.mongodbversion
  //Provider Settings "block"
  provider_name               = each.value.providername
  provider_disk_type_name     = each.value.providerdisktype
  provider_instance_size_name = each.value.providerinstancesize
}

//**********************************************************
//      MongoDB Serverless Instance
//**********************************************************
resource "mongodbatlas_serverless_instance" "mongodbinstance" {
  provider                                = mongodbatlas
  project_id                              = data.mongodbatlas_project.mongodbproject[each.key].project_id
  for_each                                = var.mongodbatlas
  name                                    = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.serverresourcetype}-${substr(random_id.mongodbatlas_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  provider_settings_backing_provider_name = each.value.providername
  provider_settings_provider_name         = each.value.providersetting
  provider_settings_region_name           = each.value.location
}

//**********************************************************
//      MongoDB Database User
//**********************************************************
resource "mongodbatlas_database_user" "mongodbdatabaseuser" {
  provider           = mongodbatlas
  for_each           = var.mongodbatlas
  username           = each.value.username
  password           = random_password.mongodbpassword[each.key].result
  project_id         = data.mongodbatlas_project.mongodbproject[each.key].project_id
  auth_database_name = "admin"
  roles {
    role_name     = "readAnyDatabase"
    database_name = "admin"
  }
  labels {
    key   = "My Key"
    value = "My Value"
  }
}

//**********************************************************
//      Upload the connection string to Keyvault
//**********************************************************
resource "azurerm_key_vault_secret" "mongodbserverlessinstanceconnectionstring" {
  for_each        = var.mongodbatlas
  name            = "mongodb-serverlessinstance-connectionstring-${each.key}"
  value           = replace("${mongodbatlas_serverless_instance.mongodbinstance[each.key].connection_strings_standard_srv}", "<password>", random_password.mongodbpassword[each.key].result)
  key_vault_id    = var.keyvault_id
  expiration_date = timeadd(timestamp(), "9640h")
  content_type    = "text/plain"
  lifecycle {
    ignore_changes = [
      expiration_date
    ]
  }
}

//**********************************************************
//      Upload the Password to Keyvault
//**********************************************************
resource "azurerm_key_vault_secret" "mongodbpasswordvault" {
  for_each        = var.mongodbatlas
  name            = "mongodbusrpasswd${each.key}"
  value           = random_password.mongodbpassword[each.key].result
  key_vault_id    = var.keyvault_id
  expiration_date = timeadd(timestamp(), "9640h")
  content_type    = "text/plain"
  lifecycle {
    ignore_changes = [
      expiration_date
    ]
  }
}