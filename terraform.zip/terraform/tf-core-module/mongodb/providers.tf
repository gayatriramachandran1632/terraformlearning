terraform {
  required_version = ">= 0.15"
  required_providers {
    mongodbatlas = {
      source  = "mongodb/mongodbatlas"
      version = ">=1.4.3"
    }
  }
}
provider "mongodbatlas" {
  public_key  = var.publickey
  private_key = var.privatekey
}