#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "publickey" {
  type = string
}
variable "privatekey" {
  type = string
}

#############################################################
## Common variables that are used for mongodb instances
#############################################################

variable "orgid" {
  type = string
}
variable "ownerid" {
  type = string
}
variable "apikeyid" {
  type = string
}
variable "keyvault_id" {
  type = string
}
# #############################################################
# ## Variables that are used for Mongodbatlas resources creation
# #############################################################

variable "mongodbatlas" {
  type = map(object({
    projectresourcetype                              = string
    clusterresourcetype                              = string
    rand_value_mongodbatlas                          = string
    rolename                                         = string
    is_collect_database_specifics_statistics_enabled = bool
    is_data_explorer_enabled                         = bool
    is_performance_advisor_enabled                   = bool
    is_realtime_performance_panel_enabled            = bool
    is_schema_advisor_enabled                        = bool
    clustertype                                      = string
    location                                         = string
    electable_nodes                                  = number
    priority                                         = number
    read_only_nodes                                  = number
    cloud_backup                                     = bool
    auto_scaling_disk_gb_enabled                     = bool
    mongodbversion                                   = number
    providername                                     = string
    providerdisktype                                 = string
    providerinstancesize                             = string
    providersetting                                  = string
    username                                         = string
    serverresourcetype                               = string
  }))
}