// Get role from data resource, instead of hard coding
data "azurerm_role_definition" "role" {
  for_each = var.eligiblerequestid
  name     = each.value.role_definition_name
}

##// Generate a new guid for the eligible schedule request whever principalId, roleDefinitionId or requestType changes
##resource "random_uuid" "eligible_schedule_request_id" {
##    for_each = var.eligiblerequestid
##    keepers = {
##        principalId         = each.value.principal_id
##        roleDefinitionId    = data.azurerm_role_definition.role.id
##        requestType         = var.request_type
##        startDateTime       = "${formatdate("YYYY-MM-DD", time_rotating.eligible_schedule_request_start_date.id)}T${formatdate("HH:mm:ss.0000000+02:00", time_rotating.eligible_schedule_request_start_date.id)}"
##        duration            = "P${tostring(var.assignment_days)}D"
##    }
##}
resource "random_id" "eligible_schedule_request_id" {
  for_each = var.eligiblerequestid
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

// Used to a) support short life time assignments automatically re-assigned and b) support a single start date that does not change
resource "time_rotating" "eligible_schedule_request_start_date" {
  rotation_days = floor(var.assignment_days / 2)
}

// Deploy the eligible schedule request using ARM template
resource "azurerm_resource_group_template_deployment" "eligible_schedule_request" {
  for_each            = var.eligiblerequestid
  name                = "${var.environmentshort}-${substr(random_id.eligible_schedule_request_id[each.key].keepers.hmac, 0, 4)}"
  resource_group_name = each.value.resource_group_name
  deployment_mode     = "Incremental"
  template_content    = file("${path.module}/pim_assignment.json")

  // Send parameters to ARM template
  parameters_content = jsonencode({
    "principalId" = {
      value = each.value.principal_id
    },
    "roleDefinitionId" = {
      value = data.azurerm_role_definition.role[each.key].id
    },
    ##"requestType" = {
    ##  value = var.request_type
    ##},
    ##"id" = {
    ##  value = substr(random_id.eligible_schedule_request_id[each.key].keepers.hmac, 0, 4)
    ##}
    "startDateTime" = {
      value = "${formatdate("YYYY-MM-DD", time_rotating.eligible_schedule_request_start_date.id)}T${formatdate("HH:mm:ss.0000000+02:00", time_rotating.eligible_schedule_request_start_date.id)}"
    }
    ##"duration" = {
    ##  value = "P${tostring(var.assignment_days)}D"
    ##}
  })

}