#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "hmac_key" {
  type = string
}

##variable "request_type" {
##    type = string
##    default = "AdminAssign"
##}

variable "assignment_days" {
  type    = number
  default = 365
}
variable "deployment_name" {
  type    = string
  default = null
}

variable "eligiblerequestid" {
  description = "Eligible request"
  type = map(object({
    resource_group_name  = string
    principal_id         = string
    role_definition_name = string
    role_definition_id   = string
    rand_value           = string
  }))
}