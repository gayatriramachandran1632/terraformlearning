variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "vnetname" {
  type = string
}
variable "subnetname" {
  type = string
}
variable "platform" {
  type = string
}
variable "networking_filepath" {
  type = string
}
variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "network_security_groups" {
  description = "network security group"
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}