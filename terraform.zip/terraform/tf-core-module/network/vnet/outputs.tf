
output "subnetid" {
  value = [for item in module.subnet : item]
}
output "vnetname" {
  value = [for n in azurerm_virtual_network.vnet : n]
}