//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

locals {
  networking = jsondecode(file(var.networking_filepath))
  valuelist = flatten([
    for n in local.networking : [
      for val in n : {
        subnetlist = val[var.platform][0]["subnet"]
        vnetlist   = val[var.platform][0]["network"]
      }
    ]
  ])
}

//**********************************************************
//      Virtual Network and Subnets
//**********************************************************
resource "azurerm_virtual_network" "vnet" {
  for_each            = { for k, instance in flatten(local.valuelist[*].vnetlist) : k => instance }
  name                = var.vnetname
  resource_group_name = var.resourcegpname
  location            = var.resourcelocation
  address_space       = each.value["address_space"]
  tags                = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

module "subnet" {
  for_each                = { for k, instance in flatten(local.valuelist[*].subnetlist) : k => instance }
  source                  = "../subnet"
  ars_tags                = var.ars_tags
  rgtags                  = var.rgtags
  resourcegpname          = var.resourcegpname
  resourcelocation        = var.resourcelocation
  vnetname                = azurerm_virtual_network.vnet[0].name
  subnetname              = each.value["name"]
  subnetid                = each.value["address"]
  subnet_delegation       = each.value["subnet_delegation"]
  vnet_id                 = azurerm_virtual_network.vnet[0].id
  environmentshort        = var.environmentshort
  hmac_key                = var.hmac_key
  regionshort             = var.regionshort
  network_security_groups = var.network_security_groups
  productname             = var.productname
}

