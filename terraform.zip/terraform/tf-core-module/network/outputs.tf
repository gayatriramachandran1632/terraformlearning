
output "subnetserviceid" {
  value = [for n in module.vnet_deployment[0] : n][0]
}

output "vnetid" {
  value = [for n in module.vnet_deployment : n][0]
}

output "vnetname" {
  value = [for n in module.vnet_deployment : n][0]
}