#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "virtual_networks" {
  type = map(object({
    resourcetype    = string
    subresourcetype = string
    rand_value_vnet = string
    rand_value_snet = string
  }))
}
variable "network_security_groups" {
  description = "network security group"
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "networking_filepath" {
  type = string
}
variable "platform" {
  type = string
}