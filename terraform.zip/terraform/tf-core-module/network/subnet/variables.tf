variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "vnetname" {
  type = string
}
variable "subnetname" {
  type = string
}
variable "subnetid" {
  type = string
}
variable "subnet_delegation" {
  type = string
}
variable "vnet_id" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "productname" {
  type = string
}
variable "network_security_groups" {
  description = "network security group"
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}