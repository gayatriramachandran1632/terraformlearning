
output "subnetserviceid" {
  value = azurerm_subnet.subnet.id
}
output "nsg" {
  value = [for n in module.nsg_deployment : n]
}