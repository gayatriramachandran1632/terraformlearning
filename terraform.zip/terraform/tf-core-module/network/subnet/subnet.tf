//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}

resource "time_sleep" "sleep" {
  create_duration = "50s"
}
//**********************************************************
//     subnet
//**********************************************************
resource "azurerm_subnet" "subnet" {
  name                 = var.subnetname
  address_prefixes     = [var.subnetid]
  virtual_network_name = var.vnetname
  resource_group_name  = var.resourcegpname

  dynamic "delegation" {
    for_each = length(var.subnet_delegation) > 0 ? [1] : []

    content {
      name = "delegation"
      service_delegation {
        name = var.subnet_delegation
      }
    }
  }

  lifecycle {
    ignore_changes = [
      delegation
    ]
  }
}

module "nsg_deployment" {
  source                  = "../../../tf-core-module/network-security-group"
  ars_tags                = var.ars_tags
  environmentshort        = var.environmentshort
  hmac_key                = var.hmac_key
  network_security_groups = var.network_security_groups
  productname             = var.productname
  regionshort             = var.regionshort
  resourcegpname          = var.resourcegpname
  resourcelocation        = var.resourcelocation
  rgtags                  = var.rgtags
  subnet_name             = var.subnetname
  vnet_id                 = var.vnet_id
  depends_on = [
    time_sleep.sleep
  ]
}