
//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "virtual_networks_unique_suffix" {
  for_each = var.virtual_networks
  keepers = {
    hmac   = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value_vnet"]}")
    subnet = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value_snet"]}")
  }
  byte_length = 4
}

module "vnet_deployment" {
  for_each                = var.virtual_networks
  source                  = "./vnet"
  vnetname                = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.virtual_networks_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  subnetname              = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.subresourcetype}-${substr(random_id.virtual_networks_unique_suffix[each.key].keepers.subnet, 0, 4)}"
  resourcegpname          = var.resourcegpname
  resourcelocation        = var.resourcelocation
  rgtags                  = var.rgtags
  ars_tags                = var.ars_tags
  networking_filepath     = var.networking_filepath
  platform                = var.platform
  environmentshort        = var.environmentshort
  hmac_key                = var.hmac_key
  network_security_groups = var.network_security_groups
  productname             = var.productname
  regionshort             = var.regionshort
}

