variable "name" {
  type = string
}
variable "hmac" {
  type = string
}
variable "rg_name" {
  type = string
}
variable "rg_location" {
  type = string
}
variable "subnet_name" {
  type = string
}
variable "vnet_id" {
  type = string
}
variable "resource_id" {
  type = string
}
variable "subresource_names" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "productname" {
  type = string
}
variable "private_endpoints" {
  type = map(object({
    name       = string
    rand_value = string
  }))
}
variable "resource_name" {
  type = string
}
variable "dns" {
  type = string
}