
# Destination variables for peering
variable "dest_subscriptionid" {
  type = string
}
variable "dest_clientid" {
  type = string
}
variable "dest_clientsecret" {
  type = string
}
variable "productname" {
  type = string
}
variable "regionlong" {
  type = string
}
variable "dest_landingzonetype" {
  type = string
}
variable "dest_environmentlong" {
  type = string
}
variable "source_landingzonetype" {
  type = string
}
variable "dns" {
  type = list(string)
}
variable "src_vnet_id" {
  type = string
}