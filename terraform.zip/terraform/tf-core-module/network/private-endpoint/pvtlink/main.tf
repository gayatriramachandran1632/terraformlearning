locals {
  dns_names = flatten([
    for dns_vals in var.dns : {
      value = dns_vals
    }
  ])
  val = [for n in local.dns_names : n.value]
}

resource "azurerm_private_dns_zone_virtual_network_link" "dnszone_vnet_link" {
  for_each              = { for n in local.val : tostring(n) => n }
  name                  = "${split("/", each.key)[8]}-${var.source_landingzonetype}"
  resource_group_name   = "${var.productname}-${var.dest_environmentlong}-${var.dest_landingzonetype}-rg-${var.regionlong}-privatedns"
  private_dns_zone_name = split("/", each.key)[8]
  virtual_network_id    = var.src_vnet_id
  provider              = azurerm.destination
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}
