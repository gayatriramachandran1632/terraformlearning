output "pvtlink" {
  value = local.val
}