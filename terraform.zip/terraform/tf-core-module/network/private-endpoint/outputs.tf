output "subres" {
  value = [for n in module.subresources : n]
}