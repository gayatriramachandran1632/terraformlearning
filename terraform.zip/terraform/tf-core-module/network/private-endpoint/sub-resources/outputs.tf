output "endpoint" {
  value = [for n in azurerm_private_endpoint.endpoint : n][0]
}