//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}
data "azurerm_subscription" "primary" {}

//**********************************************************
//      Private End Point
//**********************************************************
resource "azurerm_private_endpoint" "endpoint" {
  provider            = azurerm.destination
  name                = "${var.name}-${var.subresource_names}-pe"
  resource_group_name = var.rg_name
  location            = var.rg_location
  subnet_id           = join("", [var.vnet_id, "/subnets/", var.subnet_name])

  private_service_connection {
    name                           = "${var.name}-${var.subresource_names}-psc"
    private_connection_resource_id = var.resource_id
    is_manual_connection           = false
    subresource_names              = [var.subresource_names]
  }
  #tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}