
//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "privateendpoint_unique_suffix" {
  for_each = var.private_endpoints
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

module "subresources" {
  for_each          = var.private_endpoints
  source            = "./sub-resources"
  environmentshort  = var.environmentshort
  hmac              = var.hmac
  name              = var.name
  productname       = var.productname
  regionshort       = var.regionshort
  resource_id       = var.resource_id
  rg_location       = var.rg_location
  rg_name           = var.rg_name
  subnet_name       = var.subnet_name
  subresource_names = var.subresource_names
  vnet_id           = var.vnet_id
  resource_name     = var.resource_name
  dns               = var.dns
  providers = {
    azurerm.destination = azurerm.destination
  }
}
