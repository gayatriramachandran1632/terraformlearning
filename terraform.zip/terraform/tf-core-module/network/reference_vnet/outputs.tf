output "subnetserviceid" {
  value = data.azurerm_resources.dest_vnet
}