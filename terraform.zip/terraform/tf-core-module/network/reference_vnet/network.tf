data "azurerm_resources" "dest_vnet" {
  provider            = azurerm.destination
  type                = "Microsoft.Network/virtualNetworks"
  resource_group_name = "${var.productname}-${var.dest_environmentlong}-${var.dest_landingzonetype}-rg-${var.regionlong}-network"
  required_tags = {
    "project" = var.dest_vnet_required_tags
  }
}
data "azurerm_virtual_network" "get_vnet" {
  provider            = azurerm.destination
  name                = data.azurerm_resources.dest_vnet.resources[0].name
  resource_group_name = data.azurerm_resources.dest_vnet.resource_group_name
}