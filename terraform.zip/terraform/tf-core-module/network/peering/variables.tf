# Common variables
variable "peering_name_src_to_dest" {
  type = string
}
variable "peering_name_dest_to_src" {
  type = string
}
variable "rsg_tags" {
  type = map(string)
}
variable "productname" {
  type = string
}
variable "regionlong" {
  type = string
}
# Source variables for peering
variable "src_vnet_rsg_name" {
  type = string
}
variable "src_vnet_name" {
  type = string
}
variable "src_vnet_id" {
  type = string
}
# Destination variables for peering
variable "dest_subscriptionid" {
  type      = string
  sensitive = true
}
variable "dest_clientid" {
  type      = string
  sensitive = true
}
variable "dest_clientsecret" {
  type      = string
  sensitive = true
}
variable "dest_vnet_required_tags" {
  type = string
}
variable "dest_landingzonetype" {
  type = string
}
variable "dest_environmentlong" {
  type = string
}

