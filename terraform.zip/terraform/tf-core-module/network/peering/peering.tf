data "azurerm_resources" "dest_vnet" {
  provider            = azurerm.destination
  type                = "Microsoft.Network/virtualNetworks"
  resource_group_name = "${var.productname}-${var.dest_environmentlong}-${var.dest_landingzonetype}-rg-${var.regionlong}-network"
  required_tags = {
    "project" = var.dest_vnet_required_tags
  }
}

//******************************************************************************
//      azurerm_virtual_network_peering - peer SORUCE vnet to DESTINATION vnet
//******************************************************************************
resource "azurerm_virtual_network_peering" "src_dest" {
  provider                     = azurerm.source
  name                         = var.peering_name_src_to_dest
  resource_group_name          = var.src_vnet_rsg_name
  virtual_network_name         = var.src_vnet_name
  remote_virtual_network_id    = data.azurerm_resources.dest_vnet.resources[0].id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
}

//******************************************************************************
//      azurerm_virtual_network_peering - peer DESTINATION vnet to SOURCE vnet
//******************************************************************************
resource "azurerm_virtual_network_peering" "dest_src" {
  provider                     = azurerm.destination
  name                         = var.peering_name_dest_to_src
  resource_group_name          = data.azurerm_resources.dest_vnet.resource_group_name
  virtual_network_name         = data.azurerm_resources.dest_vnet.resources[0].name
  remote_virtual_network_id    = var.src_vnet_id
  allow_virtual_network_access = true
  allow_forwarded_traffic      = true
}



# data "azurerm_resources" "dlzvnet" {
#   # provider = azurerm.dlz
#    type = "Microsoft.Network/virtualNetworks"
#    resource_group_name = var.resourcegpname
#    required_tags = {    
#     "project" = var.rsg_tags.project
#    }
# }


# output "rgdlz" {
#  value = data.azurerm_resources.dlzvnet.resource_group_name     
# }

# output "vnetdlzid" {
#  value = data.azurerm_resources.dlzvnet.resources[0].id     
# }
# output "vnetdlzname" {
#  value = data.azurerm_resources.dlzvnet.resources[0].name  
# }