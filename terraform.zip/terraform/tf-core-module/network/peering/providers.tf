data "azurerm_client_config" "config" {}

provider "azurerm" {
  features {}
  alias                      = "source"
  subscription_id            = data.azurerm_client_config.config.subscription_id
  client_id                  = var.dest_clientid
  client_secret              = var.dest_clientsecret
  tenant_id                  = data.azurerm_client_config.config.tenant_id
  skip_provider_registration = true
}

provider "azurerm" {
  features {}
  alias                      = "destination"
  subscription_id            = var.dest_subscriptionid
  client_id                  = var.dest_clientid
  client_secret              = var.dest_clientsecret
  tenant_id                  = data.azurerm_client_config.config.tenant_id
  skip_provider_registration = true
}