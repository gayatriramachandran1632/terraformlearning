output "dest_rg" {
  value = data.azurerm_resources.dest_vnet.resource_group_name
}
output "dest_vnetid" {
  value = data.azurerm_resources.dest_vnet.resources[0].id
}
output "dest_vnetname" {
  value = data.azurerm_resources.dest_vnet.resources[0].name
}