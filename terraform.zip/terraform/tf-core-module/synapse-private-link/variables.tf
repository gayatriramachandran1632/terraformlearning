#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}

variable "hmac_key" {
  type = string
}

#############################################################
## Synapse Private Link Hub
#############################################################
variable "synapse_private_link_hub" {
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}

variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
