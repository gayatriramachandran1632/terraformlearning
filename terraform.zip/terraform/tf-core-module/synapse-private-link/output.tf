output "privatelink" {
  value = [for n in azurerm_synapse_private_link_hub.synapse_private_link_hub : n]
}