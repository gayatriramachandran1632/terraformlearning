//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}
data "azurerm_subscription" "primary" {}

locals {
  subresource_names = ["Web"]
}
//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "synpl_unique_suffix" {
  for_each = var.synapse_private_link_hub
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//  Synapse Private Link Hub
//**********************************************************
resource "azurerm_synapse_private_link_hub" "synapse_private_link_hub" {
  for_each            = var.synapse_private_link_hub
  name                = "${var.productname}${var.environmentshort}${var.regionshort}${each.value.resourcetype}${substr(random_id.synpl_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name = var.resourcegpname
  location            = var.resourcelocation

  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}