output "appserviceplanid" {
  value = values(azurerm_service_plan.appserviceplan).*.id
}
