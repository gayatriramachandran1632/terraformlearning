//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}


//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "appserviceplan_unique_suffix" {
  for_each = var.appserviceplan
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//  Azure App Service Plan
//**********************************************************
resource "azurerm_service_plan" "appserviceplan" {
  for_each            = var.appserviceplan
  name                = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.appserviceplan_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  location            = var.resourcelocation
  resource_group_name = var.resourcegpname
  os_type             = each.value["os_type"]
  sku_name            = each.value["sku_name"]
  tags                = merge(var.rgtags, var.ars_tags, { serviceprincipalid = "${data.azurerm_client_config.config.object_id}" })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

#//**********************************************************
#//  Azure Monitor Diagnostic Categories - appserviceplan
#//**********************************************************
#data "azurerm_monitor_diagnostic_categories" "appserviceplan" {
#  for_each    = var.appserviceplan
#  resource_id = azurerm_service_plan.appserviceplan[each.key].id
#}
#
#//**********************************************************
#//  Azure Monitor Diagnostic Setting
#//**********************************************************
#resource "azurerm_monitor_diagnostic_setting" "appserviceplan_diagonistics" {
#  for_each                   = var.appserviceplan
#  name                       = "${azurerm_service_plan.appserviceplan[each.key].name}-diagnostics"
#  target_resource_id         = azurerm_service_plan.appserviceplan[each.key].id
#  log_analytics_workspace_id = var.loganalyticsworkspace_id
#
#  dynamic "metric" {
#    for_each = data.azurerm_monitor_diagnostic_categories.appserviceplan[each.key].metrics
#    content {
#      category = metric.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 15
#      }
#    }
#  }
#}
