//**********************************************************
//   HMAC Key
//**********************************************************
resource "random_id" "bastion_unique_suffix" {
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}bastion")
  }
  byte_length = 4
}

resource "azurerm_public_ip" "publicip" {
  name                = "${var.productname}${var.environmentshort}${var.regionshort}publicip${substr(random_id.bastion_unique_suffix.keepers.hmac, 0, 4)}"
  location            = var.resourcelocation
  resource_group_name = var.resourcegpname
  allocation_method   = "Static"
  sku                 = "Standard"

  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

resource "azurerm_bastion_host" "bastion" {
  name                = "${var.productname}${var.environmentshort}${var.regionshort}bastion${substr(random_id.bastion_unique_suffix.keepers.hmac, 0, 4)}"
  location            = var.resourcelocation
  resource_group_name = var.resourcegpname

  ip_configuration {
    name                 = "configuration"
    subnet_id            = var.subnet_id
    public_ip_address_id = azurerm_public_ip.publicip.id
  }

  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}
