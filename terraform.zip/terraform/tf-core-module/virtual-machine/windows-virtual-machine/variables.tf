#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "subnet_id" {
  type = string
}
variable "keyvault_id" {
  type = string
}

############################
# Windows Virtual Machine
############################

variable "windows_virtual_machine" {
  type = map(object({
    rand_value_vm        = string
    resourcetype         = string
    publisher            = string
    offer                = string
    sku                  = string
    version              = string
    storage_account_type = string
    caching              = string
    size                 = string
    admin_username       = string
  }))
}