//**********************************************************
//   HMAC Key
//**********************************************************
resource "random_id" "virtual_machine_unique_suffix" {
  for_each = var.windows_virtual_machine
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value_vm"]}")
  }
  byte_length = 4
}

//**********************************************************
//   Random Password Generation for Mongodb Database User
//**********************************************************
resource "random_password" "vmpass" {
  for_each         = var.windows_virtual_machine
  length           = 32
  min_upper        = 2
  min_lower        = 2
  min_special      = 2
  numeric          = true
  special          = true
  override_special = "!@#$%&"
}

//**********************************************************
//   Network Interface
//**********************************************************
resource "azurerm_network_interface" "nic" {
  for_each            = var.windows_virtual_machine
  name                = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.virtual_machine_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name = var.resourcegpname
  location            = var.resourcelocation
  tags                = merge(var.rgtags, var.ars_tags)

  ip_configuration {
    name                          = "internal"
    private_ip_address_allocation = "Dynamic"
    subnet_id                     = var.subnet_id
  }
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

//**********************************************************
//   Virtual Machine
//**********************************************************
resource "azurerm_windows_virtual_machine" "vm" {
  for_each                   = var.windows_virtual_machine
  name                       = "${var.productname}${var.environmentshort}${var.regionshort}${each.value.resourcetype}${substr(random_id.virtual_machine_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name        = var.resourcegpname
  location                   = var.resourcelocation
  size                       = each.value["size"]
  admin_username             = each.value["admin_username"]
  admin_password             = random_password.vmpass[each.key].result
  allow_extension_operations = false
  network_interface_ids = [
    azurerm_network_interface.nic[0].id,
  ]

  os_disk {
    caching              = each.value["caching"]
    storage_account_type = each.value["storage_account_type"]
  }

  source_image_reference {
    publisher = each.value["publisher"]
    offer     = each.value["offer"]
    sku       = each.value["sku"]
    version   = each.value["version"]
  }
  lifecycle {
    ignore_changes = [
      allow_extension_operations, tags
    ]
  }
}

//**********************************************************
//      Upload the Password to Keyvault
//**********************************************************
resource "azurerm_key_vault_secret" "vmvault" {
  for_each        = var.windows_virtual_machine
  name            = "windowsvm${each.key}"
  value           = random_password.vmpass[each.key].result
  key_vault_id    = var.keyvault_id
  expiration_date = timeadd(timestamp(), "8640h")
  lifecycle {
    ignore_changes = [
      expiration_date
    ]
  }
}
