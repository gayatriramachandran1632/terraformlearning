//**********************************************************
//   HMAC Key
//**********************************************************
resource "random_id" "linux_virtual_machine_unique_suffix" {
  for_each = var.linux_virtual_machine
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value_vm"]}")
  }
  byte_length = 4
}


//**********************************************************
//   Network Interface
//**********************************************************
resource "azurerm_network_interface" "nic" {
  for_each            = var.linux_virtual_machine
  name                = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.network_interface_short}-nic-${substr(random_id.linux_virtual_machine_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name = var.resourcegpname
  location            = var.resourcelocation
  tags                = merge(var.rgtags, var.ars_tags)

  ip_configuration {
    name                          = "internal"
    private_ip_address_allocation = "Dynamic"
    subnet_id                     = var.subnet_id
  }
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

resource "random_password" "vmpass" {
  for_each         = var.linux_virtual_machine
  length           = 32
  min_upper        = 2
  min_lower        = 2
  min_special      = 2
  numeric          = true
  special          = true
  override_special = "!@#$%&"
}


#resource "azurerm_marketplace_agreement" "linuxvm" {
#  for_each  = var.linux_virtual_machine
#  publisher = each.value["publisher"]
#  offer     = each.value["offer"]
#  plan      = each.value["sku"]
#}

//**********************************************************
//   Virtual Machine
//**********************************************************
resource "azurerm_linux_virtual_machine" "vm" {
  for_each                        = var.linux_virtual_machine
  name                            = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.linux_virtual_machine_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name             = var.resourcegpname
  location                        = var.resourcelocation
  size                            = each.value.size
  disable_password_authentication = false
  admin_username                  = each.value.admin_username
  admin_password                  = random_password.vmpass[each.key].result
  network_interface_ids = [
    azurerm_network_interface.nic[each.key].id
  ]
  ##admin_ssh_key {
  ## username = each.value.admin_username
  ## public_key = each.value.public_key
  ##}
  plan {
    name      = each.value["sku"]
    product   = each.value["offer"]
    publisher = each.value["publisher"]
  }
  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }
  source_image_reference {
    publisher = each.value["publisher"]
    offer     = each.value["offer"]
    sku       = each.value["sku"]
    version   = each.value["version"]
  }
  tags = merge(var.rgtags, var.ars_tags)
  depends_on = [azurerm_network_interface.nic
  ]
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}

//**********************************************************
//      Upload the Password to Keyvault
//**********************************************************
resource "azurerm_key_vault_secret" "vmvault" {
  for_each        = var.linux_virtual_machine
  name            = "linuxvm${each.key}"
  value           = random_password.vmpass[each.key].result
  key_vault_id    = var.keyvault_id
  expiration_date = timeadd(timestamp(), "8640h")
  lifecycle {
    ignore_changes = [
      expiration_date
    ]
  }
}
