#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "subnet_id" {
  type = string
}
variable "keyvault_id" {
  type = string
}

############################
# Linux Virtual Machine
############################

variable "linux_virtual_machine" {
  type = map(object({
    rand_value_vm  = string
    admin_username = string
    resourcetype   = string

    network_interface_short = string

    size = string

    publisher = string
    offer     = string
    sku       = string
    version   = string

  }))
}
