# # output "subnetid" {
# #  value = values(azurerm_resource_group.this).*.name
# # }

# # output "subnetid" {
# #  value = values(azurerm_resource_group.vnet).*.id
# # }


# output "subnetid" {
#   value = values(azurerm_subnet.subnet).*.id
# }

# # output "rglocation" {
# #  value = values(azurerm_resource_group.this).*.location
# # }
    