//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}


//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "databricks_unique_suffix" {
  for_each = var.databricks
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
}

//**********************************************************
//  Databricks
//**********************************************************
# NOTE: public_network_access_enabled must be false: But it needs vnet.

resource "azurerm_databricks_workspace" "databricks" {
  for_each                          = var.databricks
  name                              = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-${substr(random_id.databricks_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name               = var.resourcegpname
  location                          = var.resourcelocation
  sku                               = "premium"
  public_network_access_enabled     = true
  infrastructure_encryption_enabled = true
  managed_resource_group_name       = "${var.productname}-${var.environmentshort}-${var.regionshort}-${each.value.resourcetype}-mg-${substr(random_id.databricks_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  tags                              = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })
  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}
#
#//**********************************************************
#//  Azure Monitor Diagnostic Categories - databricks
#//**********************************************************
#data "azurerm_monitor_diagnostic_categories" "databricks" {
#  for_each    = var.databricks
#  resource_id = azurerm_databricks_workspace.databricks[each.key].id
#}
#
#//**********************************************************
#//  Azure Monitor Diagnostic Setting
#//**********************************************************
#resource "azurerm_monitor_diagnostic_setting" "databricks_diagonistics" {
#  for_each                   = var.databricks
#  name                       = "${azurerm_databricks_workspace.databricks[each.key].name}-diagnostics"
#  target_resource_id         = azurerm_databricks_workspace.databricks[each.key].id
#  log_analytics_workspace_id = var.loganalyticsworkspace_id
#
#  dynamic "log" {
#    for_each = data.azurerm_monitor_diagnostic_categories.databricks[each.key].logs
#    content {
#      category = log.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 30
#      }
#    }
#  }
#
#  dynamic "metric" {
#    for_each = data.azurerm_monitor_diagnostic_categories.databricks[each.key].metrics
#    content {
#      category = metric.value
#      enabled  = false
#
#      retention_policy {
#        enabled = true
#        days    = 15
#      }
#    }
#  }
#}
