//**********************************************************
//  Local Values
//**********************************************************
# NOTE: This code flattens the dls values and helps deploy datalake with names : raw, enriched, development
locals {
  dls_values = flatten([
    for dls_vals in var.adls : [
      for dls_val in dls_vals.dls : [
        for dls_main in dls_val : {
          dls                      = dls_main
          account_tier             = dls_vals.account_tier
          access_tier              = dls_vals.access_tier
          resource_type            = dls_vals.resourcetype
          account_kind             = dls_vals.account_kind
          account_replication_type = dls_vals.account_replication_type
          min_tls_version          = dls_vals.min_tls_version
          is_hns_enabled           = dls_vals.is_hns_enabled
          resource_type            = dls_vals.resourcetype
        }
      ]
    ]
  ])
}

//******************************************************
//  Datalake Deployment Module
//******************************************************
# NOTE: We flatten the names and then loop to create the datalakes
module "dls_create" {
  for_each                 = { for p in local.dls_values : tostring(p.dls) => p }
  source                   = "./dls_create"
  adls                     = var.adls
  environmentshort         = var.environmentshort
  hmac_key                 = var.hmac_key
  dls_name                 = "${var.productname}${var.environmentshort}${var.landingzonetype}${each.key}${each.value["resource_type"]}"
  account_tier             = each.value["account_tier"]
  account_replication_type = each.value["account_replication_type"]
  account_kind             = each.value["account_kind"]
  access_tier              = each.value["access_tier"]
  min_tls_version          = each.value["min_tls_version"]
  is_hns_enabled           = each.value["is_hns_enabled"]
  resourcegpname           = var.resourcegpname
  resourcelocation         = var.resourcelocation
  rgtags                   = var.rgtags
  ars_tags                 = var.ars_tags
  adlsfilesystems          = var.adlsfilesystems
  productname              = var.productname
  regionshort              = var.regionshort
}