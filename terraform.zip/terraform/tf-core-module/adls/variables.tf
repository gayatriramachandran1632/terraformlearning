#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}

variable "adls" {
  type = map(object({
    account_tier             = string
    account_kind             = string
    access_tier              = string
    account_replication_type = string
    min_tls_version          = string
    is_hns_enabled           = bool
    resourcetype             = string
    rand_value               = string
    dls = object({
      dls = list(string)
    })
  }))
}

variable "containers" {
  type = map(object({
    name                  = string
    storage_account_name  = string
    container_access_type = string
  }))
}

variable "adlsfilesystems" {
  type = map(object({
    name  = string
    sa_id = string
  }))
}
variable "landingzonetype" {
  type = string
}