//******************************************************
//  Module to provide Managed Identity permissions
//  This gives READER or CONTRIBUTOR access resource MI
//******************************************************

# NOTE:  data function is used to get data from already available resources
data "azurerm_subscription" "primary" {}

//*******************************************
//  Azure IAM assign permissions to resource
//*******************************************
# NOTE: RegEx checks if datalake name is RAW then give READER permission else CONTRIBUTOR

# General Permissions
resource "azurerm_role_assignment" "assignmipermissions" {
  count                = length(regexall("true", var.isService)) > 0 ? 1 : 0
  scope                = "/subscriptions/${data.azurerm_subscription.primary.subscription_id}/resourceGroups/${var.resourcegpname}/providers/Microsoft.Storage/storageAccounts/${var.resource}"
  role_definition_name = (length(regexall("raw", var.resource)) > 0 && var.isService == false) ? "Storage Blob Data Reader" : "Storage Blob Data Contributor"
  principal_id         = var.managed_id
  lifecycle {
    ignore_changes = [
      skip_service_principal_aad_check
    ]
  }
}
resource "azurerm_role_assignment" "readerpermissions" {
  count                = length(regexall("true", var.isService)) > 0 ? 1 : 0
  scope                = "/subscriptions/${data.azurerm_subscription.primary.subscription_id}/resourceGroups/${var.resourcegpname}/providers/Microsoft.Storage/storageAccounts/${var.resource}"
  role_definition_name = "Reader"
  principal_id         = var.managed_id
  lifecycle {
    ignore_changes = [
      skip_service_principal_aad_check
    ]
  }
}

# ESB Permissions
resource "azurerm_role_assignment" "esb_assignmipermissions" {
  count                = length(regexall("true", var.isesbService)) > 0 ? 1 : 0
  scope                = "/subscriptions/${data.azurerm_subscription.primary.subscription_id}/resourceGroups/${var.resourcegpname}/providers/Microsoft.Storage/storageAccounts/${var.resource}"
  role_definition_name = length(regexall("raw", var.resource)) > 0 ? "Storage Blob Data Contributor" : "Storage Blob Data Reader"
  principal_id         = var.managed_id
  lifecycle {
    ignore_changes = [
      skip_service_principal_aad_check
    ]
  }
}
# Purview Permissions
resource "azurerm_role_assignment" "purview_assignmipermissions" {
  count                = length(regexall("true", var.ispurviewService)) > 0 ? 1 : 0
  scope                = "/subscriptions/${data.azurerm_subscription.primary.subscription_id}/resourceGroups/${var.resourcegpname}/providers/Microsoft.Storage/storageAccounts/${var.resource}"
  role_definition_name = "Storage Blob Data Reader"
  principal_id         = var.managed_id
  lifecycle {
    ignore_changes = [
      skip_service_principal_aad_check
    ]
  }
}