variable "managed_id" {
  type    = string
  default = null
}
variable "resourcegpname" {
  type = string
}
variable "resource" {
  type = string
}
variable "isesbService" {
  type    = bool
  default = false
}
variable "ispurviewService" {
  type    = bool
  default = false
}
variable "isService" {
  type    = bool
  default = false
}