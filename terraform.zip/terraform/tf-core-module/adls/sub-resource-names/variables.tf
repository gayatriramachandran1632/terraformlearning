#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "vnet_id" {
  type = string
}
variable "private_endpoints" {
  type = map(object({
    name       = string
    rand_value = string
  }))
}
variable "pvtendpointrsg" {
  type = string
}
variable "pvtendpointlocation" {
  type = string
}
variable "resource_name" {
  type = string
}
variable "resource_id" {
  type = string
}
variable "dns" {
  type = list(string)
}
variable "subresource_names" {
  type = list(string)
}
variable "hmac" {
  type = string
}
variable "name" {
  type = string
}
variable "rg_name" {
  type = string
}
variable "rg_location" {
  type = string
}
