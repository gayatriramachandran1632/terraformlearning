
output "subres" {
  value = [for n in module.sub-resource-datalake : n]
}