//**********************************************************
//  Datalake Deployment
//**********************************************************


//*********************************************************
//   Client Config
//*********************************************************
data "azurerm_client_config" "config" {}
data "azurerm_subscription" "primary" {}

locals {
  subresource_names = ["file", "blob"]
}

//**********************************************************
//      HMAC Key
//**********************************************************
resource "random_id" "adls_unique_suffix" {
  for_each = var.adls
  keepers = {
    hmac = sha256("${var.environmentshort}${var.hmac_key}${each.value["rand_value"]}")
  }
  byte_length = 4
  lifecycle {
    ignore_changes = [
      keepers
    ]
  }
}

//**********************************************************
//  ADLS Gen2 Account
//**********************************************************
# NOTE: Managed Identity is active - it can be used to give access to datafactory or databricks or synapse etc

resource "azurerm_storage_account" "datalake" {
  for_each                          = var.adls
  name                              = "${var.dls_name}${substr(random_id.adls_unique_suffix[each.key].keepers.hmac, 0, 4)}"
  resource_group_name               = var.resourcegpname
  location                          = var.resourcelocation
  account_tier                      = var.account_tier
  account_replication_type          = var.account_replication_type
  account_kind                      = var.account_kind
  access_tier                       = var.access_tier
  enable_https_traffic_only         = true
  min_tls_version                   = var.min_tls_version
  is_hns_enabled                    = var.is_hns_enabled
  allow_nested_items_to_be_public   = false
  infrastructure_encryption_enabled = true

  identity {
    type = "SystemAssigned"
  }
  network_rules {
    default_action = "Allow"
    bypass         = ["AzureServices"]
    #ip_rules = ["51.138.48.35"]
  }

  blob_properties {
    container_delete_retention_policy {
      days = 30
    }
    delete_retention_policy {
      days = 30
    }
  }
  tags = merge(var.rgtags, var.ars_tags, { serviceprincipalid = data.azurerm_client_config.config.object_id })

  lifecycle {
    ignore_changes = [
      tags
    ]
  }
}


#//**********************************************************
#//  Azure Monitor Diagnostic Categories - datalake
#//**********************************************************
#data "azurerm_monitor_diagnostic_categories" "adls" {
#  for_each    = var.adls
#  resource_id = azurerm_storage_account.datalake[each.key].id
#}
#
#//**********************************************************
#//  Azure Monitor Diagnostic Setting
#//**********************************************************
#resource "azurerm_monitor_diagnostic_setting" "datalake_diagonistics" {
#  for_each                   = var.adls
#  name                       = "${azurerm_storage_account.datalake[each.key].name}-diagnostics"
#  target_resource_id         = azurerm_storage_account.datalake[each.key].id
#  log_analytics_workspace_id = var.loganalyticsworkspace_id
#
#  dynamic "log" {
#    for_each = data.azurerm_monitor_diagnostic_categories.adls[each.key].logs
#    content {
#      category = log.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 30
#      }
#    }
#  }
#
#  dynamic "metric" {
#    for_each = data.azurerm_monitor_diagnostic_categories.adls[each.key].metrics
#    content {
#      category = metric.value
#      enabled  = true
#
#      retention_policy {
#        enabled = true
#        days    = 15
#      }
#    }
#  }
#}
