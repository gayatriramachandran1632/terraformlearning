#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "adls" {
  type = map(object({
    account_tier             = string
    account_kind             = string
    access_tier              = string
    account_replication_type = string
    min_tls_version          = string
    is_hns_enabled           = bool
    resourcetype             = string
    rand_value               = string
    dls = object({
      dls = list(string)
    })
  }))
}

variable "resourcegpname" {
  type = string
}
variable "resourcelocation" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "account_tier" {
  type = string
}
variable "account_replication_type" {
  type = string
}
variable "account_kind" {
  type = string
}
variable "access_tier" {
  type = string
}
variable "min_tls_version" {
  type = string
}
variable "is_hns_enabled" {
  type = bool
}
variable "environmentshort" {
  type = string
}
variable "dls_name" {
  type = string
}
variable "rgtags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(string)
}
variable "adlsfilesystems" {
  type = map(object({
    name  = string
    sa_id = string
  }))
}
variable "productname" {
  type = string
}
variable "regionshort" {
  type = string
}