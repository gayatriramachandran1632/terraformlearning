output "sa_names" {
  value = [for x in azurerm_storage_account.datalake : x.name]
}

output "sa_ids" {
  value = [for x in azurerm_storage_account.datalake : x.id]
}

output "development_id" {
  value = one([for item in azurerm_storage_account.datalake : item if can(regex("dev", item))])
}

output "raw_id" {
  value = one([for item in azurerm_storage_account.datalake : item if can(regex("raw", item))])
}