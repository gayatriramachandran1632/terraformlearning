
output "subres" {
  value = [for n in module.sub-resource-adls : n][0]
}