output "development_id" {
  value = one([for item in module.dls_create : item if can(regex("dev", item))])
}
output "whole_output" {
  value = [for item in module.dls_create : item]
}
output "storage_account_ids" {
  value = tolist(flatten([for item in module.dls_create : tolist(item.sa_ids)]))
}
output "storage_account_names" {
  value = tolist(flatten([for item in module.dls_create : tolist(item.sa_names)]))
}