productname     = "eva"
landingzonetype = "watchdog"
regionlong      = "europe"
regionshort     = "gwc"

rsg_tags = {
  description         = "DLZ resources"
  environment         = "dev"
  businessowner       = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  technicalcontact    = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  project             = "eva-watchdog"
  provisioner         = "terraform"
  businessgroup       = "rms"
  ContactEmailAddress = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com;jan-michael.matzkovits@zeiss.com"
}

ars_tags = {
  costcenter         = "000000"
  internalorder      = "0000000000"
  region             = "europe"
  serviceprincipalid = "NA"
  repo               = "ZDP-AP_eVA_MS_MVP"
  support            = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
}

resource_groups = {
  0 = {
    location     = "Germany West Central"
    workload     = "storage"
    resourcetype = "rg"
    rg_tags = {
      workload = "storage"
    }
  },
  1 = {
    location     = "Germany West Central"
    workload     = "dataintegration"
    resourcetype = "rg"
    rg_tags = {
      workload = "dataintegration"
    }
  }
}

storage_accounts = {
  0 = {
    resourcetype             = "st"
    account_replication_type = "LRS"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_tier             = "Standard"
    rand_value               = "st01" # As mentioned at the start of the file.
    min_tls_version          = "TLS1_2"
  }
}

adls = {
  sa1 = {
    resourcetype             = "dls"
    account_tier             = "Standard"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_replication_type = "RAGRS"
    min_tls_version          = "TLS1_2"
    is_hns_enabled           = true
    rand_value               = "dls01" # As mentioned at the start of the file.
    dls = {
      dls = [
        "raw", "enr", "dev"
      ]
    }
  }
}

containers = {
  container1 = {
    name                  = "test"
    storage_account_name  = "sa1"
    container_access_type = "private"
  }
}

adlsfilesystems = {
  adlsfilesystem1 = {
    name  = "adlsfilesystem1"
    sa_id = "sa1"
  }
}

application_insights = {
  1 = {
    resourcetype         = "appi"
    application_type     = "web"
    retention_in_days    = 60
    daily_data_cap_in_gb = 10
    rand_value           = "appi01" # As mentioned at the start of the file.
  }
}
synapse_workspace = {
  0 = {
    resourcetype   = "synw"
    rand_value     = "synw01" # As mentioned at the start of the file.
    synsp_nodesize = "Small"
  }
}

keyvault = {
  0 = {
    resourcetype                    = "kv"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    purge_protection_enabled        = true
    sku_name                        = "standard"
    rand_value                      = "kvt02" # As mentioned at the start of the file.
  }
}