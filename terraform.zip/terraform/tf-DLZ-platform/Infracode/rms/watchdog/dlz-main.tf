//**********************************************************
//  Resource Group
//**********************************************************
module "resourcegroup" {
  source          = "../../../../tf-core-module/resource-group"
  resource_groups = var.resource_groups
  productname     = var.productname
  environmentlong = var.environmentlong
  landingzonetype = var.landingzonetype
  regionlong      = var.regionlong
  rsg_tags        = var.rsg_tags
}
//**********************************************************
//  Storage
//**********************************************************
module "storage" {
  source           = "../../../../tf-core-module/storage"
  storage_accounts = var.storage_accounts
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.1
  resourcelocation = module.resourcegroup.rglocation.1
  ars_tags         = var.ars_tags
  rgtags           = module.resourcegroup.rgtags.1
  hmac_key         = var.hmac_key
  landingzonetype  = var.landingzonetype
  depends_on = [
    module.adls
  ]
}

//**********************************************************
//  Data Lake - ADLS
//**********************************************************
module "adls" {
  source           = "../../../../tf-core-module/adls"
  adls             = var.adls
  containers       = var.containers
  adlsfilesystems  = var.adlsfilesystems
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.0
  resourcelocation = module.resourcegroup.rglocation.0
  ars_tags         = var.ars_tags
  rgtags           = module.resourcegroup.rgtags.0
  hmac_key         = var.hmac_key
  landingzonetype  = var.landingzonetype
}


//*********************************
//  Keyvault
//*********************************
module "keyvault" {
  source           = "../../../../tf-core-module/keyvault"
  keyvault         = var.keyvault
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.1
  resourcelocation = module.resourcegroup.rglocation.1
  ars_tags         = var.ars_tags
  rgtags           = module.resourcegroup.rgtags.1
  hmac_key         = var.hmac_key
  depends_on = [
    module.adls
  ]
}

//**********************************************************
//  Synapse Workspace
//**********************************************************
module "synapse_workspace" {
  for_each             = var.adlsfilesystems
  source               = "../../../../tf-core-module/synapse-analytics"
  synapse_workspace    = var.synapse_workspace
  productname          = var.productname
  environmentshort     = var.environmentshort
  regionshort          = var.regionshort
  resourcegpname       = module.resourcegroup.rgname.1
  resourcelocation     = module.resourcegroup.rglocation.1
  storage_data_lake_id = module.storage.sa_id.0
  adlsfilesystems      = each.value["name"]
  ars_tags             = var.ars_tags
  rgtags               = module.resourcegroup.rgtags.1
  hmac_key             = var.hmac_key
  sqldbpass            = var.sqldbpass
  sqlusername          = var.sqlusername
  landingzonetype      = var.landingzonetype
  depends_on = [
    module.keyvault,
    module.adls,
    module.storage
  ]
}

module "syn_permission" {
  source         = "../../../../tf-core-module/adls/permission"
  managed_id     = [for item in module.synapse_workspace["adlsfilesystem1"] : item[0].identity[0].principal_id][0]
  resourcegpname = module.resourcegroup.rgname.0
  resource       = flatten(module.adls.storage_account_names)
  depends_on = [
    module.synapse_workspace,
    module.adls
  ]
}

module "kvt_permission_for_synapse" {
  source         = "../../../../tf-core-module/keyvault/permission"
  managed_id     = [for item in module.synapse_workspace["adlsfilesystem1"] : item[0].identity[0].principal_id][0]
  keyvault_id    = module.keyvault.key_vault_id[0]
  resourcegpname = module.resourcegroup.rgname.1

  depends_on = [
    module.synapse_workspace,
    module.keyvault
  ]
}