#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "environmentlong" {
  type = string
}
variable "regionlong" {
  type = string
}
variable "landingzonetype" {
  type = string
}

variable "hmac_key" {
  type = string
}

variable "rsg_tags" {
  type = map(string)
}

variable "ars_tags" {
  type = map(any)
}
variable "sqlusername" {
  type      = string
  sensitive = true
}
variable "sqldbpass" {
  type      = string
  sensitive = true
}

#############################################################
## Resource Group variables
#############################################################
variable "resource_groups" {
  description = "Resource groups"
  type = map(object({
    location = string
    #name              = string   
    workload     = string
    resourcetype = string
    rg_tags      = map(string)
  }))
}

#########################################
#Storage Account
#########################################

variable "storage_accounts" {
  description = "storageaccounts"
  type = map(object({
    account_tier             = string
    account_replication_type = string
    access_tier              = string
    account_kind             = string
    resourcetype             = string
    rand_value               = string
    min_tls_version          = string
  }))
}

######################################
# ADLS Account
###################################

variable "adls" {
  type = map(object({
    account_tier             = string
    account_kind             = string
    access_tier              = string
    account_replication_type = string
    min_tls_version          = string
    is_hns_enabled           = bool
    resourcetype             = string
    rand_value               = string
    dls = object({
      dls = list(string)
    })
  }))
}

//**********************************************************
//  Keyvault Variables
//**********************************************************
variable "keyvault" {
  type = map(object({
    enabled_for_deployment          = bool
    enabled_for_disk_encryption     = bool
    enabled_for_template_deployment = bool
    purge_protection_enabled        = bool
    sku_name                        = string
    resourcetype                    = string
    rand_value                      = string
  }))
}

variable "containers" {
  type = map(object({
    name                  = string
    storage_account_name  = string
    container_access_type = string
  }))
}

variable "adlsfilesystems" {
  type = map(object({
    name  = string
    sa_id = string
  }))
}

#######################################
## Application Insights
#######################################

variable "application_insights" {
  type = map(object({
    application_type     = string
    retention_in_days    = number
    daily_data_cap_in_gb = number
    resourcetype         = string
    rand_value           = string
  }))
}

############################################
# Synapse Analytics
############################################

variable "synapse_workspace" {
  type = map(object({
    resourcetype   = string
    rand_value     = string
    synsp_nodesize = string
  }))
}
