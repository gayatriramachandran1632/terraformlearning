data "azurerm_subscription" "config" {}

//**********************************************************
//  Resource Group
//**********************************************************

module "resourcegroup" {
  source           = "../../../../tf-core-module/resource-group"
  resource_groups  = var.resource_groups
  productname      = var.productname
  environmentlong  = var.environmentlong
  landingzonetype  = var.landingzonetype
  regionlong       = var.regionlong
  rsg_tags         = var.rsg_tags
  deploymentregion = var.deploymentregion
}

module "use-role" {
  source = "../../../../tf-core-module/network-iam-role/use-role"
  depends_on = [
    module.resourcegroup
  ]
}
module "networkIAM_storage" {
  source      = "../../../../tf-core-module/network-iam-role"
  scope_id    = [for n in module.resourcegroup.rgid : n if can(regex("storage", n))][0]
  principleID = var.networking_sp_id
  depends_on = [
    module.use-role
  ]
}
//*********************************
//  Network
//*********************************
module "get_network" {
  source                  = "../../../../tf-core-module/network/reference_vnet"
  dest_vnet_required_tags = "eva-ibase"
  dest_environmentlong    = var.environmentlong
  dest_landingzonetype    = "ibase"
  productname             = var.productname
  regionlong              = var.regionlong
  providers = {
    azurerm.destination = azurerm
  }
}
//*********************************
//  Network
//*********************************
module "get_logging_app_insights" {
  source                  = "../../../../tf-core-module/application-insights/reference_logging"
  dest_vnet_required_tags = "eva-ibase"
  dest_environmentlong    = var.environmentlong
  dest_landingzonetype    = "ibase"
  productname             = var.productname
  regionlong              = var.regionlong
  providers = {
    azurerm.destination = azurerm
  }
}
//**********************************************************
//  Keyvault
//**********************************************************
module "keyvault" {
  source           = "../../../../tf-core-module/keyvault"
  keyvault         = var.keyvault
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.2
  resourcelocation = var.deploymentregion
  rgtags           = module.resourcegroup.rgtags.2
  ars_tags         = var.ars_tags
  hmac_key         = var.hmac_key

  depends_on = [
    module.resourcegroup
  ]
}

module "resource-loop-kvt" {
  for_each            = { for p in flatten(module.keyvault.key_vault_name) : tostring(p) => p }
  source              = "../../../../tf-core-module/keyvault/resource_loop"
  name                = [join("", ["/subscriptions/", data.azurerm_subscription.config.subscription_id, "/resourceGroups/${module.resourcegroup.rgname.2}/providers/Microsoft.KeyVault/vaults/", each.value])]
  hmac                = substr(each.value, -4, 0)
  pvtendpointrsg      = [for n in module.get_network : n][0]["resource_group_name"]
  pvtendpointlocation = var.deploymentregion
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.get_network : n][0]["resources"][0]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("vaultcore", n))]
  rg_location         = var.deploymentregion
  rg_name             = [for n in module.get_network : n][0]["resource_group_name"]
  providers = {
    azurerm.destination = azurerm
  }
}
module "dns_zone_a_record_keyvault" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-kvt : n][0]["subres"]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-kvt : n][0]["subres"]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "vaultcore"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
//**********************************************************
//  Function App Service Plan
//**********************************************************

//**********************************************************
//  Function App Service Plan
//**********************************************************
module "appserviceplan" {
  source           = "../../../../tf-core-module/appserviceplan"
  appserviceplan   = var.appserviceplan
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.1
  resourcelocation = var.deploymentregion
  hmac_key         = var.hmac_key
  ars_tags         = var.ars_tags
  rgtags           = var.rsg_tags

  depends_on = [
    module.keyvault
  ]
}

//**********************************************************
//  Azure Functions Storage Account
//**********************************************************
module "functionsta" {
  source                    = "../../../../tf-core-module/functionapp-storage"
  function_storage_accounts = var.function_storage_accounts
  productname               = var.productname
  environmentshort          = var.environmentshort
  regionshort               = var.regionshort
  resourcegpname            = module.resourcegroup.rgname.0
  resourcelocation          = var.deploymentregion
  hmac_key                  = var.hmac_key
  ars_tags                  = var.ars_tags
  rgtags                    = var.rsg_tags
  landingzonetype           = var.landingzonetype

  depends_on = [
    module.keyvault
  ]
}
module "resource-loop-functionsapp-storage" {
  for_each            = { for p in flatten(module.functionsta.functionappsaname) : tostring(p) => p }
  source              = "../../../../tf-core-module/storage/resource_loop"
  name                = [join("", ["/subscriptions/", data.azurerm_subscription.config.subscription_id, "/resourceGroups/${module.resourcegroup.rgname.0}/providers/Microsoft.Storage/storageAccounts/", each.value])]
  hmac                = substr(each.value, -4, 0)
  pvtendpointrsg      = [for n in module.get_network : n][0]["resource_group_name"]
  pvtendpointlocation = var.deploymentregion
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.get_network : n][0]["resources"][0]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("blob.core|file.core|queue.core|table.core", n))]
  rg_location         = var.deploymentregion
  rg_name             = [for n in module.get_network : n][0]["resource_group_name"]
  providers = {
    azurerm.destination = azurerm
  }
}

# functions app
module "dns_zone_a_record_adls_fapp_blob" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "blob.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_fapp_file" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "file.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_fapp_queue" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "queue.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_fapp_table" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "table.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
//**********************************************************
//  Azure Functions
//**********************************************************
module "functionapp" {
  source              = "../../../../tf-core-module/functionapp"
  functionapp         = var.functionapp
  productname         = var.productname
  environmentshort    = var.environmentshort
  regionshort         = var.regionshort
  resourcegpname      = module.resourcegroup.rgname.1
  resourcelocation    = var.deploymentregion
  hmac_key            = var.hmac_key
  ars_tags            = var.ars_tags
  rgtags              = var.rsg_tags
  appserviceplanid    = module.appserviceplan.appserviceplanid.0
  storageaccesskey    = module.functionsta.functionappsakey.0
  storageaccountname  = module.functionsta.functionappsaname.0
  instrumentation_key = [for n in module.get_logging_app_insights : n][0]
  subnet_id           = join("", [[for n in module.get_network : n][0]["resources"][0]["id"]], ["/subnets/DataProductMach1"])

  depends_on = [
    module.keyvault
  ]
}
module "resource-loop-functionsapp" {
  for_each            = { for n in module.functionapp.funcapp : n.name => n.name }
  source              = "../../../../tf-core-module/functionapp/resource_loop"
  name                = [join("", ["/subscriptions/", data.azurerm_subscription.config.subscription_id, "/resourceGroups/${module.resourcegroup.rgname.1}/providers/Microsoft.Web/sites/", each.value])]
  hmac                = substr(module.functionsta.functionappsaname[0], -4, 0)
  pvtendpointrsg      = [for n in module.get_network : n][0]["resource_group_name"]
  pvtendpointlocation = var.deploymentregion
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.get_network : n][0]["resources"][0]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("azurewebsites", n))]
  rg_location         = var.deploymentregion
  rg_name             = [for n in module.get_network : n][0]["resource_group_name"]
  providers = {
    azurerm.destination = azurerm
  }
}
module "dns_zone_a_record_functionapp" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "azurewebsites"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_functionapp_transform" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "azurewebsites"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_functionapp_scm" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = join("", [split(".", [for n in module.resource-loop-functionsapp : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["fqdn"])[0]], ["."], [split(".", [for n in module.resource-loop-functionsapp : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["fqdn"])[1]])
  ipaddress               = [for n in module.resource-loop-functionsapp : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "azurewebsites"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_functionapp_transform_scm" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = join("", [split(".", [for n in module.resource-loop-functionsapp : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["fqdn"])[0]], ["."], [split(".", [for n in module.resource-loop-functionsapp : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["fqdn"])[1]])
  ipaddress               = [for n in module.resource-loop-functionsapp : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "azurewebsites"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}

//*********************************************
//  FunctionsApp ManagedIdentity Permissions
//*********************************************
module "funcapp_permission" {
  for_each       = { for p in flatten(module.functionsta.functionappsaname) : tostring(p) => p }
  source         = "../../../../tf-core-module/adls/permission"
  isService      = true
  managed_id     = module.functionapp.function_app_mi[0].principal_id
  resourcegpname = module.resourcegroup.rgname.0
  resource       = each.key
  depends_on = [
    module.functionapp,
    module.keyvault
  ]
}