productname     = "eva"
landingzonetype = "mach1"

rsg_tags = {
  description         = "DLZ resources"
  environment         = "dev"
  businessowner       = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  technicalcontact    = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  project             = "eva-mach1"
  provisioner         = "terraform"
  businessgroup       = "iqs"
  ContactEmailAddress = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com;jan-michael.matzkovits@zeiss.com"
}

ars_tags = {
  costcenter         = "000000"
  internalorder      = "0000000000"
  region             = "europe"
  serviceprincipalid = "NA"
  repo               = "ZDP-AP_eVA_MS_MVP"
  support            = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
}

resource_groups = {
  0 = {
    workload     = "storage"
    resourcetype = "rg"
    rg_tags = {
      workload = "storage"
    }
  },
  1 = {
    workload     = "dataintegration"
    resourcetype = "rg"
    rg_tags = {
      workload = "dataintegration"
    }
  },
  2 = {
    workload     = "management"
    resourcetype = "rg"
    rg_tags = {
      workload = "management"
    }
  }
}


storage_accounts = {
  0 = {
    resourcetype             = "st"
    account_replication_type = "LRS"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_tier             = "Standard"
    rand_value               = "st01" # Please check wiki
    min_tls_version          = "TLS1_2"
  }
}
statabledeployment = 1
staqueuedeployment = 1

adlsfilesystems = {
  adlsfilesystem1 = {
    name  = "adlsfilesystem1"
    sa_id = "sa1"
  }
}

keyvault = {
  0 = {
    resourcetype                    = "kv"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    purge_protection_enabled        = true
    sku_name                        = "standard"
    rand_value                      = "kvtmach1" # Please check wiki
  }
}

function_storage_accounts = {
  0 = {
    resourcetype             = "fas"
    account_replication_type = "LRS"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_tier             = "Standard"
    rand_value               = "funcstamach01" # Please check wiki
  }
}
appserviceplan = {
  0 = {
    resourcetype = "plan"
    os_type      = "Linux"
    sku_name     = "S1"
    rand_value   = "planmach101" # Please check wiki
  }
}
functionapp = {
  0 = {
    resourcetype    = "fa"
    serviceplan_key = 0
    project_area    = "egressapi"
    ostype          = "linux"
    rand_value      = "funcmach101" # Please check wiki
  }
  1 = {
    resourcetype    = "fa"
    serviceplan_key = 0
    project_area    = "processing"
    ostype          = "linux"
    rand_value      = "funcmach101" # Please check wiki
  }
}

queue = {
  q1 = {
    name                 = "queue1"
    storage_account_name = "0"
    rand_value           = "queue01" # Please check wiki
  }
}

private_endpoints = {
  0 = {
    name       = "pe"
    rand_value = "pemach101" # Please check wiki
  }
}