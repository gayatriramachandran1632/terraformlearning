output "rsg" {
  value = module.resourcegroup
}