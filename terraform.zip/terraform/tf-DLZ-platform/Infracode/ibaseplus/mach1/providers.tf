data "azurerm_client_config" "config" {}

terraform {
  required_version = ">= 0.15"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.18.0"
    }
  }
  backend "azurerm" {
  }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_deleted_keys_on_destroy    = false
      purge_soft_deleted_secrets_on_destroy = false
    }
  }
}

provider "azurerm" {
  features {}
  alias                      = "destination"
  subscription_id            = var.peering_subscriptionid
  client_id                  = var.peering_clientid
  client_secret              = var.peering_clientsecret
  tenant_id                  = data.azurerm_client_config.config.tenant_id
  skip_provider_registration = true
}
