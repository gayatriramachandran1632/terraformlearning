#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "environmentlong" {
  type = string
}
variable "regionlong" {
  type = string
}
variable "landingzonetype" {
  type = string
}
variable "networking_filepath" {
  type    = string
  default = ""
}
variable "platform" {
  type    = string
  default = ""
}
variable "hmac_key" {
  type = string
}
variable "rsg_tags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(any)
}
variable "statabledeployment" {
  type = string
}
variable "staqueuedeployment" {
  type = string
}
variable "networking_sp_id" {
  type = string
}
variable "peering_subscriptionid" {
  type = string
}
variable "peering_clientid" {
  type = string
}
variable "peering_clientsecret" {
  type = string
}
variable "alldnssecretsaslist" {
  type = string
}

variable "peering_name_src_to_dest" {
  type = string
}
variable "peering_name_dest_to_src" {
  type = string
}
variable "dest_environment_long" {
  type = string
}
variable "deploymentregion" {
  type = string
}
#############################################################
## Common variables that are used for mongodb instances
#############################################################

variable "orgid" {
  type = string
}
variable "ownerid" {
  type = string
}
variable "apikeyid" {
  type = string
}
variable "publickey" {
  type      = string
  sensitive = true
}
variable "privatekey" {
  type      = string
  sensitive = true
}
variable "pviewaccid" {
  type = string
}
variable "purviewMID" {
  type = string
}
variable "lawid" {
  type = string
}
variable "lztype" {
  type = string
}

#############################################################
## Resource Group variables
#############################################################
variable "resource_groups" {
  description = "Resource groups"
  type = map(object({
    #name              = string   
    workload     = string
    resourcetype = string
    rg_tags      = map(string)
  }))
}

#########################################
#Storage Account
#########################################

variable "storage_accounts" {
  description = "storageaccounts"
  type = map(object({
    account_tier             = string
    account_replication_type = string
    access_tier              = string
    account_kind             = string
    resourcetype             = string
    rand_value               = string
    min_tls_version          = string
  }))
}

variable "adlsfilesystems" {
  type = map(object({
    name  = string
    sa_id = string
  }))
}

#############################################################
# Private Endpoint
#############################################################
variable "private_endpoints" {
  type = map(object({
    name       = string
    rand_value = string
  }))
}
//**********************************************************
//  Keyvault Variables
//**********************************************************
variable "keyvault" {
  type = map(object({
    enabled_for_deployment          = bool
    enabled_for_disk_encryption     = bool
    enabled_for_template_deployment = bool
    purge_protection_enabled        = bool
    sku_name                        = string
    resourcetype                    = string
    rand_value                      = string
  }))
}


#############################################################
# App Service Plan
#############################################################
variable "appserviceplan" {
  type = map(object({
    resourcetype = string
    rand_value   = string
    os_type      = string
    sku_name     = string
  }))
}

#############################################################
# Function Storage Account
#############################################################
variable "function_storage_accounts" {
  type = map(object({
    resourcetype             = string
    account_replication_type = string
    account_kind             = string
    access_tier              = string
    account_tier             = string
    rand_value               = string
  }))
}

#############################################################
# Function App
#############################################################
variable "functionapp" {
  type = map(object({
    resourcetype    = string
    serviceplan_key = string
    project_area    = string
    ostype          = string
    rand_value      = string
  }))
}

#############################################################
# Queue
#############################################################

variable "queue" {
  type = map(object({
    name                 = string
    storage_account_name = string
    rand_value           = string
  }))
}