data "azurerm_subscription" "config" {}

//**********************************************************
//  Resource Group
//**********************************************************

module "resourcegroup" {
  source           = "../../../../tf-core-module/resource-group"
  resource_groups  = var.resource_groups
  deploymentregion = var.deploymentregion
  productname      = var.productname
  environmentlong  = var.environmentlong
  landingzonetype  = var.landingzonetype
  regionlong       = var.regionlong
  rsg_tags         = var.rsg_tags
}

module "use-role" {
  source = "../../../../tf-core-module/network-iam-role/use-role"
  depends_on = [
    module.resourcegroup
  ]
}
module "networkIAM_network" {
  source      = "../../../../tf-core-module/network-iam-role"
  scope_id    = [for n in module.resourcegroup.rgid : n if can(regex("network", n))][0]
  principleID = var.networking_sp_id
  depends_on = [
    module.use-role
  ]
}
module "networkIAM_governance" {
  source      = "../../../../tf-core-module/network-iam-role"
  scope_id    = [for n in module.resourcegroup.rgid : n if can(regex("governance", n))][0]
  principleID = var.networking_sp_id
  depends_on = [
    module.use-role
  ]
}
//*********************************
//  Network
//*********************************
module "network" {
  source                  = "../../../../tf-core-module/network"
  virtual_networks        = var.virtual_networks
  productname             = var.productname
  environmentshort        = var.environmentshort
  regionshort             = var.regionshort
  resourcegpname          = module.resourcegroup.rgname.3
  resourcelocation        = var.deploymentregion
  ars_tags                = var.ars_tags
  rgtags                  = module.resourcegroup.rgtags.3
  hmac_key                = var.hmac_key
  networking_filepath     = var.networking_filepath
  platform                = var.platform
  network_security_groups = var.network_security_groups
  depends_on = [
    module.resourcegroup
  ]
}

//**********************************************************
//  Keyvault
//**********************************************************
module "keyvault" {
  source           = "../../../../tf-core-module/keyvault"
  keyvault         = var.keyvault
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.4
  resourcelocation = var.deploymentregion
  rgtags           = module.resourcegroup.rgtags.4
  ars_tags         = var.ars_tags
  hmac_key         = var.hmac_key

  depends_on = [
    module.network
  ]
}

module "resource-loop-kvt" {
  for_each            = { for p in flatten(module.keyvault.key_vault_name) : tostring(p) => p }
  source              = "../../../../tf-core-module/keyvault/resource_loop"
  name                = [join("", ["/subscriptions/", data.azurerm_subscription.config.subscription_id, "/resourceGroups/${module.resourcegroup.rgname.4}/providers/Microsoft.KeyVault/vaults/", each.value])]
  hmac                = substr(each.value, -4, 0)
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = var.deploymentregion
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("vaultcore", n))]
  rg_location         = var.deploymentregion
  rg_name             = module.resourcegroup.rgname.3
  providers = {
    azurerm.destination = azurerm
  }
}
module "dns_zone_a_record_keyvault" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-kvt : n][0]["subres"]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-kvt : n][0]["subres"]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "vaultcore"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
//********************************************************
//  Data Lake - ADLS
//********************************************************
module "adls" {
  source           = "../../../../tf-core-module/adls"
  adls             = var.adls
  containers       = var.containers
  adlsfilesystems  = var.adlsfilesystems
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.0
  resourcelocation = var.deploymentregion
  rgtags           = module.resourcegroup.rgtags.0
  ars_tags         = var.ars_tags
  hmac_key         = var.hmac_key
  landingzonetype  = var.landingzonetype

  depends_on = [
    module.keyvault
  ]
}
module "resource-loop-adls" {
  for_each            = { for n in module.adls.storage_account_names : n => n }
  source              = "../../../../tf-core-module/adls/resource_loop"
  name                = [join("", ["/subscriptions/", data.azurerm_subscription.config.subscription_id, "/resourceGroups/${module.resourcegroup.rgname.0}/providers/Microsoft.Storage/storageAccounts/", each.value])]
  hmac                = substr(module.adls.storage_account_names[0], -4, 0)
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = var.deploymentregion
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("blob.core|file.core|queue.core|table.core", n))]
  rg_location         = var.deploymentregion
  rg_name             = module.resourcegroup.rgname.3
  providers = {
    azurerm.destination = azurerm
  }
}
# Datalake
# NOTE: This part has to be automated
# Datalake
# NOTE: This part has to be automated
module "dns_zone_a_record_adls_dev_blob" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "blob.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_dev_file" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][0]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][0]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "file.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_dev_queue" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][0]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][0]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "queue.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_dev_table" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][0]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][0]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "table.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
# enriched
module "dns_zone_a_record_adls_enr_blob" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "blob.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_enr_file" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][1]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][1]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "file.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_enr_queue" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][1]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][1]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "queue.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_enr_table" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][1]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][1]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "table.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
# raw
module "dns_zone_a_record_adls_raw_blob" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][2]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][2]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "blob.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_raw_file" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][2]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][2]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "file.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_raw_queue" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][2]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][2]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "queue.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_raw_table" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-adls : n][2]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-adls : n][2]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "table.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
//*********************************
// Application Insights
//*********************************
module "applicationinsights" {
  source                  = "../../../../tf-core-module/application-insights"
  application_insights    = var.application_insights
  productname             = var.productname
  environmentshort        = var.environmentshort
  regionshort             = var.regionshort
  resourcegpname          = module.resourcegroup.rgname.1
  resourcelocation        = var.deploymentregion
  ars_tags                = var.ars_tags
  rgtags                  = module.resourcegroup.rgtags.1
  hmac_key                = var.hmac_key
  loganalyticsworkspaceid = var.lawid
}

//**********************************************************
//  Function App Service Plan
//**********************************************************

//**********************************************************
//  Function App Service Plan
//**********************************************************
module "appserviceplan" {
  source           = "../../../../tf-core-module/appserviceplan"
  appserviceplan   = var.appserviceplan
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.2
  resourcelocation = var.deploymentregion
  hmac_key         = var.hmac_key
  ars_tags         = var.ars_tags
  rgtags           = var.rsg_tags

  depends_on = [
    module.keyvault
  ]
}

//**********************************************************
//  Azure Functions Storage Account
//**********************************************************
module "functionsta" {
  source                    = "../../../../tf-core-module/functionapp-storage"
  function_storage_accounts = var.function_storage_accounts
  productname               = var.productname
  environmentshort          = var.environmentshort
  regionshort               = var.regionshort
  resourcegpname            = module.resourcegroup.rgname.0
  resourcelocation          = var.deploymentregion
  hmac_key                  = var.hmac_key
  ars_tags                  = var.ars_tags
  rgtags                    = var.rsg_tags
  landingzonetype           = var.landingzonetype

  depends_on = [
    module.keyvault
  ]
}

module "resource-loop-functionsapp-storage" {
  for_each            = { for n in module.functionsta.functionappsaname : n => n }
  source              = "../../../../tf-core-module/storage/resource_loop"
  name                = [join("", ["/subscriptions/", data.azurerm_subscription.config.subscription_id, "/resourceGroups/${module.resourcegroup.rgname.0}/providers/Microsoft.Storage/storageAccounts/", each.value])]
  hmac                = substr(module.functionsta.functionappsaname[0], -4, 0)
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = var.deploymentregion
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("blob.core|file.core|queue.core|table.core", n))]
  rg_location         = var.deploymentregion
  rg_name             = module.resourcegroup.rgname.3
  providers = {
    azurerm.destination = azurerm
  }
}
# functions app
module "dns_zone_a_record_adls_fapp_blob" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "blob.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_fapp_file" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][1]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "file.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_fapp_queue" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][2]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "queue.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_adls_fapp_table" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp-storage : n][0]["subres"]["subres"][3]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "table.core"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}

//**********************************************************
//  Azure Functions
//**********************************************************
module "functionapp" {
  source              = "../../../../tf-core-module/functionapp"
  functionapp         = var.functionapp
  productname         = var.productname
  environmentshort    = var.environmentshort
  regionshort         = var.regionshort
  resourcegpname      = module.resourcegroup.rgname.2
  resourcelocation    = var.deploymentregion
  hmac_key            = var.hmac_key
  ars_tags            = var.ars_tags
  rgtags              = var.rsg_tags
  appserviceplanid    = module.appserviceplan.appserviceplanid.0
  storageaccesskey    = module.functionsta.functionappsakey.0
  storageaccountname  = module.functionsta.functionappsaname.0
  instrumentation_key = module.applicationinsights.key.0
  subnet_id           = join("", [[for n in module.network.vnetid : n[0]][1]["id"]], ["/subnets/DataProduct"])

  depends_on = [
    module.keyvault
  ]
}
module "resource-loop-functionsapp" {
  for_each            = { for n in module.functionapp.funcapp : n.name => n.name }
  source              = "../../../../tf-core-module/functionapp/resource_loop"
  name                = [join("", ["/subscriptions/", data.azurerm_subscription.config.subscription_id, "/resourceGroups/${module.resourcegroup.rgname.2}/providers/Microsoft.Web/sites/", each.value])]
  hmac                = substr(module.functionsta.functionappsaname[0], -4, 0)
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = var.deploymentregion
  private_endpoints   = var.private_endpoints
  productname         = var.productname
  regionshort         = var.regionshort
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  hmac_key            = var.hmac_key
  environmentshort    = var.environmentshort
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("azurewebsites", n))]
  rg_location         = var.deploymentregion
  rg_name             = module.resourcegroup.rgname.3
  providers = {
    azurerm.destination = azurerm
  }
}
module "dns_zone_a_record_functionapp" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "azurewebsites"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_functionapp_transform" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = split(".", [for n in module.resource-loop-functionsapp : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["fqdn"])[0]
  ipaddress               = [for n in module.resource-loop-functionsapp : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][0]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "azurewebsites"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_functionapp_scm" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = join("", [split(".", [for n in module.resource-loop-functionsapp : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["fqdn"])[0]], ["."], [split(".", [for n in module.resource-loop-functionsapp : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["fqdn"])[1]])
  ipaddress               = [for n in module.resource-loop-functionsapp : n][0]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "azurewebsites"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}
module "dns_zone_a_record_functionapp_transform_scm" {
  source                  = "../../../../tf-core-module/dns/dns-a-record-source-to-connectivity-connection"
  productname             = var.productname
  regionlong              = var.regionlong
  dest_vnet_required_tags = "eva"
  dest_environmentlong    = var.dest_environment_long
  dest_landingzonetype    = "mgc"
  fqdn                    = join("", [split(".", [for n in module.resource-loop-functionsapp : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["fqdn"])[0]], ["."], [split(".", [for n in module.resource-loop-functionsapp : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["fqdn"])[1]])
  ipaddress               = [for n in module.resource-loop-functionsapp : n][1]["subres"]["subres"][0]["subres"][0]["endpoint"][1]["ip_addresses"][0]
  dns                     = [for n in split(",", var.alldnssecretsaslist) : n]
  filter                  = "azurewebsites"
  dest_clientid           = var.peering_clientid
  dest_clientsecret       = var.peering_clientsecret
  dest_subscriptionid     = var.peering_subscriptionid
}

//*********************************************
//  FunctionsApp ManagedIdentity Permissions
//*********************************************
module "funcapp_permission" {
  for_each       = { for p in flatten(module.adls.storage_account_names) : tostring(p) => p }
  source         = "../../../../tf-core-module/adls/permission"
  isService      = true
  managed_id     = module.functionapp.function_app_mi[0].principal_id
  resourcegpname = module.resourcegroup.rgname.0
  resource       = each.key
  depends_on = [
    module.functionapp,
    module.adls,
    module.keyvault
  ]
}

//*************************************************************
// Peer DMLZ non-prod mgmt to non-prod connectivity
// Spoke service principal should have Network contributor access
// Connectivity to DLZ1 subscription
//*************************************************************
module "peering" {
  source                   = "../../../../tf-core-module/network/peering"
  productname              = var.productname
  regionlong               = var.regionlong
  src_vnet_id              = [for n in module.network.vnetid : n[0]][1]["id"]
  src_vnet_name            = [for n in module.network.vnetid : n[0]][1]["name"]
  src_vnet_rsg_name        = module.resourcegroup.rgname.3
  dest_vnet_required_tags  = "eva"
  dest_environmentlong     = var.dest_environment_long
  dest_landingzonetype     = "mgc"
  dest_clientid            = var.peering_clientid
  dest_clientsecret        = var.peering_clientsecret
  dest_subscriptionid      = var.peering_subscriptionid
  peering_name_src_to_dest = var.peering_name_src_to_dest
  peering_name_dest_to_src = var.peering_name_dest_to_src
  rsg_tags                 = module.resourcegroup.rgtags.3
}

module "pvtlink" {
  source                 = "../../../../tf-core-module/network/private-endpoint/pvtlink"
  dest_clientid          = var.peering_clientid
  dest_clientsecret      = var.peering_clientsecret
  dest_subscriptionid    = var.peering_subscriptionid
  productname            = var.productname
  regionlong             = var.regionlong
  dest_environmentlong   = var.dest_environment_long
  dest_landingzonetype   = "mgc"
  source_landingzonetype = var.lztype
  dns                    = [for n in split(",", var.alldnssecretsaslist) : n]
  src_vnet_id            = [for n in module.network.vnetid : n[0]][1]["id"]
}

//**********************************************************
//  Mongodbatlas
//**********************************************************
module "mongodb" {
  source           = "../../../../tf-core-module/mongodb"
  mongodbatlas     = var.mongodbatlas
  productname      = var.productname
  environmentshort = var.environmentshort
  keyvault_id      = module.keyvault.key_vault_id[0]
  regionshort      = var.resourceregion
  hmac_key         = var.hmac_key
  orgid            = var.orgid
  ownerid          = var.ownerid
  apikeyid         = var.apikeyid
  privatekey       = var.privatekey
  publickey        = var.publickey
}

// //**********************************************************
// //  PIM assignment
// //**********************************************************
// module "pim_assignment" {
//   source            = "../../../../tf-core-module/pim"
//   eligiblerequestid = var.eligiblerequestid
//   productname       = var.productname
//   environmentshort  = var.environmentshort
//   hmac_key          = var.hmac_key
// }

//****************************************************
// ESB SP permissions to ADLS RAW storage blob
//***************************************************
module "esb_permission" {
  for_each       = { for p in flatten(module.adls.storage_account_names) : tostring(p) => p }
  source         = "../../../../tf-core-module/adls/permission"
  isesbService   = true
  managed_id     = var.esbMID
  resourcegpname = module.resourcegroup.rgname.0
  resource       = each.key
  depends_on = [
    module.adls
  ]
}

module "purview_permission" {
  for_each         = { for p in flatten(module.adls.storage_account_names) : tostring(p) => p }
  source           = "../../../../tf-core-module/adls/permission"
  ispurviewService = true
  managed_id       = var.purviewMID
  resourcegpname   = module.resourcegroup.rgname.0
  resource         = each.key
  depends_on = [
    module.adls
  ]
}

//*********************************
//  Storing vnet id in keyvault
//*********************************
module "keyvault_vnetid" {
  source      = "../../../../tf-core-module/keyvault/keyvault_secret"
  isService   = true
  serviceName = "vnetid"
  secretvalue = [[for n in module.network.vnetid : n[0]][1]["id"]]
  keyvault_id = module.keyvault.key_vault_id[0]
  depends_on = [
    module.keyvault,
    module.network
  ]
}
//*********************************
//  Storing instrumentation key
//*********************************
module "keyvault_app_insignts" {
  source      = "../../../../tf-core-module/keyvault/keyvault_secret"
  isService   = true
  serviceName = "appinsights"
  secretvalue = [module.applicationinsights.key.0]
  keyvault_id = module.keyvault.key_vault_id[0]
  depends_on = [
    module.keyvault,
    module.network
  ]
}