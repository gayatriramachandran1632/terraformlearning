productname     = "eva"
landingzonetype = "ibase"

# resources that are not available in GWC
resourceregion = "westeurope"

rsg_tags = {
  description         = "DLZ resources"
  environment         = "dev"
  businessowner       = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  technicalcontact    = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  project             = "eva-ibase"
  provisioner         = "terraform"
  businessgroup       = "iqs"
  ContactEmailAddress = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com;jan-michael.matzkovits@zeiss.com"
}

ars_tags = {
  costcenter         = "000000"
  internalorder      = "0000000000"
  region             = "europe"
  serviceprincipalid = "NA"
  repo               = "ZDP-AP_eVA_MS_MVP"
  support            = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
}

resource_groups = {
  0 = {
    workload     = "storage"
    resourcetype = "rg"
    rg_tags = {
      workload = "storage"
    }
  },
  1 = {
    workload     = "logging"
    resourcetype = "rg"
    rg_tags = {
      workload = "logging"
    }
  },
  2 = {
    workload     = "dataintegration"
    resourcetype = "rg"
    rg_tags = {
      workload = "dataintegration"
    }
  },
  3 = {
    workload     = "network"
    resourcetype = "rg"
    rg_tags = {
      workload = "network"
    }
  },
  4 = {
    workload     = "governance"
    resourcetype = "rg"
    rg_tags = {
      workload = "governance"
    }
  }
}


storage_accounts = {
  0 = {
    resourcetype             = "st"
    account_replication_type = "LRS"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_tier             = "Standard"
    rand_value               = "st01" # Please check wiki
    min_tls_version          = "TLS1_2"
  }
}

adls = {
  sa1 = {
    resourcetype             = "dls"
    account_tier             = "Standard"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_replication_type = "RAGRS"
    min_tls_version          = "TLS1_2"
    is_hns_enabled           = true
    rand_value               = "dlsdlz01" # Please check wiki
    dls = {
      dls = [
        "raw", "enr", "dev"
      ]
    }
  }
}

containers = {
  container1 = {
    name                  = "test"
    storage_account_name  = "sa1"
    container_access_type = "private"
  }
}

adlsfilesystems = {
  adlsfilesystem1 = {
    name  = "adlsfilesystem1"
    sa_id = "sa1"
  }
}

keyvault = {
  0 = {
    resourcetype                    = "kv"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    purge_protection_enabled        = true
    sku_name                        = "standard"
    rand_value                      = "kvtdlzdev01" # Please check wiki
  }
}

function_storage_accounts = {
  0 = {
    resourcetype             = "fas"
    account_replication_type = "LRS"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_tier             = "Standard"
    rand_value               = "funcsta01" # Please check wiki
  }
}
appserviceplan = {
  0 = {
    resourcetype = "plan"
    os_type      = "Linux"
    sku_name     = "S1"
    rand_value   = "plan01" # Please check wiki
  }
}
functionapp = {
  0 = {
    resourcetype    = "fa"
    serviceplan_key = 0
    project_area    = "transform"
    ostype          = "linux"
    rand_value      = "func01" # Please check wiki
  }
  1 = {
    resourcetype    = "fa"
    serviceplan_key = 0
    project_area    = "ingress"
    ostype          = "linux"
    rand_value      = "func01" # Please check wiki
  }
}

queue = {
  q1 = {
    name                 = "queue1"
    storage_account_name = "0"
    rand_value           = "queue01" # Please check wiki
  }
}

synapse_workspace = {
  0 = {
    resourcetype   = "synw"
    rand_value     = "synw01" # Please check wiki
    synsp_nodesize = "Small"
  }
}
private_endpoints = {
  0 = {
    name       = "pe"
    rand_value = "pe01" # Please check wiki
  }
}

virtual_networks = {
  0 = {
    resourcetype    = "vnet"
    subresourcetype = "snet"
    rand_value_vnet = "vnet01" # Please check wiki
    rand_value_snet = "snet01" # Please check wiki
  }
}

network_security_groups = {
  0 = {
    resourcetype = "nsg"
    rand_value   = "nsg01" # Please check wiki
  }
}

application_insights = {
  0 = {
    resourcetype         = "appi"
    application_type     = "web"
    retention_in_days    = 60
    daily_data_cap_in_gb = 10
    rand_value           = "appi01" # As mentioned at the start of the file.
  }
}

mongodbatlas = {
  0 = {
    rand_value_mongodbatlas                          = "mongodb01"
    projectresourcetype                              = "prj"
    clusterresourcetype                              = "clst"
    rolename                                         = "GROUP_OWNER"
    clustertype                                      = "REPLICASET"
    location                                         = "EUROPE_WEST"
    mongodbversion                                   = 4.2
    providername                                     = "AZURE"
    providerdisktype                                 = "P2"
    providerinstancesize                             = "M10"
    is_collect_database_specifics_statistics_enabled = true
    is_data_explorer_enabled                         = true
    is_performance_advisor_enabled                   = true
    is_realtime_performance_panel_enabled            = true
    is_schema_advisor_enabled                        = true
    electable_nodes                                  = 3
    priority                                         = 7
    read_only_nodes                                  = 0
    cloud_backup                                     = true
    auto_scaling_disk_gb_enabled                     = true
    providersetting                                  = "SERVERLESS"
    username                                         = "mongouser"
    serverresourcetype                               = "svr"
  }
}
statabledeployment = 0
staqueuedeployment = 0

eligiblerequestid = {
  0 = {
    resource_group_name  = "eva-dev-ibase-rg-europe-dataintegration"
    principal_id         = "c7172811-1148-488c-82f9-6f88b37d1ec4" #AAD_ZDP-ap-ag-eva-eu-np-dlz-ibase-writers
    role_definition_id   = "b24988ac-6180-42a0-ab88-20f7382dd24c"
    role_definition_name = "Contributor"
    rand_value           = "erequestid02"
  }
}

esbMID = "01daea68-8412-4d36-9008-48174190cdf3"
