#############################################################
## Common variables that are used in all resource's names
#############################################################

variable "productname" {
  type = string
}
variable "environmentshort" {
  type = string
}
variable "regionshort" {
  type = string
}
variable "environmentlong" {
  type = string
}
variable "regionlong" {
  type = string
}
variable "landingzonetype" {
  type = string
}
variable "networking_filepath" {
  type = string
}
variable "platform" {
  type = string
}
variable "hmac_key" {
  type = string
}
variable "esbMID" {
  type = string
}
variable "purviewMID" {
  type = string
}
variable "rsg_tags" {
  type = map(string)
}
variable "ars_tags" {
  type = map(any)
}
variable "statabledeployment" {
  type = string
}
variable "staqueuedeployment" {
  type = string
}
variable "peering_subscriptionid" {
  type = string
}
variable "peering_clientid" {
  type = string
}
variable "peering_clientsecret" {
  type = string
}
variable "alldnssecretsaslist" {
  type = string
}
variable "pviewaccid" {
  type    = string
  default = ""
}
variable "lawid" {
  type = string
}
variable "lztype" {
  type = string
}
variable "deploymentregion" {
  type = string
}

#############################################################
## Resource Group variables
#############################################################
variable "resource_groups" {
  description = "Resource groups"
  type = map(object({
    #name              = string
    workload     = string
    resourcetype = string
    rg_tags      = map(string)
  }))
}

#########################################
#Storage Account
#########################################

variable "storage_accounts" {
  description = "storageaccounts"
  type = map(object({
    account_tier             = string
    account_replication_type = string
    access_tier              = string
    account_kind             = string
    resourcetype             = string
    rand_value               = string
    min_tls_version          = string
  }))
}

######################################
# ADLS Account
###################################

variable "adls" {
  type = map(object({
    account_tier             = string
    account_kind             = string
    access_tier              = string
    account_replication_type = string
    min_tls_version          = string
    is_hns_enabled           = bool
    resourcetype             = string
    rand_value               = string
    dls = object({
      dls = list(string)
    })
  }))
}

variable "containers" {
  type = map(object({
    name                  = string
    storage_account_name  = string
    container_access_type = string
  }))
}

variable "adlsfilesystems" {
  type = map(object({
    name  = string
    sa_id = string
  }))
}

variable "peering_name_src_to_dest" {
  type = string
}
variable "peering_name_dest_to_src" {
  type = string
}
variable "dest_environment_long" {
  type = string
}


#############################################################
# Private Endpoint
#############################################################
variable "private_endpoints" {
  type = map(object({
    name       = string
    rand_value = string
  }))
}
//**********************************************************
//  Keyvault Variables
//**********************************************************
variable "keyvault" {
  type = map(object({
    enabled_for_deployment          = bool
    enabled_for_disk_encryption     = bool
    enabled_for_template_deployment = bool
    purge_protection_enabled        = bool
    sku_name                        = string
    resourcetype                    = string
    rand_value                      = string
  }))
}


#############################################################
# App Service Plan
#############################################################
variable "appserviceplan" {
  type = map(object({
    resourcetype = string
    rand_value   = string
    os_type      = string
    sku_name     = string
  }))
}

#############################################################
# Function Storage Account
#############################################################
variable "function_storage_accounts" {
  type = map(object({
    resourcetype             = string
    account_replication_type = string
    account_kind             = string
    access_tier              = string
    account_tier             = string
    rand_value               = string
  }))
}

#############################################################
# Function App
#############################################################
variable "functionapp" {
  type = map(object({
    resourcetype    = string
    serviceplan_key = string
    project_area    = string
    ostype          = string
    rand_value      = string
  }))
}

#############################################################
# Queue
#############################################################

variable "queue" {
  type = map(object({
    name                 = string
    storage_account_name = string
    rand_value           = string
  }))
}

#############################################################
# Synapse Analytics
#############################################################

variable "synapse_workspace" {
  type = map(object({
    resourcetype   = string
    rand_value     = string
    synsp_nodesize = string
  }))
}

################################################################
## Virtual Network variables
##############################################################

variable "virtual_networks" {
  type = map(object({
    resourcetype    = string
    subresourcetype = string
    rand_value_vnet = string
    rand_value_snet = string
  }))
}

############################################
# NSG Variables
###########################################
variable "network_security_groups" {
  description = "network security group"
  type = map(object({
    resourcetype = string
    rand_value   = string
  }))
}

#######################################
## Application Insights
#######################################

variable "application_insights" {
  type = map(object({
    application_type     = string
    retention_in_days    = number
    daily_data_cap_in_gb = number
    resourcetype         = string
    rand_value           = string
  }))
}

# #############################################################
# ## Variables that are used for Mongodbatlas resources creation
# #############################################################

variable "mongodbatlas" {
  type = map(object({
    projectresourcetype                              = string
    clusterresourcetype                              = string
    rand_value_mongodbatlas                          = string
    rolename                                         = string
    is_collect_database_specifics_statistics_enabled = bool
    is_data_explorer_enabled                         = bool
    is_performance_advisor_enabled                   = bool
    is_realtime_performance_panel_enabled            = bool
    is_schema_advisor_enabled                        = bool
    clustertype                                      = string
    location                                         = string
    electable_nodes                                  = number
    priority                                         = number
    read_only_nodes                                  = number
    cloud_backup                                     = bool
    auto_scaling_disk_gb_enabled                     = bool
    mongodbversion                                   = number
    providername                                     = string
    providerdisktype                                 = string
    providerinstancesize                             = string
    providersetting                                  = string
    username                                         = string
    serverresourcetype                               = string
  }))
}

#############################################################
## Common variables that are used for mongodb instances
#############################################################

variable "orgid" {
  type = string
}
variable "ownerid" {
  type = string
}
variable "apikeyid" {
  type = string
}
variable "publickey" {
  type = string
}
variable "privatekey" {
  type = string
}
variable "resourceregion" {
  type = string
}
variable "networking_sp_id" {
  type = string
}

#######################################
## PIM assignment
#######################################

variable "eligiblerequestid" {
  description = "Eligible request"
  type = map(object({
    resource_group_name  = string
    principal_id         = string
    role_definition_name = string
    role_definition_id   = string
    rand_value           = string
  }))
}