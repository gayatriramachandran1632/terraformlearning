//**********************************************************
//  Resource Group
//**********************************************************
module "resourcegroup" {
  source          = "../../../tf-core-module/resource-group"
  resource_groups = var.resource_groups
  productname     = var.productname
  environmentlong = var.environmentlong
  landingzonetype = var.landingzonetype
  regionlong      = var.regionlong
  rsg_tags        = var.rsg_tags
}

//*********************************
//  Network
//*********************************
module "network" {
  source                  = "../../../tf-core-module/network"
  virtual_networks        = var.virtual_networks
  productname             = var.productname
  environmentshort        = var.environmentshort
  regionshort             = var.regionshort
  resourcegpname          = module.resourcegroup.rgname.3
  resourcelocation        = module.resourcegroup.rglocation.3
  ars_tags                = var.ars_tags
  rgtags                  = module.resourcegroup.rgtags.2
  hmac_key                = var.hmac_key
  networking_filepath     = var.networking_filepath
  platform                = var.platform
  network_security_groups = var.network_security_groups
  depends_on = [
    module.resourcegroup
  ]
}

//*********************************
// Network Security Group
//*********************************

module "networksecuritygroup" {
  source                  = "../../../tf-core-module/network-security-group"
  network_security_groups = var.network_security_groups
  productname             = var.productname
  environmentshort        = var.environmentshort
  regionshort             = var.regionshort
  resourcegpname          = module.resourcegroup.rgname.3
  resourcelocation        = module.resourcegroup.rglocation.3
  vnet_id                 = [for n in module.network.vnetid : n[0]][1]["id"]
  subnet_name             = "service"
  ars_tags                = var.ars_tags
  rgtags                  = module.resourcegroup.rgtags.2
  hmac_key                = var.hmac_key
  depends_on = [
    module.resourcegroup
  ]
}

//*********************************
//  Global DNS
//*********************************
module "dns" {
  source            = "../../../tf-core-module/dns"
  private_dns_zones = var.private_dns_zones
  resourcegpname    = module.resourcegroup.rgname.5
  ars_tags          = var.ars_tags
  rgtags            = module.resourcegroup.rgtags.5
  environmentshort  = var.environmentshort
  hmac_key          = var.hmac_key
  productname       = var.productname
  regionshort       = var.regionshort
  vnet_id           = [for n in module.network.vnetid : n[0]][1]["id"]
  depends_on = [
    module.network,
    module.resourcegroup
  ]
}


//*********************************
//  Keyvault
//*********************************
module "keyvault" {
  source           = "../../../../tf-core-module/keyvault"
  keyvault         = var.keyvault
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.4
  resourcelocation = module.resourcegroup.rglocation.4
  rgtags           = module.resourcegroup.rgtags.4
  ars_tags         = var.ars_tags
  hmac_key         = var.hmac_key

  # USE Network folder to implement Private Endpoints
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = module.resourcegroup.rglocation.3
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  private_endpoints   = var.private_endpoints
  dns                 = [for n in split(",", var.alldnssecretsaslist) : n if can(regex("vaultcore", n))]
  depends_on = [
    module.network
  ]
}

//**********************************************************
//  Storage
//**********************************************************
module "storage" {
  source           = "../../../tf-core-module/storage"
  storage_accounts = var.storage_accounts
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.3
  resourcelocation = module.resourcegroup.rglocation.3
  ars_tags         = var.ars_tags
  rgtags           = module.resourcegroup.rgtags.3
  hmac_key         = var.hmac_key
  landingzonetype  = var.landingzonetype

  # USE Network folder to implement Private Endpoints
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = module.resourcegroup.rglocation.3
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  private_endpoints   = var.private_endpoints
  dns                 = [for n in module.dns["dns_zone_ids"] : n if can(regex("blob.core|file.core", n))]
  depends_on = [
    module.keyvault
  ]
  deployqueue = ""
  deploytable = ""
}

//**********************************************************
//  Data Lake - ADLS
//**********************************************************
module "adls" {
  source           = "../../../tf-core-module/adls"
  adls             = var.adls
  containers       = var.containers
  adlsfilesystems  = var.adlsfilesystems
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.0
  resourcelocation = module.resourcegroup.rglocation.0
  ars_tags         = var.ars_tags
  rgtags           = module.resourcegroup.rgtags.0
  hmac_key         = var.hmac_key
  landingzonetype  = var.landingzonetype

  # USE Network folder to implement Private Endpoints
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = module.resourcegroup.rglocation.3
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  private_endpoints   = var.private_endpoints
  dns                 = [for n in module.dns["dns_zone_ids"] : n if can(regex("blob.core|file.core", n))]
  depends_on = [
    module.keyvault
  ]
}

//**********************************************************
//  Datafactory
//**********************************************************
module "datafactory" {
  source           = "../../../tf-core-module/datafactory"
  datafactory      = var.datafactory
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.3
  resourcelocation = module.resourcegroup.rglocation.3
  ars_tags         = var.ars_tags
  rgtags           = module.resourcegroup.rgtags.3
  hmac_key         = var.hmac_key

}

//**********************************************************
//  Databricks
//**********************************************************
module "databricks" {
  source           = "../../../tf-core-module/databricks"
  databricks       = var.databricks
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.3
  resourcelocation = module.resourcegroup.rglocation.3
  ars_tags         = var.ars_tags
  rgtags           = module.resourcegroup.rgtags.3
  hmac_key         = var.hmac_key

}

//**********************************************************
//  Eventgrid
//**********************************************************
module "eventgrid" {
  source               = "../../../tf-core-module/eventgrid"
  queue                = var.queue
  eventgrid            = var.eventgrid
  productname          = var.productname
  environmentshort     = var.environmentshort
  regionshort          = var.regionshort
  resourcegpname       = module.resourcegroup.rgname.2
  resourcelocation     = module.resourcegroup.rglocation.2
  rgid                 = module.resourcegroup.rgid.2
  storage_account_name = module.storage.sa_name.0
  storage_account_id   = module.storage.sa_id.0
  ars_tags             = var.ars_tags
  rgtags               = module.resourcegroup.rgtags.2
  hmac_key             = var.hmac_key
}

//**********************************************************
//  Application Insights
//**********************************************************
module "applicationinsights" {
  source               = "../../../tf-core-module/application-insights"
  application_insights = var.application_insights
  productname          = var.productname
  environmentshort     = var.environmentshort
  regionshort          = var.regionshort
  resourcegpname       = module.resourcegroup.rgname.2
  resourcelocation     = module.resourcegroup.rglocation.2
  ars_tags             = var.ars_tags
  rgtags               = module.resourcegroup.rgtags.2
  hmac_key             = var.hmac_key
}

//**********************************************************
//  Synapse Workspace
//**********************************************************
module "synapse_workspace" {
  for_each             = var.adlsfilesystems
  source               = "../../../tf-core-module/synapse-analytics"
  synapse_workspace    = var.synapse_workspace
  productname          = var.productname
  environmentshort     = var.environmentshort
  regionshort          = var.regionshort
  resourcegpname       = module.resourcegroup.rgname.3
  resourcelocation     = module.resourcegroup.rglocation.3
  storage_data_lake_id = module.storage.sa_id.0
  adlsfilesystems      = each.value["name"]
  ars_tags             = var.ars_tags
  rgtags               = module.resourcegroup.rgtags.3
  hmac_key             = var.hmac_key
  landingzonetype      = var.landingzonetype

  keyvault_id = module.keyvault.key_vault_id[0]

  # USE Network folder to implement Private Endpoints
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = module.resourcegroup.rglocation.3
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  private_endpoints   = var.private_endpoints
  dns                 = [for n in module.dns["dns_zone_ids"] : n if can(regex("sql.azuresynapse|dev.azuresynapse", n))]
  depends_on = [
    module.keyvault,
    module.adls
  ]
}


//*********************************************
//  Synapse ManagedIdentity Permissions
//*********************************************
module "syn_permission" {
  source         = "../../../tf-core-module/adls/permission"
  managed_id     = [for item in module.synapse_workspace["adlsfilesystem1"] : item[0].identity[0].principal_id][0]
  resourcegpname = module.resourcegroup.rgname.0
  resource       = flatten(module.adls.storage_account_names)
  depends_on = [
    module.synapse_workspace,
    module.adls
  ]
}
//*********************************************
//  Synapse KeyVault Permissions
//*********************************************
module "kvt_permission_for_synapse" {
  source         = "../../../tf-core-module/keyvault/permission"
  managed_id     = [for item in module.synapse_workspace["adlsfilesystem1"] : item[0].identity[0].principal_id][0]
  keyvault_id    = module.keyvault.key_vault_id[0]
  resourcegpname = module.resourcegroup.rgname.1

  depends_on = [
    module.synapse_workspace,
    module.keyvault
  ]
}

//**********************************************************
//  Event Hub
//**********************************************************
module "eventhub" {
  source            = "../../../tf-core-module/eventhub"
  eventhub          = var.eventhub
  productname       = var.productname
  environmentshort  = var.environmentshort
  regionshort       = var.regionshort
  resourcegpname    = module.resourcegroup.rgname.1
  resourcelocation  = module.resourcegroup.rglocation.1
  ars_tags          = var.ars_tags
  rgtags            = module.resourcegroup.rgtags.1
  hmac_key          = var.hmac_key
  eventhubnamespace = var.eventhubnamespace
  # USE Network folder to implement Private Endpoints
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = module.resourcegroup.rglocation.3
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  private_endpoints   = var.private_endpoints
  dns                 = [for n in module.dns["dns_zone_ids"] : n if can(regex("servicebus", n))]
  depends_on = [
    module.keyvault,
    module.adls,
    module.kvt_permission_for_synapse
  ]
}

//**********************************************************
//  Function App Service Plan
//**********************************************************
module "appserviceplan" {
  source           = "../../../tf-core-module/appserviceplan"
  appserviceplan   = var.appserviceplan
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.0
  resourcelocation = module.resourcegroup.rglocation.0
  hmac_key         = var.hmac_key
  ars_tags         = var.ars_tags
  rgtags           = var.rsg_tags

}

//**********************************************************
//  Azure Functions Storage Account
//**********************************************************
module "functionsta" {
  source                    = "../../../tf-core-module/functionapp-storage"
  function_storage_accounts = var.function_storage_accounts
  productname               = var.productname
  environmentshort          = var.environmentshort
  regionshort               = var.regionshort
  resourcegpname            = module.resourcegroup.rgname.0
  resourcelocation          = module.resourcegroup.rglocation.0
  hmac_key                  = var.hmac_key
  ars_tags                  = var.ars_tags
  rgtags                    = var.rsg_tags
  landingzonetype           = var.landingzonetype
  loganalyticsworkspace_id  = module.loganalyticsworkspace.ana_id.0
  # USE Network folder to implement Private Endpoints
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = module.resourcegroup.rglocation.3
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  private_endpoints   = var.private_endpoints
  dns                 = [for n in module.dns["dns_zone_ids"] : n if can(regex("blob.core|file.core", n))]
  depends_on = [
    module.keyvault
  ]
}

//**********************************************************
//  Azure Functions
//**********************************************************
module "functionapp" {
  source             = "../../../tf-core-module/functionapp"
  functionapp        = var.functionapp
  productname        = var.productname
  environmentshort   = var.environmentshort
  regionshort        = var.regionshort
  resourcegpname     = module.resourcegroup.rgname.0
  resourcelocation   = module.resourcegroup.rglocation.0
  hmac_key           = var.hmac_key
  ars_tags           = var.ars_tags
  rgtags             = var.rsg_tags
  appserviceplanid   = module.appserviceplan.appserviceplanid.0
  storageaccesskey   = module.functionsta.functionappsakey.0
  storageaccountname = module.functionsta.functionappsaname.0
  # USE Network folder to implement Private Endpoints
  pvtendpointrsg      = module.resourcegroup.rgname.3
  pvtendpointlocation = module.resourcegroup.rglocation.3
  vnet_id             = [for n in module.network.vnetid : n[0]][1]["id"]
  private_endpoints   = var.private_endpoints
  dns                 = [for n in module.dns["dns_zone_ids"] : n if can(regex("blob.core|file.core", n))]

  depends_on = [
    module.keyvault
  ]
}

//**********************************************************
//  SQL server
//**********************************************************
module "sqlserver" {
  source           = "../../../tf-core-module/sqlserver"
  sqlserver        = var.sqlserver
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.1
  resourcelocation = module.resourcegroup.rglocation.1
  ars_tags         = var.ars_tags
  rgtags           = var.rsg_tags
  hmac_key         = var.hmac_key

  keyvault_id = module.keyvault.key_vault_id[0]
}

//**********************************************************
//  SQL database
//**********************************************************
module "sqldb" {
  source           = "../../../tf-core-module/sqldb"
  sqldb            = var.sqldb
  productname      = var.productname
  environmentshort = var.environmentshort
  regionshort      = var.regionshort
  resourcegpname   = module.resourcegroup.rgname.1
  resourcelocation = module.resourcegroup.rglocation.1
  sqlserverid      = module.sqlserver.sqlserverid.0
  landingzonetype  = var.landingzonetype
  ars_tags         = var.ars_tags
  rgtags           = var.rsg_tags
  hmac_key         = var.hmac_key
}
