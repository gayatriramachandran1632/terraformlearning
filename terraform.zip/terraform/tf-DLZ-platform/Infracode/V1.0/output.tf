output "storage_account_ids" {
  value = module.adls.storage_account_ids
}
output "storage_account_names" {
  value = module.adls.storage_account_names
}
output "whole_output" {
  value = module.adls.whole_output
}
output "rsg" {
  value = module.resourcegroup
}