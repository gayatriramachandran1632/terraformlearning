productname     = "eva"
landingzonetype = "ibase"
regionlong      = "europe"
regionshort     = "gwc"

rsg_tags = {
  description         = "DLZ resources"
  environment         = "dev"
  businessowner       = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  technicalcontact    = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
  project             = "eva-ibase"
  provisioner         = "terraform"
  businessgroup       = "iqs"
  ContactEmailAddress = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com;jan-michael.matzkovits@zeiss.com"
}

ars_tags = {
  costcenter         = "000000"
  internalorder      = "0000000000"
  region             = "europe"
  serviceprincipalid = "NA"
  repo               = "ZDP-AP_eVA_MS_MVP"
  support            = "markus.morgner@zeiss.com;reiner.rottmann@zeiss.com"
}

resource_groups = {
  0 = {
    location     = "Germany West Central"
    workload     = "storage"
    resourcetype = "rg"
    rg_tags = {
      workload = "storage"
    }
  },
  1 = {
    location     = "Germany West Central"
    workload     = "dataproduct"
    resourcetype = "rg"
    rg_tags = {
      workload = "dataproduct"
    }
  },
  2 = {
    location     = "Germany West Central"
    workload     = "logging"
    resourcetype = "rg"
    rg_tags = {
      workload = "logging"
    }
  },
  3 = {
    location     = "Germany West Central"
    workload     = "dataintegration"
    resourcetype = "rg"
    rg_tags = {
      workload = "dataintegration"
    }
  }
}

keyvault = {
  0 = {
    resourcetype                    = "kv"
    enabled_for_deployment          = true
    enabled_for_disk_encryption     = true
    enabled_for_template_deployment = true
    purge_protection_enabled        = true
    sku_name                        = "standard"
    rand_value                      = "kvt02" # As mentioned at the start of the file.
  }
}

storage_accounts = {
  0 = {
    resourcetype             = "st"
    account_replication_type = "LRS"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_tier             = "Standard"
    rand_value               = "st01" # As mentioned at the start of the file.
    min_tls_version          = "TLS1_2"
  }
}

adls = {
  sa1 = {
    resourcetype             = "dls"
    account_tier             = "Standard"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_replication_type = "RAGRS"
    min_tls_version          = "TLS1_2"
    is_hns_enabled           = true
    rand_value               = "dls01" # As mentioned at the start of the file.
    dls = {
      dls = [
        "raw", "enr", "dev"
      ]
    }
  }
}

containers = {
  container1 = {
    name                  = "test"
    storage_account_name  = "sa1"
    container_access_type = "private"
  }
}

adlsfilesystems = {
  adlsfilesystem1 = {
    name  = "adlsfilesystem1"
    sa_id = "sa1"
  }
}

datafactory = {
  0 = {
    resourcetype = "adf"
    rand_value   = "adf01" # As mentioned at the start of the file.
  }
}

databricks = {
  0 = {
    resourcetype = "dbw"
    rand_value   = "dbw01" # As mentioned at the start of the file.
  }
}

queue = {
  q1 = {
    name                 = "queue1"
    storage_account_name = "0"
    rand_value           = "queue01" # As mentioned at the start of the file.
  }
}

eventgrid = {
  0 = {
    resourcetype = "egrid"
    queue_name   = "q1"
    rand_value   = "egrid01" # As mentioned at the start of the file.
  }
}

application_insights = {
  1 = {
    resourcetype         = "appi"
    application_type     = "web"
    retention_in_days    = 60
    daily_data_cap_in_gb = 10
    rand_value           = "appi01" # As mentioned at the start of the file.
  }
}
synapse_workspace = {
  0 = {
    resourcetype   = "synw"
    rand_value     = "synw01" # As mentioned at the start of the file.
    synsp_nodesize = "Small"
  }
}
function_storage_accounts = {
  0 = {
    resourcetype             = "fas"
    account_replication_type = "LRS"
    account_kind             = "StorageV2"
    access_tier              = "Hot"
    account_tier             = "Standard"
    rand_value               = "funcsta01" # As mentioned at the start of the file.
  }
}
appserviceplan = {
  0 = {
    resourcetype = "plan"
    os_type      = "Linux"
    sku_name     = "S1"
    rand_value   = "plan01" # As mentioned at the start of the file.
  }
}
functionapp = {
  0 = {
    resourcetype    = "fa"
    serviceplan_key = 0
    project_area    = "processing"
    ostype          = "linux"
    rand_value      = "func01" # Please check wiki
  }
  1 = {
    resourcetype    = "fa"
    serviceplan_key = 0
    project_area    = "egressapi"
    ostype          = "linux"
    rand_value      = "func01" # Please check wiki
  }
}

eventhub = {
  0 = {
    resourcetype = "evh"
    rand_value   = "evh01" # As mentioned at the start of the file.
  }
}

eventhubnamespace = {
  0 = {
    resourcetype = "evhns"
    rand_value   = "evhns01" # As mentioned at the start of the file.
  }
}

sqlserver = {
  0 = {
    resourcetype                  = "sql"
    public_network_access_enabled = false
    rand_value                    = "sql01" # As mentioned at the start of the file.
  }
}

sqldb = {
  0 = {
    resourcetype         = "sqldb"
    max_size_gb          = 5
    sku_name             = "S0"
    storage_account_type = "Local"
    rand_value           = "sqldb01" # As mentioned at the start of the file.
  }
}
private_dns_zones = {
  zone1 = {
    dns_zone_name        = "privatelink.vaultcore.azure.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsibase01" # Please check wiki
  }
  zone2 = {
    dns_zone_name        = "privatelink.file.core.windows.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsblobfile01" # Please check wiki
  }
  zone3 = {
    dns_zone_name        = "privatelink.blob.core.windows.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsblob01" # Please check wiki
  }
  zone4 = {
    dns_zone_name        = "privatelink.sql.azuresynapse.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnssynsql01" # Please check wiki
  }
  zone5 = {
    dns_zone_name        = "privatelink.dev.azuresynapse.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnssyndev01" # Please check wiki
  }
  zone6 = {
    dns_zone_name        = "privatelink.servicebus.windows.net"
    zone_exists          = false
    registration_enabled = false
    rand_value           = "dnsservbus01" # Please check wiki
  }
}