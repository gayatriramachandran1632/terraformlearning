This repo is linked to the "Automation for Azure Policy Set and Assignment creation"  https://chrysalis.ms/Projects/1632
Detailed documention to use this automation is placed in the below wiki

https://dev.azure.com/chrysalis-innersource/Infrastructure%20IP%20Library/_wiki/wikis/Infrastructure-IP-Library.wiki/2044/Azure-Policy-Automation