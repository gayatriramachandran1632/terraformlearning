[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseDeclaredVarsMoreThanAssignments', 'scriptPath')]
param()
Describe 'Test Bicep Parameter File Tests' {
    BeforeAll {
        # Define the path to the script dynamically
        $projectRoot = Split-Path -Parent $PSScriptRoot
        $scriptPath = Join-Path -Path $projectRoot -ChildPath '\utilities\sharedScripts\Test-BicepParamFile.ps1'
    }
# For innovation.main.bicepparam
    It 'Test-BicepParamFile should not throw an error' {
        $parameterPath = Join-Path -Path $projectRoot -ChildPath '\orchestration\storage\innovation.main.bicepparam'
         Write-Output "Testing: $parameterPath"
        {
            & $scriptPath -FilePath $parameterPath
            if ($LASTEXITCODE -ne 0) {
                throw "Test-BicepParamFile failed with exit code $LASTEXITCODE"
            }
        } | Should -Not -Throw
    }

    It 'Test-BicepParamFile should not throw an error' {
        $parameterPath = Join-Path -Path $projectRoot -ChildPath '\orchestration\eventhub-ns\innovation.main.bicepparam'
        Write-Output "Testing: $parameterPath"
        {
            & $scriptPath -FilePath $parameterPath
            if ($LASTEXITCODE -ne 0) {
                throw "Test-BicepParamFile failed with exit code $LASTEXITCODE"
            }
        } | Should -Not -Throw
    }

    It 'Test-BicepParamFile should not throw an error' {
        $parameterPath = Join-Path -Path $projectRoot -ChildPath '\orchestration\networkconfiguration\innovation.main.bicepparam'
         Write-Output "Testing: $parameterPath"
        {
            & $scriptPath -FilePath $parameterPath
            if ($LASTEXITCODE -ne 0) {
                throw "Test-BicepParamFile failed with exit code $LASTEXITCODE"
            }
        } | Should -Not -Throw
    }

# For dev.main.bicepparam; this only has the network configuration test as of 30.06.2025.

    It 'Test-BicepParamFile should not throw an error' {
        $parameterPath = Join-Path -Path $projectRoot -ChildPath '\orchestration\networkconfiguration\dev.main.bicepparam'
         Write-Output "Testing: $parameterPath"
        {
            & $scriptPath -FilePath $parameterPath
            if ($LASTEXITCODE -ne 0) {
                throw "Test-BicepParamFile failed with exit code $LASTEXITCODE"
            }
        } | Should -Not -Throw
    }
#########
    It 'Test-BicepParamFile should throw an error' {
        $parameterPath = Join-Path -Path $projectRoot -ChildPath 'testData\test-bicep-param-file-root\proximusuat.main.bicepparam'
        {
            & $scriptPath -FilePath $parameterPath
            if ($LASTEXITCODE -ne 0) {
                throw "Test-BicepParamFile failed with exit code $LASTEXITCODE"
            }
        } | Should -Throw

    }
}