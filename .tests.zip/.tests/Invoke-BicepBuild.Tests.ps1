﻿Describe 'Bicep Build Tests' {

    It 'Bicep files should build successfully' {
        # get the list of changed files
        $gitDiffFiles = git diff --name-only --diff-filter=d --merge-base 'origin/users/garamac/feature-pesterforpwsh2'
        { foreach ($bicepFile in ($gitDiffFiles | Where-Object { $_ -like '*.bicep' -and $_ -notlike '*.tests*' })) {
                bicep build $bicepFile
                if ($LASTEXITCODE -ne 0) {
                    throw "Bicep build failed for $($bicepFile)"
                }
            }
        } | Should -Not -Throw
    }
}