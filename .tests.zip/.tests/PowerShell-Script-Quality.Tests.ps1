#Requires -Modules Pester

<#
.SYNOPSIS
PowerShell script validation tests for IaC project utilities

.DESCRIPTION
This test suite validates PowerShell scripts and utilities without relying on 
external Azure CLI commands. It focuses on script structure, error handling,
and best practices.
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseDeclaredVarsMoreThanAssignments', 'projectRoot')]
param()

Describe 'PowerShell Script Quality Tests' {
    BeforeAll {
        $projectRoot = Split-Path -Parent $PSScriptRoot
        
        # Function to test PowerShell syntax
        function Test-PowerShellSyntax {
            param([string]$FilePath)
            
            try {
                $null = [System.Management.Automation.PSParser]::Tokenize((Get-Content -Path $FilePath -Raw), [ref]$null)
                return $true
            }
            catch {
                return $false
            }
        }
    }

    Context 'Utility Script Validation' {
        BeforeAll {
            $testBicepParamScript = Join-Path -Path $projectRoot -ChildPath 'utilities\sharedScripts\Test-BicepParamFile.ps1'
            $setPesterOutputScript = Join-Path -Path $projectRoot -ChildPath 'utilities\sharedScripts\Set-PesterGitHubOutput.ps1'
        }

        It 'Test-BicepParamFile.ps1 should exist and be readable' {
            $testBicepParamScript | Should -Exist
            { Get-Content -Path $testBicepParamScript -ErrorAction Stop } | Should -Not -Throw
        }

        It 'Test-BicepParamFile.ps1 should have valid PowerShell syntax' {
            Test-PowerShellSyntax -FilePath $testBicepParamScript | Should -Be $true
        }

        It 'Test-BicepParamFile.ps1 should have proper parameter validation' {
            $content = Get-Content -Path $testBicepParamScript -Raw
            
            $content | Should -Match '\[CmdletBinding\(\)\]'
            $content | Should -Match '\[Parameter\(Mandatory = \$true\)\]'
            $content | Should -Match '\[string\]\$FilePath'
        }

        It 'Test-BicepParamFile.ps1 should have proper help documentation' {
            $content = Get-Content -Path $testBicepParamScript -Raw
            
            $content | Should -Match '\.SYNOPSIS'
            $content | Should -Match '\.DESCRIPTION'
            $content | Should -Match '\.PARAMETER'
            $content | Should -Match '\.OUTPUTS'
        }

        It 'Test-BicepParamFile.ps1 should handle file existence properly' {
            $content = Get-Content -Path $testBicepParamScript -Raw
            
            $content | Should -Match 'Test-Path -Path \$FilePath'
            $content | Should -Match 'exit 0'
            $content | Should -Match 'exit 1'
        }

        It 'Test-BicepParamFile.ps1 should provide informative messages' {
            $content = Get-Content -Path $testBicepParamScript -Raw
            
            $content | Should -Match 'Write-Information.*exists.*Proceeding'
            $content | Should -Match 'Write-Information.*does not exist.*Stopping'
        }

        It 'Set-PesterGitHubOutput.ps1 should exist if present' {
            if (Test-Path $setPesterOutputScript) {
                { Get-Content -Path $setPesterOutputScript -ErrorAction Stop } | Should -Not -Throw
                Test-PowerShellSyntax -FilePath $setPesterOutputScript | Should -Be $true
            }
        }
    }

    Context 'Test Script Structure Validation' {
        BeforeAll {
            $testFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath '.tests') -Filter '*.Tests.ps1'
        }

        It 'All test files should have valid PowerShell syntax' {
            foreach ($testFile in $testFiles) {
                Test-PowerShellSyntax -FilePath $testFile.FullName | Should -Be $true
            }
        }

        It 'All test files should follow Pester v5 structure' {
            foreach ($testFile in $testFiles) {
                $content = Get-Content -Path $testFile.FullName -Raw
                
                # Basic Pester structure
                $content | Should -Match 'Describe\s+[''"][^''"]+[''"]'
            }
        }

        It 'Test files should have proper BeforeAll blocks where needed' {
            $testFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath '.tests') -Filter '*.Tests.ps1' | 
                         Where-Object { $_.Name -ne 'Advanced-Testing-Examples.ps1' }
            
            foreach ($testFile in $testFiles) {
                $content = Get-Content -Path $testFile.FullName -Raw
                
                if ($content -match 'projectRoot|scriptPath') {
                    $content | Should -Match 'BeforeAll\s*{'
                }
            }
        }

        It 'Test files should use appropriate assertion methods' {
            foreach ($testFile in $testFiles) {
                $content = Get-Content -Path $testFile.FullName -Raw
                
                # Check for common Pester assertions
                if ($content -match 'Should\s+-') {
                    $content | Should -Match 'Should\s+-(Not\s+)?((Be)|(Exist)|(Throw)|(Match)|(Contain))'
                }
            }
        }
    }

    Context 'Script Security and Best Practices' {
        BeforeAll {
            $allScripts = @()
            $allScripts += Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'utilities') -Filter '*.ps1' -Recurse
            $allScripts += Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath '.tests') -Filter '*.ps1' -Recurse
            if (Test-Path (Join-Path -Path $projectRoot -ChildPath '*.ps1')) {
                $allScripts += Get-ChildItem -Path $projectRoot -Filter '*.ps1'
            }
        }

        It 'Scripts should not contain hardcoded credentials' {
            foreach ($script in $allScripts) {
                $content = Get-Content -Path $script.FullName -Raw
                
                # Check for common credential patterns
                $content | Should -Not -Match 'password\s*=\s*[''"][^''"]*[''"]'
                $content | Should -Not -Match 'secret\s*=\s*[''"][^''"]*[''"]'
                $content | Should -Not -Match 'key\s*=\s*[''"][A-Za-z0-9+/]{20,}[''"]'
            }
        }

        It 'Scripts should use proper error handling' {
            $utilityScripts = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'utilities') -Filter '*.ps1' -Recurse
            
            foreach ($script in $utilityScripts) {
                $content = Get-Content -Path $script.FullName -Raw
                
                # Should have some form of error handling
                $hasErrorHandling = ($content -match 'try\s*{') -or 
                                   ($content -match 'ErrorAction') -or 
                                   ($content -match '\$\?') -or
                                   ($content -match 'exit\s+\d+')
                
                $hasErrorHandling | Should -Be $true
            }
        }

        It 'Scripts should have proper parameter validation' {
            $utilityScripts = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'utilities') -Filter '*.ps1' -Recurse
            
            foreach ($script in $utilityScripts) {
                $content = Get-Content -Path $script.FullName -Raw
                
                if ($content -match 'param\s*\(') {
                    # Should have CmdletBinding if using parameters
                    $content | Should -Match '\[CmdletBinding\(\)\]'
                }
            }
        }

        It 'Test scripts should suppress known PSScriptAnalyzer warnings appropriately' {
            $testFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath '.tests') -Filter '*.Tests.ps1'
            
            foreach ($testFile in $testFiles) {
                $content = Get-Content -Path $testFile.FullName -Raw
                
                # Check for suppressions of common test-related warnings
                if ($content -match '\$projectRoot|\$scriptPath') {
                    $content | Should -Match '\[Diagnostics\.CodeAnalysis\.SuppressMessageAttribute\(.*PSUseDeclaredVarsMoreThanAssignments'
                }
            }
        }
    }

    Context 'Function and Module Structure' {
        It 'Utility scripts should have consistent function naming' {
            $utilityScripts = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'utilities') -Filter '*.ps1' -Recurse
            
            foreach ($script in $utilityScripts) {
                $content = Get-Content -Path $script.FullName -Raw
                
                # If functions are defined, they should follow PowerShell naming conventions
                $functionMatches = [regex]::Matches($content, 'function\s+([A-Za-z-]+)')
                foreach ($match in $functionMatches) {
                    $functionName = $match.Groups[1].Value
                    $functionName | Should -Match '^[A-Z][a-z]*(-[A-Z][a-z]*)*$'
                }
            }
        }

        It 'Scripts should have consistent indentation' {
            $utilityScripts = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'utilities') -Filter '*.ps1' -Recurse
            
            foreach ($script in $utilityScripts) {
                $lines = Get-Content -Path $script.FullName
                
                # Check for consistent indentation (spaces, not tabs)
                $tabLines = $lines | Where-Object { $_ -match '^[\t]+' }
                $tabLines.Count | Should -Be 0
            }
        }
    }

    Context 'Environment Variable Usage' {
        It 'Scripts should handle missing environment variables gracefully' {
            $allScripts = @()
            $allScripts += Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'utilities') -Filter '*.ps1' -Recurse
            if (Test-Path (Join-Path -Path $projectRoot -ChildPath '*.ps1')) {
                $allScripts += Get-ChildItem -Path $projectRoot -Filter '*.ps1'
            }
            
            foreach ($script in $allScripts) {
                $content = Get-Content -Path $script.FullName -Raw
                
                # If environment variables are used, there should be validation
                $envVarMatches = [regex]::Matches($content, '\$env:([A-Za-z_][A-Za-z0-9_]*)')
                if ($envVarMatches.Count -gt 0) {
                    # Should have some form of validation or error handling
                    $hasValidation = ($content -match 'if.*\$env:') -or 
                                    ($content -match 'Test-Path.*\$env:') -or 
                                    ($content -match 'String\]::IsNullOrEmpty') -or
                                    ($content -match 'exit\s+\d+')
                    
                    # This is a recommendation, not a hard requirement for all scripts
                    Write-Information "Script $($script.Name) uses environment variables. Consider adding validation." -InformationAction Continue
                }
            }
        }
    }

    Context 'Output and Logging Standards' {
        It 'Utility scripts should provide meaningful output' {
            $utilityScripts = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'utilities') -Filter '*.ps1' -Recurse
            
            foreach ($script in $utilityScripts) {
                $content = Get-Content -Path $script.FullName -Raw
                
                # Should have some form of output
                $hasOutput = ($content -match 'Write-Information') -or 
                            ($content -match 'Write-Output') -or 
                            ($content -match 'Write-Host') -or 
                            ($content -match 'Write-Verbose')
                
                $hasOutput | Should -Be $true
            }
        }

        It 'Scripts should use appropriate output streams' {
            $utilityScripts = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'utilities') -Filter '*.ps1' -Recurse
            
            foreach ($script in $utilityScripts) {
                $content = Get-Content -Path $script.FullName -Raw
                
                # Prefer Write-Information or Write-Output over Write-Host
                if ($content -match 'Write-Host') {
                    Write-Information "Script $($script.Name) uses Write-Host. Consider Write-Information for better pipeline compatibility." -InformationAction Continue
                }
            }
        }
    }
}
