#Requires -Modules Pester

<#
.SYNOPSIS
Master test runner for Infrastructure as Code validation

.DESCRIPTION
This script runs all Pester test suites for the IaC project, providing
comprehensive validation without Azure CLI dependencies.
#>

[CmdletBinding()]
param(
    [Parameter()]
    [string]$TestPath = $PSScriptRoot,
    
    [Parameter()]
    [string]$OutputFormat = 'NUnitXml',
    
    [Parameter()]
    [string]$OutputFile = 'TestResults.xml',
    
    [Parameter()]
    [switch]$PassThru
)

# Import Pester module
Import-Module Pester -Force

Write-Host "Starting Infrastructure as Code Test Suite" -ForegroundColor Green
Write-Host "Test Path: $TestPath" -ForegroundColor Cyan
Write-Host "Output Format: $OutputFormat" -ForegroundColor Cyan
Write-Host "Output File: $OutputFile" -ForegroundColor Cyan

# Define test suites
$testSuites = @(
    @{
        Name = "Infrastructure Validation"
        Path = Join-Path -Path $TestPath -ChildPath "Infrastructure-Validation.Tests.ps1"
        Description = "Validates file structure, content, and basic infrastructure requirements"
    },
    @{
        Name = "Bicep Template Quality"
        Path = Join-Path -Path $TestPath -ChildPath "Bicep-Template-Quality.Tests.ps1"
        Description = "Validates Bicep template syntax, structure, and best practices"
    },
    @{
        Name = "PowerShell Script Quality"
        Path = Join-Path -Path $TestPath -ChildPath "PowerShell-Script-Quality.Tests.ps1"
        Description = "Validates PowerShell scripts for quality and best practices"
    },
    @{
        Name = "Project Standards Validation"
        Path = Join-Path -Path $TestPath -ChildPath "Project-Standards-Validation.Tests.ps1"
        Description = "Validates project structure and organizational standards compliance"
    },
    @{
        Name = "Bicep Parameter File Tests"
        Path = Join-Path -Path $TestPath -ChildPath "Test-BicepParamFile.Tests.ps1"
        Description = "Validates Bicep parameter file existence and structure"
    }
)

# Configuration for Pester
$pesterConfig = New-PesterConfiguration
$pesterConfig.Run.Path = @()
$pesterConfig.TestResult.Enabled = $true
$pesterConfig.TestResult.OutputFormat = $OutputFormat
$pesterConfig.TestResult.OutputPath = $OutputFile
$pesterConfig.Output.Verbosity = 'Detailed'
$pesterConfig.Run.PassThru = $PassThru

# Validate and add existing test files
$validTestSuites = @()
foreach ($suite in $testSuites) {
    if (Test-Path -Path $suite.Path) {
        Write-Host "✓ Found test suite: $($suite.Name)" -ForegroundColor Green
        $validTestSuites += $suite
        $pesterConfig.Run.Path += $suite.Path
    } else {
        Write-Warning "✗ Test suite not found: $($suite.Name) at $($suite.Path)"
    }
}

if ($validTestSuites.Count -eq 0) {
    Write-Error "No test suites found. Please ensure test files exist in the correct location."
    exit 1
}

Write-Host "`nRunning $($validTestSuites.Count) test suite(s)..." -ForegroundColor Yellow

# Run the tests
try {
    $results = Invoke-Pester -Configuration $pesterConfig
    
    # Display summary
    Write-Host "`n" + ("=" * 80) -ForegroundColor Cyan
    Write-Host "TEST EXECUTION SUMMARY" -ForegroundColor Cyan
    Write-Host ("=" * 80) -ForegroundColor Cyan
    
    Write-Host "Total Tests: $($results.TotalCount)" -ForegroundColor White
    Write-Host "Passed: $($results.PassedCount)" -ForegroundColor Green
    Write-Host "Failed: $($results.FailedCount)" -ForegroundColor Red
    Write-Host "Skipped: $($results.SkippedCount)" -ForegroundColor Yellow
    Write-Host "Duration: $($results.Duration)" -ForegroundColor White
    
    if ($results.FailedCount -gt 0) {
        Write-Host "`nFAILED TESTS:" -ForegroundColor Red
        foreach ($test in $results.Failed) {
            Write-Host "  - $($test.FullName)" -ForegroundColor Red
            Write-Host "    $($test.ErrorRecord.Exception.Message)" -ForegroundColor DarkRed
        }
    }
    
    # Return appropriate exit code
    if ($results.FailedCount -gt 0) {
        Write-Host "`nTest execution completed with failures." -ForegroundColor Red
        exit 1
    } else {
        Write-Host "`nAll tests passed successfully!" -ForegroundColor Green
        exit 0
    }
}
catch {
    Write-Error "An error occurred during test execution: $_"
    exit 1
}
