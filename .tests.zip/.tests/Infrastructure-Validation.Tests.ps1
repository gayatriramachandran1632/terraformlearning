#Requires -Modules Pester, powershell-yaml

<#
.SYNOPSIS
Comprehensive Pester test suite for Infrastructure as Code validation

.DESCRIPTION
This test suite validates Bicep files, parameter files, and infrastructure
configurations without relying on Azure CLI commands. It focuses on:
- File existence and structure validation
- Parameter validation
- Bicep syntax and best practices
- Resource naming conventions
- Security configurations
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseDeclaredVarsMoreThanAssignments', 'projectRoot')]
param()

Describe 'Infrastructure Validation Tests' {
    BeforeAll {
        $projectRoot = Split-Path -Parent $PSScriptRoot
        $bicepFiles = @(
            'orchestration\storage\main.bicep',
            'orchestration\eventhub-ns\main.bicep',
            'orchestration\networkconfiguration\main.bicep',
            'orchestration\networkconfiguration\subnet.bicep'
        )
        $paramFiles = @(
            'orchestration\storage\innovation.main.bicepparam',
            'orchestration\eventhub-ns\innovation.main.bicepparam',
            'orchestration\networkconfiguration\innovation.main.bicepparam',
            'orchestration\networkconfiguration\dev.main.bicepparam'
        )
    }

    Context 'File Structure Validation' {
        It 'Should have all required Bicep files' {
            foreach ($file in $bicepFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $filePath | Should -Exist
            }
        }

        It 'Should have all required parameter files' {
            foreach ($file in $paramFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $filePath | Should -Exist
            }
        }

        It 'Should have utility scripts' {
            $utilityFiles = @(
                'utilities\sharedScripts\Test-BicepParamFile.ps1',
                'utilities\sharedScripts\Set-PesterGitHubOutput.ps1'
            )
            foreach ($file in $utilityFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $filePath | Should -Exist
            }
        }
    }

    Context 'Bicep File Content Validation' {
        It 'Storage main.bicep should have required metadata' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "metadata name = 'Deploy Storage Account resources'"
            $content | Should -Match "metadata project = 'ACTP'"
            $content | Should -Match "metadata workstream = 'Workstream A - E05'"
        }

        It 'Storage main.bicep should have correct target scope' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "targetScope = 'subscription'"
        }

        It 'EventHub main.bicep should have required metadata' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\eventhub-ns\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "metadata name = 'Deploy Event Hub namespace resources'"
            $content | Should -Match "metadata project = 'ACTP'"
            $content | Should -Match "metadata workstream = 'Workstream A - E05'"
        }

        It 'Network configuration main.bicep should have required metadata' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\networkconfiguration\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "metadata name = 'Deploy Subnet resources'"
            $content | Should -Match "metadata project = 'ACTP'"
            $content | Should -Match "metadata workstream = 'Workstream A - E05'"
        }

        It 'All Bicep files should have description for parameters' {
            foreach ($file in $bicepFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $content = Get-Content -Path $filePath -Raw
                
                # Check that parameters have descriptions
                $paramMatches = [regex]::Matches($content, '@description\([^)]+\)\s*param\s+(\w+)')
                $paramMatches.Count | Should -BeGreaterThan 0
            }
        }
    }

    Context 'Parameter File Validation' {
        It 'Innovation storage parameters should have valid structure' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\innovation.main.bicepparam'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "using './main.bicep'"
            $content | Should -Match "param location = 'westeurope'"
            $content | Should -Match "param nameObject = {"
            $content | Should -Match "param storagesecuritydetails = {"
        }

        It 'Name object should have required properties' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\innovation.main.bicepparam'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "client:"
            $content | Should -Match "workloadIdentifier:"
            $content | Should -Match "environment:"
            $content | Should -Match "region:"
            $content | Should -Match "purpose:"
        }

        It 'Storage security details should have required properties' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\innovation.main.bicepparam'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "publicstorageaccess:"
            $content | Should -Match "softdeleteforcontainers:"
            $content | Should -Match "softdeleteforblobs:"
            $content | Should -Match "restorepolicydays:"
        }

        It 'All parameter files should reference correct main.bicep' {
            foreach ($file in $paramFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $content = Get-Content -Path $filePath -Raw
                
                $content | Should -Match "using '\./main\.bicep'"
            }
        }
    }

    Context 'Resource Naming Convention Validation' {
        It 'Storage account name should follow naming convention' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            # Check for proper naming pattern: client+workload+purpose+env+region+st+01
            $content | Should -Match 'concat\(\'\$\{nameObject\.client\}\$\{nameObject\.workloadIdentifier\}\$\{nameObject\.shortpurpose\}\$\{nameObject\.environment\}\$\{nameObject\.region\}st01\'\)'
        }

        It 'Resource group name should follow naming convention' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            # Check for proper RG naming pattern
            $content | Should -Match 'concat\(\'\$\{nameObject\.client\}-\$\{nameObject\.workloadIdentifier\}-\$\{nameObject\.purpose\}-\$\{nameObject\.environment\}-\$\{nameObject\.region\}-rg-1\'\)'
        }

        It 'EventHub namespace name should follow naming convention' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\eventhub-ns\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            # Check for EventHub naming pattern
            $content | Should -Match 'concat\(\'\$\{nameObject\.client\}-\$\{nameObject\.workloadIdentifier\}-\$\{nameObject\.environment\}-\$\{nameObject\.region\}-ehns-1\'\)'
        }
    }

    Context 'Security Configuration Validation' {
        It 'Storage account should have secure defaults' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            # Check for security configurations
            $content | Should -Match "allowBlobPublicAccess: storagesecuritydetails\.publicstorageaccess"
            $content | Should -Match "networkAcls:"
            $content | Should -Match "defaultAction: 'Deny'"
            $content | Should -Match "isVersioningEnabled: true"
        }

        It 'Storage parameters should disable public access by default' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\innovation.main.bicepparam'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "publicstorageaccess: false"
        }

        It 'Storage should have backup and restore policies configured' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\innovation.main.bicepparam'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "softdeleteforcontainers: \d+"
            $content | Should -Match "softdeleteforblobs: \d+"
            $content | Should -Match "restorepolicydays: \d+"
            $content | Should -Match "restorePolicyEnabledbool: true"
        }
    }

    Context 'Module Reference Validation' {
        It 'Storage module should reference correct AVM module' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "module storageAccount 'br/public:avm/res/storage/storage-account:"
        }

        It 'Network security group should reference correct AVM module' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\networkconfiguration\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "module networkSecurityGroup 'br/public:avm/res/network/network-security-group:"
        }

        It 'Route table should reference correct AVM module' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\networkconfiguration\main.bicep'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "module routetable 'br/public:avm/res/network/route-table:"
        }
    }

    Context 'Environment-Specific Configuration' {
        It 'Dev environment should have appropriate configurations' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\networkconfiguration\dev.main.bicepparam'
            if (Test-Path $filePath) {
                $content = Get-Content -Path $filePath -Raw
                $content | Should -Match "environment: 'd'"
            }
        }

        It 'Innovation environment should have appropriate configurations' {
            $paramFiles = @(
                'orchestration\storage\innovation.main.bicepparam',
                'orchestration\eventhub-ns\innovation.main.bicepparam',
                'orchestration\networkconfiguration\innovation.main.bicepparam'
            )
            
            foreach ($file in $paramFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                if (Test-Path $filePath) {
                    $content = Get-Content -Path $filePath -Raw
                    $content | Should -Match "environment: 'd'"
                }
            }
        }
    }

    Context 'Utility Script Validation' {
        It 'Test-BicepParamFile.ps1 should have proper error handling' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'utilities\sharedScripts\Test-BicepParamFile.ps1'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "Test-Path"
            $content | Should -Match "exit 0"
            $content | Should -Match "exit 1"
        }

        It 'Test-BicepParamFile.ps1 should validate mandatory parameters' {
            $filePath = Join-Path -Path $projectRoot -ChildPath 'utilities\sharedScripts\Test-BicepParamFile.ps1'
            $content = Get-Content -Path $filePath -Raw
            
            $content | Should -Match "\[Parameter\(Mandatory = \$true\)\]"
            $content | Should -Match "\[string\]\$FilePath"
        }
    }

    Context 'File Permissions and Access' {
        It 'All Bicep files should be readable' {
            foreach ($file in $bicepFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                { Get-Content -Path $filePath -ErrorAction Stop } | Should -Not -Throw
            }
        }

        It 'All parameter files should be readable' {
            foreach ($file in $paramFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                { Get-Content -Path $filePath -ErrorAction Stop } | Should -Not -Throw
            }
        }

        It 'PowerShell scripts should be executable' {
            $scriptFiles = @(
                'utilities\sharedScripts\Test-BicepParamFile.ps1',
                'utilities\sharedScripts\Set-PesterGitHubOutput.ps1'
            )
            
            foreach ($file in $scriptFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $fileInfo = Get-Item -Path $filePath
                $fileInfo.Extension | Should -Be '.ps1'
            }
        }
    }
}
