#Requires -Modules Pester

<#
.SYNOPSIS
Project structure and naming convention validation tests

.DESCRIPTION
This test suite validates the overall project structure, naming conventions,
and compliance with organizational standards without Azure CLI dependencies.
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseDeclaredVarsMoreThanAssignments', 'projectRoot')]
param()

Describe 'Project Structure and Standards Validation' {
    BeforeAll {
        $projectRoot = Split-Path -Parent $PSScriptRoot
    }

    Context 'Project Structure Compliance' {
        It 'Should have required top-level directories' {
            $requiredDirs = @('orchestration', 'utilities', '.tests')
            
            foreach ($dir in $requiredDirs) {
                $dirPath = Join-Path -Path $projectRoot -ChildPath $dir
                $dirPath | Should -Exist
            }
        }

        It 'Should have orchestration subdirectories' {
            $orchestrationDirs = @('storage', 'eventhub-ns', 'networkconfiguration')
            
            foreach ($dir in $orchestrationDirs) {
                $dirPath = Join-Path -Path $projectRoot -ChildPath "orchestration\$dir"
                $dirPath | Should -Exist
            }
        }

        It 'Each orchestration module should have main.bicep' {
            $orchestrationDirs = @('storage', 'eventhub-ns', 'networkconfiguration')
            
            foreach ($dir in $orchestrationDirs) {
                $bicepPath = Join-Path -Path $projectRoot -ChildPath "orchestration\$dir\main.bicep"
                $bicepPath | Should -Exist
            }
        }

        It 'Each orchestration module should have at least one parameter file' {
            $orchestrationDirs = @('storage', 'eventhub-ns', 'networkconfiguration')
            
            foreach ($dir in $orchestrationDirs) {
                $paramFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath "orchestration\$dir") -Filter '*.bicepparam'
                $paramFiles.Count | Should -BeGreaterThan 0
            }
        }

        It 'Should have utilities with shared scripts' {
            $sharedScriptsPath = Join-Path -Path $projectRoot -ChildPath 'utilities\sharedScripts'
            $sharedScriptsPath | Should -Exist
            
            $scripts = Get-ChildItem -Path $sharedScriptsPath -Filter '*.ps1'
            $scripts.Count | Should -BeGreaterThan 0
        }
    }

    Context 'File Naming Convention Validation' {
        It 'Bicep files should follow naming convention' {
            $bicepFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter '*.bicep' -Recurse
            
            foreach ($file in $bicepFiles) {
                # Should be either main.bicep or descriptive name.bicep
                ($file.Name -eq 'main.bicep') -or ($file.Name -match '^[a-z]+\.bicep$') | Should -Be $true
            }
        }

        It 'Parameter files should follow naming convention' {
            $paramFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter '*.bicepparam' -Recurse
            
            foreach ($file in $paramFiles) {
                # Should follow pattern: environment.main.bicepparam
                $file.Name | Should -Match '^[a-z]+\.main\.bicepparam$'
            }
        }

        It 'Test files should follow naming convention' {
            $testFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath '.tests') -Filter '*.Tests.ps1'
            
            foreach ($file in $testFiles) {
                # Should end with .Tests.ps1
                $file.Name | Should -Match '\.Tests\.ps1$'
            }
        }

        It 'PowerShell scripts should follow naming convention' {
            $psFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'utilities') -Filter '*.ps1' -Recurse
            
            foreach ($file in $psFiles) {
                # Should use PascalCase or kebab-case
                ($file.BaseName -match '^[A-Z][a-zA-Z0-9]*(-[A-Z][a-zA-Z0-9]*)*$') -or 
                ($file.BaseName -match '^[a-z]+(-[a-z]+)*$') | Should -Be $true
            }
        }
    }

    Context 'Content Standards Validation' {
        It 'README.md should exist and contain project information' {
            $readmePath = Join-Path -Path $projectRoot -ChildPath 'README.md'
            $readmePath | Should -Exist
            
            $content = Get-Content -Path $readmePath -Raw
            $content | Should -Not -BeNullOrEmpty
            $content.Length | Should -BeGreaterThan 100
        }

        It 'Bicep files should have consistent header structure' {
            $bicepFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter 'main.bicep' -Recurse
            
            foreach ($file in $bicepFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                
                # Should have metadata section
                $content | Should -Match 'metadata name ='
                $content | Should -Match 'metadata description ='
                $content | Should -Match 'metadata project ='
                $content | Should -Match 'metadata workstream ='
            }
        }

        It 'All Bicep files should specify target scope' {
            $bicepFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter 'main.bicep' -Recurse
            
            foreach ($file in $bicepFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                $content | Should -Match 'targetScope\s*=\s*'
            }
        }

        It 'Parameter files should reference correct template' {
            $paramFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter '*.bicepparam' -Recurse
            
            foreach ($file in $paramFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                $content | Should -Match "using '\./main\.bicep'"
            }
        }
    }

    Context 'Security and Compliance Standards' {
        It 'No sensitive information should be present in parameter files' {
            $paramFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter '*.bicepparam' -Recurse
            
            foreach ($file in $paramFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                
                # Check for potential sensitive data patterns
                $content | Should -Not -Match 'password\s*[=:]\s*[''"][^''"]*[''"]'
                $content | Should -Not -Match 'secret\s*[=:]\s*[''"][^''"]*[''"]'
                $content | Should -Not -Match 'key\s*[=:]\s*[''"][A-Za-z0-9+/]{20,}[''"]'
            }
        }

        It 'Public access should be disabled by default in storage configurations' {
            $storageParams = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration\storage') -Filter '*.bicepparam'
            
            foreach ($file in $storageParams) {
                $content = Get-Content -Path $file.FullName -Raw
                
                # Should explicitly set public access to false
                $content | Should -Match 'publicstorageaccess:\s*false'
            }
        }

        It 'Storage configurations should have data protection policies' {
            $storageParams = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration\storage') -Filter '*.bicepparam'
            
            foreach ($file in $storageParams) {
                $content = Get-Content -Path $file.FullName -Raw
                
                # Should have soft delete and backup policies
                $content | Should -Match 'softdeleteforcontainers:'
                $content | Should -Match 'softdeleteforblobs:'
                $content | Should -Match 'restorepolicydays:'
            }
        }
    }

    Context 'Resource Naming Standards Validation' {
        It 'Resource naming should follow Azure conventions' {
            $bicepFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter 'main.bicep' -Recurse
            
            foreach ($file in $bicepFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                
                # Check for proper resource naming patterns
                if ($content -match 'Microsoft\.Resources/resourceGroups') {
                    $content | Should -Match 'rg-\d+'
                }
                
                if ($content -match 'Microsoft\.Storage/storageAccounts') {
                    $content | Should -Match 'st\d+'
                }
                
                if ($content -match 'Microsoft\.EventHub/namespaces') {
                    $content | Should -Match 'ehns-\d+'
                }
            }
        }

        It 'Names should include environment identifier' {
            $paramFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter '*.bicepparam' -Recurse
            
            foreach ($file in $paramFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                
                # Should have environment property in nameObject
                $content | Should -Match 'environment:\s*[''"][a-z][''"]'
            }
        }

        It 'Names should include region identifier' {
            $paramFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter '*.bicepparam' -Recurse
            
            foreach ($file in $paramFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                
                # Should have region property in nameObject
                $content | Should -Match 'region:\s*[''"][a-z]+[''"]'
            }
        }
    }

    Context 'Project Metadata Consistency' {
        It 'All Bicep templates should reference same project' {
            $bicepFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter 'main.bicep' -Recurse
            
            $projects = @()
            foreach ($file in $bicepFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                $projectMatch = [regex]::Match($content, "metadata project = '([^']+)'")
                if ($projectMatch.Success) {
                    $projects += $projectMatch.Groups[1].Value
                }
            }
            
            $uniqueProjects = $projects | Sort-Object -Unique
            $uniqueProjects.Count | Should -Be 1
            $uniqueProjects[0] | Should -Be 'ACTP'
        }

        It 'All Bicep templates should reference same workstream' {
            $bicepFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter 'main.bicep' -Recurse
            
            $workstreams = @()
            foreach ($file in $bicepFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                $workstreamMatch = [regex]::Match($content, "metadata workstream = '([^']+)'")
                if ($workstreamMatch.Success) {
                    $workstreams += $workstreamMatch.Groups[1].Value
                }
            }
            
            $uniqueWorkstreams = $workstreams | Sort-Object -Unique
            $uniqueWorkstreams.Count | Should -Be 1
            $uniqueWorkstreams[0] | Should -Be 'Workstream A - E05'
        }
    }

    Context 'Version and API Consistency' {
        It 'Resource API versions should be recent and consistent' {
            $bicepFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter '*.bicep' -Recurse
            
            foreach ($file in $bicepFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                
                # Extract API versions
                $apiVersions = [regex]::Matches($content, '@(\d{4}-\d{2}-\d{2})')
                
                foreach ($apiVersion in $apiVersions) {
                    $year = [int]$apiVersion.Groups[1].Value.Substring(0, 4)
                    # API versions should be from 2020 or later
                    $year | Should -BeGreaterOrEqual 2020
                }
            }
        }

        It 'AVM module versions should be specified' {
            $bicepFiles = Get-ChildItem -Path (Join-Path -Path $projectRoot -ChildPath 'orchestration') -Filter 'main.bicep' -Recurse
            
            foreach ($file in $bicepFiles) {
                $content = Get-Content -Path $file.FullName -Raw
                
                # Check for AVM module references
                $avmModules = [regex]::Matches($content, "br/public:avm/[^:]+:([0-9]+\.[0-9]+\.[0-9]+)")
                
                foreach ($moduleRef in $avmModules) {
                    $version = $moduleRef.Groups[1].Value
                    # Version should follow semantic versioning
                    $version | Should -Match '^\d+\.\d+\.\d+$'
                }
            }
        }
    }
}
