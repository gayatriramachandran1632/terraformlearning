#Requires -Modules Pester

<#
.SYNOPSIS
Bicep template validation tests without Azure CLI dependencies

.DESCRIPTION
This test suite validates Bicep templates for syntax, structure, and best practices
without requiring Azure CLI commands. It focuses on static analysis and validation.
#>

[Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSUseDeclaredVarsMoreThanAssignments', 'projectRoot')]
param()

Describe 'Bicep Template Quality Tests' {
    BeforeAll {
        $projectRoot = Split-Path -Parent $PSScriptRoot
        
        # Function to extract parameters from Bicep files
        function Get-BicepParameters {
            param([string]$FilePath)
            
            $content = Get-Content -Path $FilePath -Raw
            $paramPattern = '@description\([^)]+\)\s*param\s+(\w+)\s+(\w+)(?:\s*=\s*[^@\r\n]+)?'
            $paramMatches = [regex]::Matches($content, $paramPattern)
            
            $parameters = @{}
            foreach ($match in $paramMatches) {
                $parameters[$match.Groups[1].Value] = $match.Groups[2].Value
            }
            return $parameters
        }
        
        # Function to extract outputs from Bicep files
        function Get-BicepOutputs {
            param([string]$FilePath)
            
            $content = Get-Content -Path $FilePath -Raw
            $outputPattern = 'output\s+(\w+)\s+(\w+)\s*=\s*(.+)'
            $outputMatches = [regex]::Matches($content, $outputPattern)
            
            $outputs = @{}
            foreach ($match in $outputMatches) {
                $outputs[$match.Groups[1].Value] = $match.Groups[2].Value
            }
            return $outputs
        }
    }

    Context 'Storage Module Template Validation' {
        BeforeAll {
            $storageTemplatePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\main.bicep'
            $storageParamPath = Join-Path -Path $projectRoot -ChildPath 'orchestration\storage\innovation.main.bicepparam'
        }

        It 'Should have all required parameters defined' {
            $parameters = Get-BicepParameters -FilePath $storageTemplatePath
            
            $requiredParams = @('nameObject', 'location', 'storagesecuritydetails')
            foreach ($param in $requiredParams) {
                $parameters.Keys | Should -Contain $param
            }
        }

        It 'Should use proper parameter types' {
            $content = Get-Content -Path $storageTemplatePath -Raw
            
            $content | Should -Match 'param nameObject object'
            $content | Should -Match 'param location string'
            $content | Should -Match 'param storagesecuritydetails object'
        }

        It 'Should have resource group deployment' {
            $content = Get-Content -Path $storageTemplatePath -Raw
            
            $content | Should -Match "resource resourceGroup 'Microsoft\.Resources/resourceGroups@"
        }

        It 'Should use approved AVM module versions' {
            $content = Get-Content -Path $storageTemplatePath -Raw
            
            # Check for AVM module reference
            $content | Should -Match "br/public:avm/res/storage/storage-account:"
            
            # Ensure version is specified
            $content | Should -Match "br/public:avm/res/storage/storage-account:\d+\.\d+\.\d+"
        }

        It 'Should implement proper naming conventions in variables' {
            $content = Get-Content -Path $storageTemplatePath -Raw
            
            # Check for workload name variable
            $content | Should -Match "var workloadName = 'iac'"
        }

        It 'Should have security-focused storage configuration' {
            $content = Get-Content -Path $storageTemplatePath -Raw
            
            # Check for security parameters being used
            $content | Should -Match 'allowBlobPublicAccess: storagesecuritydetails\.publicstorageaccess'
            $content | Should -Match 'networkAcls:'
            $content | Should -Match "defaultAction: 'Deny'"
        }
    }

    Context 'EventHub Module Template Validation' {
        BeforeAll {
            $eventHubTemplatePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\eventhub-ns\main.bicep'
        }

        It 'Should have all required parameters defined' {
            $parameters = Get-BicepParameters -FilePath $eventHubTemplatePath
            
            $requiredParams = @('nameObject', 'eventHubDetails', 'networkDetails')
            foreach ($param in $requiredParams) {
                $parameters.Keys | Should -Contain $param
            }
        }

        It 'Should have proper variable declarations' {
            $content = Get-Content -Path $eventHubTemplatePath -Raw
            
            $content | Should -Match "var workloadName = 'iac'"
            $content | Should -Match 'var eventHubNamespaceName = toLower\('
        }

        It 'Should reference existing resources correctly' {
            $content = Get-Content -Path $eventHubTemplatePath -Raw
            
            $content | Should -Match "resource.*existing.*'Microsoft\.Resources/resourceGroups@"
            $content | Should -Match "resource.*existing.*'Microsoft\.Network/privateDnsZones@"
        }

        It 'Should use subscription target scope' {
            $content = Get-Content -Path $eventHubTemplatePath -Raw
            
            $content | Should -Match "targetScope = 'subscription'"
        }

        It 'Should have telemetry parameter with default' {
            $content = Get-Content -Path $eventHubTemplatePath -Raw
            
            $content | Should -Match 'param enableTelemetry bool = false'
        }
    }

    Context 'Network Configuration Template Validation' {
        BeforeAll {
            $networkTemplatePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\networkconfiguration\main.bicep'
            $subnetTemplatePath = Join-Path -Path $projectRoot -ChildPath 'orchestration\networkconfiguration\subnet.bicep'
        }

        It 'Should have all required parameters defined' {
            $parameters = Get-BicepParameters -FilePath $networkTemplatePath
            
            $requiredParams = @('nameObject', 'subnetdetails', 'virtualnetworkdetails')
            foreach ($param in $requiredParams) {
                $parameters.Keys | Should -Contain $param
            }
        }

        It 'Should deploy NSG module correctly' {
            $content = Get-Content -Path $networkTemplatePath -Raw
            
            $content | Should -Match "module networkSecurityGroup 'br/public:avm/res/network/network-security-group:"
            $content | Should -Match 'name:.*nsg'
        }

        It 'Should deploy route table module correctly' {
            $content = Get-Content -Path $networkTemplatePath -Raw
            
            $content | Should -Match "module routetable 'br/public:avm/res/network/route-table:"
            $content | Should -Match 'name:.*rt'
        }

        It 'Should reference local subnet module' {
            $content = Get-Content -Path $networkTemplatePath -Raw
            
            $content | Should -Match "module subnetModule 'subnet\.bicep'"
            $content | Should -Match 'subnetName:.*snet'
        }

        It 'Should reference existing resource group' {
            $content = Get-Content -Path $networkTemplatePath -Raw
            
            $content | Should -Match "resource resourceGroupExisting.*existing"
            $content | Should -Match 'virtualnetworkdetails\.resourceGroupName'
        }

        It 'Subnet template should exist and be valid' {
            $subnetTemplatePath | Should -Exist
            
            $content = Get-Content -Path $subnetTemplatePath -Raw
            $content | Should -Not -BeNullOrEmpty
        }
    }

    Context 'Template Consistency Validation' {
        It 'All templates should use consistent metadata structure' {
            $bicepFiles = @(
                'orchestration\storage\main.bicep',
                'orchestration\eventhub-ns\main.bicep',
                'orchestration\networkconfiguration\main.bicep'
            )
            
            foreach ($file in $bicepFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $content = Get-Content -Path $filePath -Raw
                
                $content | Should -Match "metadata name ="
                $content | Should -Match "metadata description ="
                $content | Should -Match "metadata project = 'ACTP'"
                $content | Should -Match "metadata workstream = 'Workstream A - E05'"
            }
        }

        It 'All templates should use consistent variable naming' {
            $bicepFiles = @(
                'orchestration\storage\main.bicep',
                'orchestration\eventhub-ns\main.bicep',
                'orchestration\networkconfiguration\main.bicep'
            )
            
            foreach ($file in $bicepFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $content = Get-Content -Path $filePath -Raw
                
                $content | Should -Match "var workloadName = 'iac'"
            }
        }

        It 'All templates should have timestamp parameter with default' {
            $bicepFiles = @(
                'orchestration\storage\main.bicep',
                'orchestration\eventhub-ns\main.bicep',
                'orchestration\networkconfiguration\main.bicep'
            )
            
            foreach ($file in $bicepFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $content = Get-Content -Path $filePath -Raw
                
                $content | Should -Match 'param timestamp string = utcNow\(\)'
            }
        }

        It 'All module deployments should use timestamp in naming' {
            $bicepFiles = @(
                'orchestration\storage\main.bicep',
                'orchestration\eventhub-ns\main.bicep',
                'orchestration\networkconfiguration\main.bicep'
            )
            
            foreach ($file in $bicepFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $content = Get-Content -Path $filePath -Raw
                
                $content | Should -Match "take\('\$\{timestamp\}"
            }
        }
    }

    Context 'Parameter Validation and Type Safety' {
        It 'Name object should have consistent structure across parameter files' {
            $paramFiles = @(
                'orchestration\storage\innovation.main.bicepparam',
                'orchestration\eventhub-ns\innovation.main.bicepparam',
                'orchestration\networkconfiguration\innovation.main.bicepparam'
            )
            
            $requiredNameProperties = @('client', 'workloadIdentifier', 'environment', 'region')
            
            foreach ($file in $paramFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                if (Test-Path $filePath) {
                    $content = Get-Content -Path $filePath -Raw
                    
                    foreach ($property in $requiredNameProperties) {
                        $content | Should -Match "${property}:"
                    }
                }
            }
        }

        It 'Location parameter should be valid Azure region' {
            $paramFiles = @(
                'orchestration\storage\innovation.main.bicepparam',
                'orchestration\eventhub-ns\innovation.main.bicepparam',
                'orchestration\networkconfiguration\innovation.main.bicepparam'
            )
            
            $validRegions = @('westeurope', 'eastus', 'westus2', 'northeurope', 'centralus')
            
            foreach ($file in $paramFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                if (Test-Path $filePath) {
                    $content = Get-Content -Path $filePath -Raw
                    
                    $regionMatch = [regex]::Match($content, "param location = '([^']+)'")
                    if ($regionMatch.Success) {
                        $region = $regionMatch.Groups[1].Value
                        $validRegions | Should -Contain $region
                    }
                }
            }
        }
    }

    Context 'Best Practices Validation' {
        It 'Should use proper API versions' {
            $bicepFiles = @(
                'orchestration\storage\main.bicep',
                'orchestration\eventhub-ns\main.bicep',
                'orchestration\networkconfiguration\main.bicep'
            )
            
            foreach ($file in $bicepFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $content = Get-Content -Path $filePath -Raw
                
                # Check for recent API versions (2024)
                $apiVersionMatches = [regex]::Matches($content, "@202[4-9]-\d{2}-\d{2}")
                $apiVersionMatches.Count | Should -BeGreaterThan 0
            }
        }

        It 'Should have descriptions for all parameters' {
            $bicepFiles = @(
                'orchestration\storage\main.bicep',
                'orchestration\eventhub-ns\main.bicep',
                'orchestration\networkconfiguration\main.bicep'
            )
            
            foreach ($file in $bicepFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $content = Get-Content -Path $filePath -Raw
                
                # Count parameters with descriptions
                $paramsWithDesc = [regex]::Matches($content, "@description\([^)]+\)\s*param\s+\w+\s+\w+")
                
                # Every param should have a description (allowing for some optional params)
                $paramsWithDesc.Count | Should -BeGreaterThan 0
            }
        }

        It 'Should use proper resource naming with take() function' {
            $bicepFiles = @(
                'orchestration\storage\main.bicep',
                'orchestration\eventhub-ns\main.bicep',
                'orchestration\networkconfiguration\main.bicep'
            )
            
            foreach ($file in $bicepFiles) {
                $filePath = Join-Path -Path $projectRoot -ChildPath $file
                $content = Get-Content -Path $filePath -Raw
                
                # Check for take() function usage to prevent name length issues
                $content | Should -Match "take\("
            }
        }
    }
}
