﻿Describe 'Bicep Lint Tests' {

    It 'Bicep files should lint successfully without BCP187 warning' {
        # get the list of changed files
        $gitDiffFiles = git diff --name-only --diff-filter=d --merge-base 'origin/users/garamac/feature-pesterforpwsh2'
        # run lint on each bicep file skipping .tests folder
        { foreach ($bicepFile in ($gitDiffFiles | Where-Object { $_ -like '*.bicep' -and $_ -notlike '*.tests*' })) {
                $output = bicep lint $bicepFile 2>&1
                if ($output -match 'error') {
                    throw "Bicep lint failed for $($bicepFile): $output"
                }
                if ($output -match 'BCP187') {
                    $msgLine = $output | Where-Object { $_ -match 'BCP187' }
                    throw "Bicep lint failed for $($bicepFile): $($msgLine.Exception.Message)"
                }
            }
        } | Should -Not -Throw
    }

    It 'Bicep parameter files should lint successfully without BCP187 warning' {
        # get the list of changed files
        $gitDiffFiles = git diff --name-only --diff-filter=d --merge-base 'origin/users/garamac/feature-pesterforpwsh2'
        Write-Output "Changed files: $gitDiffFiles"
        # run lint on each bicepparam file skipping .tests folder
        { foreach ($bicepFile in ($gitDiffFiles | Where-Object { $_ -like '*.bicepparam' -and $_ -notlike '*.tests*' })) {
                $output = bicep lint $bicepFile 2>&1
                if ($output -match 'error') {
                    throw "Bicep lint failed for $($bicepFile): $output"
                }
                if ($output -match 'BCP187') {
                    $msgLine = $output | Where-Object { $_ -match 'BCP187' }
                    throw "Bicep lint failed for $($bicepFile): $($msgLine.Exception.Message)"
                }
            }
        } | Should -Not -Throw
    }
}