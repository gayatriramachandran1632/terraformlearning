targetScope = 'subscription'

//---------------------- Metadata ----------------------

metadata name = 'Deploy Event Hub namespace resources'
metadata description = 'This Module deploys an Event Hub Namespace into the selected subscription.'
metadata project = 'ACTP'
metadata workstream = 'Workstream A - E05'

// ---------------------- Parameters ----------------------

@description('Required. Name Object to create resource name')
param nameObject object

@description('Optional. Location for all Resources.')
param location string = deployment().location

@description('Required. details of EventHub Namespace')
param eventHubDetails object

@description('Optional. timestamp')
param timestamp string = utcNow()

@description('Optional. Enable/Disable usage telemetry for module.')
param enableTelemetry bool = false

@description('Required. Details of network configuration')
param networkDetails object

// ---------------------- Variables ----------------------

var workloadName = 'iac'

var eventHubNamespaceName = toLower(concat('${nameObject.client}-${nameObject.workloadIdentifier}-${nameObject.environment}-${nameObject.region}-ehns-1'))

// Resource Group
resource resourceGroup 'Microsoft.Resources/resourceGroups@2024-07-01' = {
  name: (concat('${nameObject.client}-${nameObject.workloadIdentifier}-${nameObject.purpose}-${nameObject.environment}-${nameObject.region}-rg-1'))
  location: location
}

@description('Reference the existing Private DNS Zone Resource Group')
resource existingPrivateDNSZoneRG 'Microsoft.Resources/resourceGroups@2024-07-01' existing = {
  name: networkDetails.existingPrivateDNSZoneRG
}

@description('Reference the existing Private DNS Zone')
resource existingPrivateDNSZone 'Microsoft.Network/privateDnsZones@2024-06-01' existing = {
  name: networkDetails.existingPrivateDNSZone
  scope: existingPrivateDNSZoneRG
}

@description('Reference the existing Private DNS Zone')
resource existingnetworkRG 'Microsoft.Resources/resourceGroups@2024-07-01' existing = {
  name: networkDetails.existingnetworkRG
}

@description('Reference the existing Virtual Network')
resource existingvnet 'Microsoft.Network/virtualNetworks@2024-05-01' existing = {
  name: networkDetails.existingvnet
  scope: existingnetworkRG
}

@description('Reference the existing Private Endpoint Subnet')
resource existingsubnet 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' existing = {
  parent: existingvnet
  name: networkDetails.existingsubnet
}

@description('Reference the existing AKS Nodes Resource Group')
resource existingaksRG 'Microsoft.Resources/resourceGroups@2024-07-01' existing = {
  name: networkDetails.existingaksRG
}

@description('Reference the existing Keyvault addon User managed Identity')
resource existingmanagedidentity 'Microsoft.ManagedIdentity/userAssignedIdentities@2023-01-31' existing = {
  name: networkDetails.existingmanagedidentity
  scope: existingaksRG
}

@description('EventHub Namespace Deployment')
module eventHubNamespace 'br:pxsmytinfsweacr1.azurecr.io/elements/res/event-hub/namespace:0.7.1' = {
  name: take('${timestamp}-eventhub-${workloadName}', 64)
  scope: resourceGroup
  params: {
    name: eventHubNamespaceName
    location: location
    skuName: eventHubDetails.sku
    skuCapacity: eventHubDetails.throughputUnits
    isAutoInflateEnabled: false
    minimumTlsVersion: eventHubDetails.minimumTlsVersion
    zoneRedundant: eventHubDetails.zoneRedundant
    privateEndpoints: [
      for pe in eventHubDetails.privateEndpoints: {
        customDnsConfigs: pe.customDnsConfigs
        ipConfigurations: pe.ipConfigurations
        privateDnsZoneGroup: {
          privateDnsZoneGroupConfigs: [
            {
              privateDnsZoneResourceId: existingPrivateDNSZone.id
            }
          ]
        }
        subnetResourceId: existingsubnet.id
      }
    ]
    roleAssignments: [
      {
        principalId: existingmanagedidentity.properties.principalId
        principalType: 'ServicePrincipal'
        roleDefinitionIdOrName: 'Azure Event Hubs Data sender'
      }
    ]
    publicNetworkAccess: 'Enabled'
    enableTelemetry: enableTelemetry
  }
}
