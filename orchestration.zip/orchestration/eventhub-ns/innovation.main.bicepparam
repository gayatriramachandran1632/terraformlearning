using './main.bicep'

param nameObject = {
  client: 'pxs'
  workloadIdentifier: 'icdm'
  environment: 'd'
  region: 'we'
  purpose: 'filetransfer'
}

param eventHubDetails = {
  minimumTlsVersion: '1.2'
  zoneRedundant: true
  sku: 'Standard'
  throughputUnits: 1
  privateEndpoints: [
    {
      customDnsConfigs: [
        {
          fqdn: 'eh-ns.privatelink.servicebus.windows.net'
          ipAddresses: [
            '10.5.1.20'
          ]
        }
      ]
      ipConfigurations: [
        {
          name: 'ehnsIpConfig'
          properties: {
            groupId: 'namespace'
            memberName: 'namespace'
            privateIPAddress: '10.5.1.20'
          }
        }
      ]
    }
  ]
}

param location = 'West Europe'
param enableTelemetry = false

param networkDetails = {
  existingPrivateDNSZoneRG: 'pxs-azure-middleware-dns-d-gwc-rg'
  existingPrivateDNSZone: 'privatelink.servicebus.windows.net'
  existingnetworkRG: 'pxs-azure-middleware-d-gwc-rg'
  existingvnet: 'pxs-azure-middleware-d-gwc-vnet'
  existingsubnet: 'aks-privendpoint-subnet'
  existingaksRG: 'pxs-azure-middleware-d-gwc-rg_aks_pxs-azure-middleware-d-gwc-aks_nodes'
  existingmanagedidentity: 'azurekeyvaultsecretsprovider-pxs-azure-middleware-d-gwc-aks'
}
