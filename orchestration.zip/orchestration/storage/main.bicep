// ---------------------- Orchestration Bicep file ----------------------
targetScope = 'subscription'

metadata name = 'Deploy Storage Account resources'
metadata description = 'This Module deploys Storage Account into the selected subscription.'
metadata project = 'ACTP'
metadata workstream = 'Workstream A - E05'

// ---------------------- Parameters ----------------------
@description('Required. Name Object to create resource name')
param nameObject object

@description('Required. The location where the resources to be deployed.')
param location string

@description('Required.Security details of the storage account')
param storagesecuritydetails object

@description('Optional. timestamp')
param timestamp string = utcNow()

var workloadName = 'iac'

// Resource Group
resource resourceGroup 'Microsoft.Resources/resourceGroups@2024-07-01' = {
                                  name: (concat('${nameObject.client}-${nameObject.workloadIdentifier}-${nameObject.purpose}-${nameObject.environment}-${nameObject.region}-rg-1'))
  location: location
}

//var storagedetails = loadYamlContent('container.yaml')

// var storagedetailsdelete = loadYamlContent('containerdelete.yaml')
module storageAccount 'br/public:avm/res/storage/storage-account:0.18.0' = {

  scope: resourceGroup
  name: take('${timestamp}-st-${workloadName}', 64)
  params: {
    // Required parameters
    name: concat('${nameObject.client}${nameObject.workloadIdentifier}${nameObject.shortpurpose}${nameObject.environment}${nameObject.region}st01')
    // Non-required parameters
    allowBlobPublicAccess: storagesecuritydetails.publicstorageaccess
    skuName: 'Standard_ZRS'
    location: location
    networkAcls: {
      bypass: 'AzureServices'
      defaultAction: 'Deny'
    }
    blobServices: {
      isVersioningEnabled: true
      restorePolicyDays: storagesecuritydetails.restorepolicydays
      deleteRetentionPolicyDays: storagesecuritydetails.softdeleteforblobs
      containerDeleteRetentionPolicyDays: storagesecuritydetails.softdeleteforcontainers
      restorePolicyEnabled: storagesecuritydetails.restorePolicyEnabledbool
      containerDeleteRetentionPolicyEnabled: true
      changeFeedEnabled: true
      changeFeedRetentionInDays: storagesecuritydetails.changeFeedRetentionInDays
    }
    managementPolicyRules: [
      {
        enabled: true
        name: 'FirstRule'
        type: 'Lifecycle'
        definition: {
          actions: {
            version: {
              delete: {
                daysAfterCreationGreaterThan: 15
              }
            }
            baseBlob: {
              delete: {
                daysAfterModificationGreaterThan: 15
              }
            }
          }

          filters: {
            blobTypes: [
              'blockBlob'
            ]
          }
        }
      }
    ]
  }
}
