using './main.bicep'

param location = 'westeurope'

param nameObject = {
  client: 'pxs'
  workloadIdentifier: 'icdm'
  environment: 'd'
  region: 'we'
  purpose: 'filetransfer'
  shortpurpose: 'ft'
}
param storagesecuritydetails = {
  publicstorageaccess: false
  softdeleteforcontainers: 10
  softdeleteforblobs: 8
  restorepolicydays: 7
  changeFeedRetentionInDays: 8
  restorePolicyEnabledbool: true
}
