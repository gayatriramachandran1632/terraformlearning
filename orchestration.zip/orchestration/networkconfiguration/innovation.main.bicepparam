using './main.bicep'

param nameObject = {
 client: 'pxs'
  workloadIdentifier: 'azure'
  identifier: 'entfta'
  environment: 'innovation'
  region: 'gwc'
  purpose: 'privendpoint'  
}
param subnetdetails = {
  addressPrefix: '10.5.1.128/25'
}
param virtualnetworkdetails = {
  name: 'pxs-entfta-dev-gwc-vnet1'
  resourceGroupName: 'pxs-azure-connectivity-dev-rg'
}
