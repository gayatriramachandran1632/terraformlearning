// ---------------------- Orchestration Bicep file ----------------------
targetScope = 'subscription'

metadata name = 'Deploy Subnet resources'
metadata description = 'This Module deploys Subnet into an existing Virtual Network.'
metadata project = 'ACTP'
metadata workstream = 'Workstream A - E05'

// ---------------------- Parameters ----------------------
@description('Required. Name Object to create resource name')
param nameObject object

@description('Optional. timestamp')
param timestamp string = utcNow()

@description('Required.Network details of the subnet')
param subnetdetails object

@description('Required. The name of the parent virtual network.')
param virtualnetworkdetails object

var workloadName = 'iac'

// Resource Group
resource resourceGroupExisting 'Microsoft.Resources/resourceGroups@2024-07-01' existing = {
  name: virtualnetworkdetails.resourceGroupName  
}

// This module deploys a network security group into an existing resource group with the specified parameters.
module networkSecurityGroup 'br/public:avm/res/network/network-security-group:0.5.1' = {
  name: take('${timestamp}-nsg-${workloadName}', 64)
  scope: resourceGroupExisting
  params: {
    name: '${nameObject.client}-${nameObject.workloadIdentifier}-${nameObject.identifier}-${nameObject.purpose}-${nameObject.environment}-${nameObject.region}-nsg'
    }
}
// This module deploys a route table into an existing virtual network with the specified parameters.
module routetable 'br/public:avm/res/network/route-table:0.4.1' = {
  name: take('${timestamp}-rt-${workloadName}', 64)
  scope: resourceGroupExisting
  params: {
    name: '${nameObject.client}-${nameObject.workloadIdentifier}-${nameObject.identifier}-${nameObject.purpose}-${nameObject.environment}-${nameObject.region}-rt'
  }
}
// This module deploys a subnet into an existing virtual network with the specified parameters.
module subnetModule 'subnet.bicep' = {
  name: take('${timestamp}-snet-${workloadName}', 64)
  scope: resourceGroupExisting
  params: { 
    subnetName: '${nameObject.client}-${nameObject.workloadIdentifier}-${nameObject.identifier}-${nameObject.purpose}-${nameObject.environment}-${nameObject.region}-snet'
    addressPrefix: subnetdetails.addressPrefix
    virtualnetworkdetails: virtualnetworkdetails
    networkSecurityGroupResourceId: networkSecurityGroup.outputs.resourceId
    routeTableResourceId: routetable.outputs.resourceId
  }
}
