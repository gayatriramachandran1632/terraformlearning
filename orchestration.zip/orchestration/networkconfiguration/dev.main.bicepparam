using './main.bicep'

param nameObject = {
  client: 'pxs'
  workloadIdentifier: 'azure'
  identifier: 'entfta'
  environment: 'dev'
  region: 'gwc'
  purpose: 'privendpoint'
 
}
param subnetdetails = {
  addressPrefix: '10.27.128.32/28'
}

param virtualnetworkdetails = {
  name: 'pxs-entfta-dev-gwc-vnet1'
  resourceGroupName: 'pxs-azure-connectivity-dev-rg'
}
