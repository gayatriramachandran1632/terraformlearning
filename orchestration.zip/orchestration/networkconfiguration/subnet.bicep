param subnetName string
param addressPrefix string
param virtualnetworkdetails object
param networkSecurityGroupResourceId string
param routeTableResourceId string

resource existingVnet 'Microsoft.Network/virtualNetworks@2024-01-01' existing = {
  name: virtualnetworkdetails.name 
}

resource subnet 'Microsoft.Network/virtualNetworks/subnets@2024-05-01' = {
  name: subnetName
  parent: existingVnet
  properties: {
    addressPrefix: addressPrefix
    networkSecurityGroup: {
      id: networkSecurityGroupResourceId
    }
    routeTable: {
      id: routeTableResourceId
    }
  }
}
