# Container and Event Subscription creation YAML

This workflow is used to deploy Azure resources using Bicep.

---

## Workflow File

### **File Name**
`.github/workflows/azure-entft-deploy.yml`

---

## Description

The workflow has different jobs as per environment:
1. Checkout
2. Deploy Event Hub (Innovation)
3. Deploy Storage Account (Innovation)

---

## Triggers

Has workflow dispatch trigger and has to be triggered manually.
---

## Inputs

| Input Name   | Description                        | Type   | Required |
|--------------|------------------------------------|--------|----------|
| Needs to be added |  | String | Yes      |


---




