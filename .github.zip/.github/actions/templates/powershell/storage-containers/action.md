# Container and Event Subscription creation YAML

This workflow (yml) calls the powershell script to create Azure sub resources like container and eventsubscriptions.

---

## Workflow File

### **File Name**
`.github/actions/templates/containereventsubscription-powershell-creation/action.yml`

---

## Description

The workflow:
1. Install Powershell-YAML Module
2. Azure Login with OIDC
3. Call Container powershell script
4. Call Event Subscription powershell script

---

## Triggers

Would be triggered by the workflow in the entft_a_config_dev
https://github.com/Proximus-Corporate/entft_a_config_dev/blob/user/qaqazi/containerft/.github/workflows/create-containereventsubscription-innovation.yml
---

## Inputs

| Input Name   | Description                        | Type   | Required |
|--------------|------------------------------------|--------|----------|
| Needs to be added |  | String | Yes      |


---




