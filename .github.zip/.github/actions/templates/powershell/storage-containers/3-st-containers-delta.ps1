[CmdletBinding()]
param (
    [string]$target_containers = $env:TGT_CONTAINERS,
    [string]$source_containers = $env:SRC_CONTAINERS,
    [string]$target_local_users = $env:TGT_LOCAL_USERS
)

Write-Output "Step 3: Starting Step 3: Comparing target and source states..."

# Step 3.1: Load target and source state files
try {
    Write-Output "Step 3.1: Loading target and source state files..."
    $results_from_target = Get-Content -Path $target_containers | ConvertFrom-Json
    $results_from_source = Get-Content -Path $source_containers | ConvertFrom-Json
    $local_users_from_target = Get-Content -Path $target_local_users | ConvertFrom-Json
} catch {
    Write-Error "Step 3.1: Failed to read or parse input state files. $_"
    exit 1
}

# Step 3.2: Identify outdated role assignments and containers to remove
Write-Output "Step 3.2: Identifying outdated role assignments and containers for removal..."
$to_remove_assignments = @()
$to_remove_containers = @()
$to_remove_assignments_only = @()
$unique_containers = @()

foreach ($target_assignment in $results_from_target) {
    $source_container = $results_from_source | Where-Object { $_.ContainerName -eq $target_assignment.ContainerName }

    if ($source_container) {
        $source_role_assignments = $source_container | Where-Object {
            $_.PrincipalId -eq $target_assignment.PrincipalId -and
            $_.RoleDefinitionIdOrName -eq $target_assignment.RoleDefinitionIdOrName
        }

        $requires_sftp_match = $source_container | Where-Object {
            $_.PrincipalId -eq $target_assignment.PrincipalId -and
            $_.RequireSFTP -eq $true
        }

        if (-not $source_role_assignments -or $requires_sftp_match) {
            Write-Output "Step 3.2.1: Marking outdated role assignment for removal - Container: $($target_assignment.ContainerName), PrincipalId: $($target_assignment.PrincipalId)"
            $to_remove_assignments_only += $target_assignment
        }

    } else {
        Write-Output "Step 3.2.2: Marking role assignments and container for removal - Container: $($target_assignment.ContainerName), PrincipalId: $($target_assignment.PrincipalId)"
        $to_remove_assignments += $target_assignment
        $unique_containers += $target_assignment.ContainerName
        $to_remove_containers = $unique_containers | Sort-Object -Unique
    }
}

# Step 3.3: Save removal lists to files
Write-Output "Step 3.3: Saving removal lists to files..."
$remove_assignments_path = Join-Path -Path $PSScriptRoot -ChildPath "to-remove-assignments-only.json"
$remove_containers_path = Join-Path -Path $PSScriptRoot -ChildPath "to-remove-containers.json"

$to_remove_assignments_only | ConvertTo-Json -Depth 5 | Out-File -FilePath $remove_assignments_path -Encoding utf8
$to_remove_containers | ConvertTo-Json | Out-File -FilePath $remove_containers_path -Encoding utf8

# Step 3.4: Expose removal Output to GitHub
Write-Output "Step 3.4: Exposing removal Output to GitHub..."
"to-remove-assignments-only=$remove_assignments_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8
"to-remove-containers=$remove_containers_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8

Write-Output "Step 3.4.1: Removal lists saved to to-remove-assignments-only.json"
Write-Output "Step 3.4.2: Removal lists saved to to-remove-containers.json"
Write-Output "Step 3.4.3: Completed comparison for Removal."

# Step 3.5: Prepare list of containers and RBAC assignments to add
Write-Output "Step 3.5: Preparing deployment plan..."
$containers_to_create = @()
$roles_to_add_for_existing = @()

foreach ($entry in $results_from_source) {
    $container_exists = $results_from_target | Where-Object { $_.ContainerName -eq $entry.ContainerName }

    if (-not $container_exists) {
        # Container doesn't exist: mark for creation along with role
        $containers_to_create += [PSCustomObject]@{
            ContainerName = $entry.ContainerName
            PrincipalId = $entry.PrincipalId
            RoleDefinitionIdOrName = $entry.RoleDefinitionIdOrName
            RequireSFTP = $entry.RequireSFTP
        }
    } else {
        # Container exists: check role assignment
        $role_exists = $container_exists | Where-Object {
            $_.PrincipalId -eq $entry.PrincipalId -and
            $_.RoleDefinitionIdOrName -eq $entry.RoleDefinitionIdOrName
        }

        if (-not $role_exists) {
            if ($entry.RequireSFTP -eq $true) {
                Write-Output "Step 3.5.1: Skipping RBAC assignment for SFTP entry (container exists) - Container: $($entry.ContainerName)"
                continue
            }

            $roles_to_add_for_existing += [PSCustomObject]@{
                ContainerName = $entry.ContainerName
                PrincipalId = $entry.PrincipalId
                RoleDefinitionIdOrName = $entry.RoleDefinitionIdOrName
                RequireSFTP = $entry.RequireSFTP
            }

            Write-Output "Step 3.5.2: Adding RBAC assignment as SFTP is False (container exists) - Container: $($entry.ContainerName)"
        }
    }

    Write-Output "Step 3.99: Contents of containers_to_create is: $($containers_to_create)..."

}

# Step 3.6: Write additions to file
Write-Output "Step 3.6: Writing additions to file..."
$add_containers_path = Join-Path -Path $PSScriptRoot -ChildPath "to-add-containers.json"
$add_assignments_path = Join-Path -Path $PSScriptRoot -ChildPath "to-add-assignments-only.json"

$containers_to_create | ConvertTo-Json -Depth 5 | Out-File -FilePath $add_containers_path -Encoding utf8
$roles_to_add_for_existing | ConvertTo-Json -Depth 5 | Out-File -FilePath $add_assignments_path -Encoding utf8

# Step 3.7: Expose additions to GitHub
Write-Output "Step 3.7: Exposing additions to GitHub..."
"to-add-containers=$add_containers_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8
"to-add-assignments-only=$add_assignments_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8

Write-Output "Step 3.7.1: Additions list saved to to-add-containers.json"
Write-Output "Step 3.7.2: Additions list saved to to-add-assignments-only.json"
Write-Output "Step 3.7.3: Completed comparison for Additions."

# Step 3.8: Print summary of all Output files
Write-Output "`nStep 3.8: --- Contents of to-remove-assignments-only.json ---"
if (Test-Path -Path $remove_assignments_path) {
    Get-Content -Path $remove_assignments_path -Raw | ConvertFrom-Json | ConvertTo-Json -Depth 10
} else {
    Write-Output "File not found: $remove_assignments_path"
}

Write-Output "`nStep 3.8: --- Contents of to-remove-containers.json ---"
if (Test-Path -Path $remove_containers_path) {
    Get-Content -Path $remove_containers_path -Raw | ConvertFrom-Json | ConvertTo-Json -Depth 10
} else {
    Write-Output "File not found: $remove_containers_path"
}

Write-Output "`nStep 3.8: --- Contents of to-add-containers.json ---"
if (Test-Path -Path $add_containers_path) {
    Get-Content -Path $add_containers_path -Raw | ConvertFrom-Json | ConvertTo-Json -Depth 10
} else {
    Write-Output "File not found: $add_containers_path"
}

Write-Output "`nStep 3.8: --- Contents of to-add-assignments-only.json ---"
if (Test-Path -Path $add_assignments_path) {
    Get-Content -Path $add_assignments_path -Raw | ConvertFrom-Json | ConvertTo-Json -Depth 10
} else {
    Write-Output "File not found: $add_assignments_path"
}

# Step 3.9: Prepare SFTP users list (to be created or removed)
Write-Output "Step 3.9: Generating SFTP user lists for creation and removal..."

$sftp_users = @()

foreach ($entry in $results_from_source) {
    if ($entry.RequireSFTP -eq $true) {
        Write-Output "Step 3.9.1: SFTP user to be created - Container: $($entry.ContainerName), Username: $($entry.Username)"
        $sftp_users += [PSCustomObject]@{
            ContainerName = $entry.ContainerName
            RoleType      = $entry.RoleType
            Username      = $entry.Username
            Action        = "Create"
        }
    } else {
        Write-Output "Step 3.9.2: SFTP user to be removed - Container: $($entry.ContainerName), Username: $($entry.Username)"
        $sftp_users += [PSCustomObject]@{
            ContainerName = $entry.ContainerName
            RoleType      = $entry.RoleType
            Username      = $entry.Username
            Action        = "Delete"
        }
    }
}

# Check for unique sftp_users to avoid duplicates
$sftp_users = $sftp_users | Sort-Object -Property ContainerName, Username, RoleType, Action -Unique

# Check for users that already exist in the target but not in YAML. Will be removed.
foreach ($user in $local_users_from_target) {
    if (-not ($sftp_users | Where-Object { $_.Username -eq $user.name })) {
        Write-Output "Step 3.9.2: SFTP user to be removed (exists in target but not in YAML) - Container: $($user.homeDirectory), Username: $($user.name)"
        $sftp_users += [PSCustomObject]@{
            ContainerName = $user.homeDirectory
            Username      = $user.name
            Action        = "Delete"
        }
    }
}

# Loop through the $sftp_users list and remove those marked for deletion but present in the target
$filtered_sftp_users = @()

foreach ($user in $sftp_users) {
    $user_exists_in_target = $local_users_from_target | Where-Object { $_.name -eq $user.Username }
    if ($user_exists_in_target) {
        Write-Output "User '$($user.Username)' exists in the target, proceeding with action."
        if ($user.Action -eq "Delete") {
            $filtered_sftp_users += $user
            Write-Output "Keeping user '$($user.Username)' with action '$($user.Action)' in order to perform deletion."
        } else {
            Write-Output "User '$($user.Username)' with action '$($user.Action)' is ignored because it already exists in portal."
        }
    } else {
        Write-Output "User '$($user.Username)' does not exist in the portal, proceeding with action."
        if ($user.Action -eq "Delete") {
            Write-Output "Removing user '$($user.Username)' with action '$($user.Action)' from the filtered list as it does not exist in the target and is marked for deletion."
        } else {
            $filtered_sftp_users += $user
            Write-Output "Keeping user '$($user.Username)' with action '$($user.Action)' in the filtered list to perform creation."
        }
    }
}

Write-Output "Updated SFTP users list after removal of users who exist in the target and have Action=Delete:"
$filtered_sftp_users | Format-Table -Property ContainerName, Username, RoleType, Action
Write-Output "Total SFTP users after filtering: $($filtered_sftp_users)"
$sftp_users = $filtered_sftp_users | Sort-Object -Property ContainerName, Username, RoleType, Action -Unique

$sftp_users_path = Join-Path -Path $PSScriptRoot -ChildPath "sftp-users.json"
$sftp_users | ConvertTo-Json -Depth 5 | Out-File -FilePath $sftp_users_path -Encoding utf8
"sftp-users=$sftp_users_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8
Write-Output "Step 3.9.3: List of SFTP users saved to sftp-users.json"

Write-Output "`nStep 3.9.4: --- Contents of sftp-users.json ---"
if (Test-Path -Path $sftp_users_path) {
    Get-Content -Path $sftp_users_path -Raw | ConvertFrom-Json | ConvertTo-Json -Depth 10
} else {
    Write-Output "File not found: $sftp_users_path"
}