[CmdletBinding()]
param(
    [string]$subscription_id = $env:TGT_SUB_ID,
    [string]$target_resource_group = $env:TGT_RG_NAME,
    [string]$target_storage_account = $env:TGT_ST_NAME,
    [string]$source_files = $env:SRC_FILES
)

Write-Output "Step 2: Starting Step 2: Parsing source files..."

$results_from_source = @()

$source_file_paths = Get-Content -Path $source_files | ConvertFrom-Json

foreach ($source_file in $source_file_paths) {
    if (-not (Test-Path -Path $source_file)) {
        Write-Output "Step 2.1: source file $source_file not found, skipping."
        continue
    }

    Write-Output "Step 2.2: Parsing file: $source_file"
    $source_content = Get-Content -Path $source_file | Out-String | ConvertFrom-Yaml
    $container_name = [System.IO.Path]::GetFileNameWithoutExtension($source_file)

    if ($source_content.resource.provider -and $source_content.resource.provider.principalId) {
        $provider = $source_content.resource.provider
        $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.Storage/storageAccounts/$target_storage_account/blobServices/default/containers/$container_name"
        $results_from_source += [PSCustomObject]@{
            ContainerName = $container_name
            PrincipalId = $provider.principalId
            RoleDefinitionIdOrName = "Storage Blob Data Contributor"
            DisplayName = $provider.arisCode
            Scope = $scope
            RequireSFTP = $provider.requireSFTP
            RoleType = "Provider"
            Username = $provider.arisCode + "" + $source_content.resource.subject + "provider"
        }
        Write-Output "Step 2.3: Added provider role for container: $container_name"
    }

    if ($source_content.consumers) {
        foreach ($consumer in $source_content.consumers) {
            if ($consumer.principalId) {
                $consumer_principal_id = $consumer.principalId
                $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.Storage/storageAccounts/$target_storage_account/blobServices/default/containers/$container_name"
                $results_from_source += [PSCustomObject]@{
                    ContainerName = $container_name
                    PrincipalId = $consumer_principal_id
                    RoleDefinitionIdOrName = "Storage Blob Data Reader"
                    DisplayName = $consumer.arisCode
                    Scope = $scope
                    RequireSFTP = $consumer.requireSFTP
                    RoleType = "Consumer"
                    Username = $source_content.resource.provider.arisCode + "" + $source_content.resource.subject  + "" +  "consumer" + $consumer.arisCode
                }
                Write-Output "Step 2.4: Added consumer role for container: $container_name"
            }
        }
    }
}

Write-Output "Step 2.5: source state parsed successfully."

# Output results for next steps
$source_state_path = Join-Path -Path $PSScriptRoot -ChildPath "source-containers.json"
$results_from_source | ConvertTo-Json -Depth 5 | Out-File -FilePath $source_state_path
Write-Output "Step 2.6: Output written to $source_state_path"

# Expose path to GitHub Actions
"source-containers=$source_state_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append

Write-Output "`nStep 2.7 --- Contents of results_from_source ---"
$results_from_source | ConvertTo-Json -Depth 10
Write-Output "Step 2.7 --- End of results_from_source ---`n"