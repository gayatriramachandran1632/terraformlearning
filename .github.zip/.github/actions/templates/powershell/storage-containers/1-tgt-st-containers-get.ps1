[CmdletBinding()]
param(
    [string]$subscription_id = $env:TGT_SUB_ID,
    [string]$target_resource_group = $env:TGT_RG_NAME,
    [string]$target_storage_account = $env:TGT_ST_NAME,
    [string]$source_folder_path = $env:SRC_FOLDER_PATH
)

Write-Output "Step 1: Starting Step 1: Fetching target state..."

$tgt_st_keys = az storage account keys list -g $target_resource_group -n $target_storage_account --query [0].value
Write-Output "Step 1.1: Retrieved storage account keys."

# # Determine source files to process based on input path
# $source_files = @()
# $src_container_name = $null

# if ($source_folder_path -match '[\\/](.+?)\.yaml$') {
#     $src_container_name = [System.IO.Path]::GetFileNameWithoutExtension($source_folder_path)
#     Write-Output "Step 1.2: Container name from path: $src_container_name"

#     if ($src_container_name) {
#         if (Test-Path -Path $source_folder_path) {
#             $source_files = @(Get-Item -Path $source_folder_path)
#             Write-Output "Step 1.3: source file found and added to the list."
#         } else {
#             Write-Output "Step 1.4: source file $src_container_name not found."
#             $source_files = @() # Empty array if file does not exist
#         }
#     }
# } else {
#     if (Test-Path -Path $source_folder_path) {
#         $source_files = Get-ChildItem -Path $source_folder_path -Filter *.yaml
#         Write-Output "Step 1.5: Found source files in folder."
#     } else {
#         Write-Output "Step 1.6: Folder path $source_folder_path does not exist."
#         $source_files = @()
#     }
# }

# $results_from_target = @()

# if (-not $src_container_name) {
#     Write-Output "Step 1.7: Fetching all containers in the storage account."
#     $containers = az storage container list --account-name $target_storage_account --account-key $tgt_st_keys | ConvertFrom-Json
#     Write-Output "Step 1.8: Retrieved container list."

#     foreach ($container in $containers) {
#         Write-Output "Step 1.9: Checking role assignments for container: $($container.Name)"
#         $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.Storage/storageAccounts/$target_storage_account/blobServices/default/containers/$($container.Name)"
#         $role_assignments = az role assignment list --scope $scope --query "[?roleDefinitionName=='Storage Blob Data Reader' || roleDefinitionName=='Storage Blob Data Contributor']" | ConvertFrom-Json

#         if ($role_assignments) {
#             foreach ($role_assignment in $role_assignments) {
#                 if ($role_assignment.Scope -eq $scope) {
#                     $results_from_target += [PSCustomObject]@{
#                         ContainerName = $container.Name
#                         PrincipalId = $role_assignment.principalId
#                         RoleDefinitionIdOrName = $role_assignment.RoleDefinitionName
#                         DisplayName = $role_assignment.DisplayName
#                         Scope = $role_assignment.Scope
#                     }
#                     Write-Output "Step 1.10: Added role assignment for container: $($container.Name)"
#                 }
#             }
#         } else {
#             Write-Output "Step 1.11: No 'Storage Blob Data Reader/Contributor' role assignments found for container $($container.Name)."
#         }
#     }
# } else {
#     Write-Output "Step 1.12: Checking role assignments for single container: $($src_container_name)"
#     $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.Storage/storageAccounts/$target_storage_account/blobServices/default/containers/$src_container_name"
#     $role_assignments = az role assignment list --scope $scope --query "[?roleDefinitionName=='Storage Blob Data Reader' || roleDefinitionName=='Storage Blob Data Contributor']" | ConvertFrom-Json

#     if ($role_assignments) {
#         foreach ($role_assignment in $role_assignments) {
#             if ($role_assignment.Scope -eq $scope) {
#                 $results_from_target += [PSCustomObject]@{
#                     ContainerName = $src_container_name
#                     PrincipalId = $role_assignment.principalId
#                     RoleDefinitionIdOrName = $role_assignment.RoleDefinitionName
#                     DisplayName = $role_assignment.DisplayName
#                     Scope = $role_assignment.Scope
#                 }
#                 Write-Output "Step 1.13: Added role assignment for container: $src_container_name"
#             }
#         }
#     } else {
#         Write-Output "Step 1.14: No 'Storage Blob Data Reader/Contributor' role assignments found for container $src_container_name."
#     }
# }

# Write-Output "Step 1.15: Target state fetched successfully."

# Output results and source files list to files
# $target_state_path = Join-Path -Path $PSScriptRoot -ChildPath "target-containers.json"
# $source_files_path = Join-Path -Path $PSScriptRoot -ChildPath "source-files.json"

# $results_from_target | ConvertTo-Json -Depth 5 | Out-File -FilePath $target_state_path
# $source_files.FullName | ConvertTo-Json | Out-File -FilePath $source_files_path

# Write-Output "Step 1.16: Output written to target-containers.json and source-files.json"

# # Set GitHub Action Outputs
# "target-containers=$target_state_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append
# "source-files=$source_files_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append

# Write-Output "`nStep 1.17: --- Contents of results_from_target ---"
# $results_from_target | ConvertTo-Json -Depth 10
# Write-Output "Step 1.17: --- End of results_from_target ---`n"

# # Retreive local users for the storage account
# $local_users_from_target = az storage account local-user list --account-name $target_storage_account --resource-group $target_resource_group | ConvertFrom-Json

# $local_users_path = Join-Path -Path $PSScriptRoot -ChildPath "target-local-users.json"
# $local_users_from_target | ConvertTo-Json -Depth 5 | Out-File -FilePath $local_users_path
# Write-Output "Step 1.18: Local users fetched successfully."
# "target-local-users=$local_users_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append
# Write-Output "`nStep 1.19: --- Filtered local_users_from_target (name + homeDirectory) ---"
# $local_users_from_target | Select-Object name, homeDirectory | ConvertTo-Json -Depth 2
# Write-Output "Step 1.19: --- End of filtered output ---`n"