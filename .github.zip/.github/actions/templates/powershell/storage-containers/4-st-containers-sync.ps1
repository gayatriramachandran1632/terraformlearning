[CmdletBinding()]
param(    
    [string]$subscription_id = $env:TGT_SUB_ID,
    [string]$target_resource_group = $env:TGT_RG_NAME,
    [string]$target_storage_account = $env:TGT_ST_NAME,
    [string]$target_key_vault = $env:TGT_AKV_NAME,
    [string]$src_remove_assnmts_only = $env:SRC_REMOVE_ASSNMTS_ONLY,
    [string]$src_to_remove_containers = $env:SRC_TO_REMOVE_CONTAINERS,
    [string]$src_to_add_containers = $env:SRC_TO_ADD_CONTAINERS,
    [string]$src_to_add_assnmts_only = $env:SRC_TO_ADD_ASSNMTS_ONLY,
    [string]$src_sftp_users = $env:SRC_SFTP_USERS
)

Write-Output "Step 4: Starting Step 4: Add new containers & role assignments (from source state)"

# Step 4.1: Load removal lists
$to_remove_assignments_only = @()
$to_remove_containers = @()

if (Test-Path -Path $src_remove_assnmts_only) {
    Write-Output "Step 4.1: Loading outdated role assignments from: $src_remove_assnmts_only"
    $to_remove_assignments_only = Get-Content -Path $src_remove_assnmts_only | ConvertFrom-Json
} else {
    Write-Output "Step 4.1: No outdated role assignments to remove."
}

if (Test-Path -Path $src_to_remove_containers) {
    Write-Output "Step 4.2: Loading outdated containers from: $src_to_remove_containers"
    $to_remove_containers = Get-Content -Path $src_to_remove_containers | ConvertFrom-Json
} else {
    Write-Output "Step 4.2: No containers to remove."
}

# Step 4.3: Get storage account key
Write-Output "Step 4.3: Retrieving storage account keys for $target_storage_account"
$storage_account_keys = az storage account keys list -g $target_resource_group -n $target_storage_account --query [0].value -o tsv

# Step 4.4: Deleting outdated assignments and containers
Write-Output "Step 4.4: Removing outdated containers and role assignments."

foreach ($remove_assignment in $to_remove_assignments_only) {
    Write-Output "Step 4.4.1: Removing Role Assignment for Container: $($remove_assignment.ContainerName), PrincipalId: $($remove_assignment.PrincipalId)"
    az role assignment delete --scope $remove_assignment.Scope --assignee $remove_assignment.PrincipalId --role $remove_assignment.RoleDefinitionIdOrName
}

foreach ($container_name_entry in $to_remove_containers) {
    Write-Output "Step 4.4.2: Deleting container: $container_name_entry"
    az storage container delete --account-name $target_storage_account --account-key $storage_account_keys --name $container_name_entry
}

Write-Output "Step 4.4.3: Removal completed."

# Step 4.5: Creating new containers and adding role assignments
Write-Output "Step 4.5: Creating new containers and assigning role assignments"

$containers_to_create = @()
$roles_to_add_for_existing = @()

if (Test-Path -Path $src_to_add_containers) {
    Write-Output "Step 4.5.1: Loading containers to create from: $src_to_add_containers"
    $containers_to_create = Get-Content -Path $src_to_add_containers | ConvertFrom-Json
}

if (Test-Path -Path $src_to_add_assnmts_only) {
    Write-Output "Step 4.5.2: Loading role assignments to add from: $src_to_add_assnmts_only"
    $roles_to_add_for_existing = Get-Content -Path $src_to_add_assnmts_only | ConvertFrom-Json
}

foreach ($entry in $containers_to_create) {
    $container_name = $entry.ContainerName
    $principal_id = $entry.PrincipalId
    $role = $entry.RoleDefinitionIdOrName

    Write-Output "Step 4.5.3: Creating container: $container_name"
    az storage container create `
        --name $container_name `
        --account-name $target_storage_account `
        --account-key $storage_account_keys | Out-Null

    if ($LASTEXITCODE -eq 0) {
        if ($entry.RequireSFTP -ne $true) {
            $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.Storage/storageAccounts/$target_storage_account/blobServices/default/containers/$container_name"
            Write-Output "Step 4.5.4: Assigning role: $role to principal $principal_id on container $container_name"
            az role assignment create `
                --assignee-object-id $principal_id `
                --role $role `
                --scope $scope `
                --assignee-principal-type ServicePrincipal
        } else {
            Write-Output "Step 4.5.5: Skipping role assignment for SFTP container: $container_name"
        }
    } else {
        Write-Output "Step 4.5.6: Failed to create container: $container_name"
    }
}

foreach ($entry in $roles_to_add_for_existing) {
    $container_name = $entry.ContainerName
    $principal_id = $entry.PrincipalId
    $role = $entry.RoleDefinitionIdOrName

    if ($entry.RequireSFTP -ne $true) {
        $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.Storage/storageAccounts/$target_storage_account/blobServices/default/containers/$container_name"
        Write-Output "Step 4.5.7: Assigning role to existing container: $container_name"
        az role assignment create `
            --assignee-object-id $principal_id `
            --role $role `
            --scope $scope `
            --assignee-principal-type ServicePrincipal
    } else {
        Write-Output "Step 4.5.8: Skipping role assignment for SFTP container: $container_name"
    }
}

# Step 4.6: Create/Delete SFTP Local Users
$sftp_users = @()
if (Test-Path -Path $src_sftp_users) {
    Write-Output "Step 4.6: Loading SFTP users from: $src_sftp_users"
    $sftp_users = Get-Content -Path $src_sftp_users | ConvertFrom-Json
} else {
    Write-Output "Step 4.6: No SFTP users found."
}

foreach ($user in $sftp_users) {
    $container = $user.ContainerName
    $username = $user.Username
    $action = $user.Action.ToLowerInvariant()

    if ($action -eq "create") {
        Write-Output "Step 4.6.1: Creating local user '$username' for container '$container'"

        az storage account local-user create `
            --account-name "$target_storage_account" `
            --resource-group "$target_resource_group" `
            --name "$username" `
            --home-directory "$container" `
            --permission-scope permissions=rl service=blob resource-name="$container" `
            --has-shared-key true `
            --has-ssh-key false `
            --has-ssh-password true

        $password = (az storage account local-user regenerate-password `
            --account-name "$target_storage_account" `
            --resource-group "$target_resource_group" `
            --name "$username" `
            --only-show-errors `
            --output json | ConvertFrom-Json).sshPassword

        Write-Output "Step 4.6.2: Storing password in Key Vault as secret '$username'"
        Write-Output "Step 4.6.2: Storing password in Key Vault as secret '$password'"

        $max_retries = 3
        $retry_delay = 5
        $retry_count = 0
        $secret_set_succeeded = $false

        while (-not $secret_set_succeeded -and $retry_count -lt $max_retries) {
            $secret_set_result = az keyvault secret set `
                --vault-name "$target_key_vault" `
                --name "$username" `
                --value "$password" `
                2>&1

            if ($secret_set_result -like "*ObjectIsDeletedButRecoverable*") {
                Write-Output "Secret '$username' is in a deleted-but-recoverable state. Attempting recovery..."

                az keyvault secret recover `
                    --vault-name "$target_key_vault" `
                    --name "$username" | Out-Null

                Write-Output "Waiting 5 seconds for recovery to begin..."
                Start-Sleep -Seconds 5

            } elseif ($secret_set_result -like "*ObjectIsBeingRecovered*") {
                Write-Output "Secret '$username' is still being recovered. Waiting and retrying... ($($retry_count + 1)/$max_retries)"
                Start-Sleep -Seconds $retry_delay
                $retry_count++
            } elseif ($LASTEXITCODE -eq 0) {
                $secret_set_succeeded = $true
            } else {
                Write-Output "Unexpected error setting Key Vault secret for '$username':"
                Write-Output $secret_set_result
                throw "Failed to store secret in Key Vault."
            }
        }

        if ($secret_set_succeeded) {
            Write-Output "Step 4.6.4: Stored password in Key Vault as secret '$username'"
        } else {
            throw "Failed to store secret in Key Vault for user '$username' after $max_retries retries."
        }

    } elseif ($action -eq "delete") {
        Write-Output "Step 4.6.5: Deleting local user '$username' and its Key Vault secret"

        az storage account local-user delete `
            --account-name $target_storage_account `
            --name $username `
            --resource-group $target_resource_group | Out-Null

        Write-Output "Step 4.6.5: Deleted local user '$username'"
        Write-Output "Step 4.6.6: Deleting Key Vault secret for user '$username'"
        az keyvault secret delete `
            --vault-name $target_key_vault `
            --name $username | Out-Null

        Write-Output "Step 4.6.6: Deleted local user and Key Vault secret for user '$username'"
    }
}

Write-Output "Step 4: Completed all additions and deletions for containers and SFTP users."