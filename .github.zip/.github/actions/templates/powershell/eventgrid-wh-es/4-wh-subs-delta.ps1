[CmdletBinding()]
param (
    [string]$target_event_subs = $env:TGT_WH_STATE,
    [string]$source_event_subs = $env:SRC_WH_STATE,
    [string]$app_id_or_uri = $env:TGT_WH_APP_ID,
    [string]$tenant_id = $env:TGT_WH_TENANT_ID
)

try {
    $results_from_target = Get-Content -Path $target_event_subs | ConvertFrom-Json
    $results_from_source = Get-Content -Path $source_event_subs | ConvertFrom-Json
} catch {
    Write-Error "Step 4: Failed to read or parse input state files. $_"
    exit 1
}

$to_add = @()
$to_update = @()
$to_delete = @()

Write-Output "Step 4: Comparing source and target subscriptions..."

foreach ($source_entry in $results_from_source) {
    $existing_subscription = $results_from_target | Where-Object { $_.Name -eq $source_entry.Name }
    $subject_begins_with = "/blobServices/default/containers/$($source_entry.SubjectBeginsWith)"

    if (-not $existing_subscription) {
        # New subscription to be added
        $to_add += [PSCustomObject]@{
            Name              = $source_entry.Name
            Url               = $source_entry.Url
            Authentication    = $source_entry.Authentication
            SubjectBeginsWith = $subject_begins_with
        }
    }
    else {
        # Check if any updates are required
        $update_required = $false

        if (
            $existing_subscription.Url -ne $source_entry.Url -or
            $existing_subscription.ApplicationIdorUri -ne $app_id_or_uri -or
            $existing_subscription.TenantId -ne $tenant_id -or
            $existing_subscription.SubjectBeginsWith -ne $subject_begins_with
        ) {
            $update_required = $true
        }

        if ($update_required) {
            $to_update += [PSCustomObject]@{
                Name              = $source_entry.Name
                Url               = $source_entry.Url
                Authentication    = $source_entry.Authentication
                SubjectBeginsWith = $subject_begins_with
            }
        }
    }
}

# Determine deletions
foreach ($target_entry in $results_from_target) {
    if ($target_entry.Name -eq "StorageAntimalwareSubscription") { continue }

    $exists_in_source = $results_from_source | Where-Object { $_.Name -eq $target_entry.Name }
    if (-not $exists_in_source) {
        $to_delete += $target_entry
    }
}

# Write to-add-event-subs subscriptions
$to_add_path = Join-Path -Path $PSScriptRoot -ChildPath "to-add-event-subs.json"
$to_add | ConvertTo-Json -Depth 5 | Out-File -FilePath $to_add_path -Encoding utf8
"to-add-event-subs=$to_add_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8

Write-Output "`nStep 4: --- Contents of to-add-event-subs ---"
$to_add | ConvertTo-Json -Depth 10
Write-Output "Step 4: --- End of to-add-event-subs ---`n"

# Write to-update-event-subs subscriptions
$to_update_path = Join-Path -Path $PSScriptRoot -ChildPath "to-update-event-subs.json"
$to_update | ConvertTo-Json -Depth 5 | Out-File -FilePath $to_update_path -Encoding utf8
"to-update-event-subs=$to_update_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8

Write-Output "`nStep 4: --- Contents of to-update-event-subs ---"
$to_update | ConvertTo-Json -Depth 10
Write-Output "Step 4: --- End of to-update-event-subs ---`n"

# Write to-remove-event-subs subscriptions
$to_delete_path = Join-Path -Path $PSScriptRoot -ChildPath "to-remove-event-subs.json"
$to_delete | ConvertTo-Json -Depth 5 | Out-File -FilePath $to_delete_path -Encoding utf8
"to-remove-event-subs=$to_delete_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8

Write-Output "`nStep 4: --- Contents of to-remove-event-subs ---"
$to_delete | ConvertTo-Json -Depth 10
Write-Output "Step 4: --- End of to-remove-event-subs ---`n"
