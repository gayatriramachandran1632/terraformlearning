[CmdletBinding()]
param (
    [string]$source_files = $env:SRC_FILES
)

Write-Output "step 3: parsing source configuration files..."

# initialize result list
$results_from_source = @()

try {
    $source_file_paths = Get-Content -Path $source_files | ConvertFrom-Json
} catch {
    Write-Error "step 3: failed to read or parse source files list from $source_files. $_"
    return
}

if (-not $source_file_paths) {
    Write-Output "step 3: no source files found in the provided path."
    return
} else {
    Write-Output "step 3: found source files: $($source_file_paths -join ', ')"
}

# parse source content
foreach ($file in $source_file_paths) {
    if (-not (Test-Path -Path $file)) {
        Write-Output "step 3: source file $file not found, skipping."
        continue
    }

    try {
        $source_content = Get-Content -Path $file -Raw | ConvertFrom-YAML
    } catch {
        Write-Warning "step 3: failed to parse source file $file. $_"
        continue
    }

    $container_name = [System.IO.Path]::GetFileNameWithoutExtension($file)

    if ($null -ne $source_content.consumers) {
        foreach ($consumer in $source_content.consumers) {
            if ($null -ne $consumer.notifications -and $null -ne $consumer.notifications.webHook) {
                $webhook = $consumer.notifications.webHook

                $results_from_source += [PSCustomObject]@{
                    Name              = $consumer.arisCode
                    Url               = $webhook.url
                    Authentication    = $webhook.authentication
                    SubjectBeginsWith = $container_name
                }
            }
        }
    }
}

# save parsed results
$source_state_path = Join-Path -Path $PSScriptRoot -ChildPath "source-event-subs.json"
$results_from_source | ConvertTo-Json -Depth 5 | Out-File -FilePath $source_state_path -Encoding utf8
"source-event-subs=$source_state_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8

# debug output
Write-Output "`nstep 3: --- contents of results_from_source ---"
$results_from_source | ConvertTo-Json -Depth 10
Write-Output "step 3: --- end of results_from_source ---`n"
