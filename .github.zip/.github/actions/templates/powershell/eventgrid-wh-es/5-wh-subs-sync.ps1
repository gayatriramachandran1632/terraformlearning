[CmdletBinding()]
param (
    [string]$target_resource_group = $env:TGT_RG_NAME,
    [string]$target_system_topic = $env:TGT_SYS_TOPIC_NAME,
    [string]$application_id_or_uri = $env:APP_ID_OR_URI,
    [string]$tenant_id = $env:TENANT_ID,
    [string]$to_add_path = $env:TO_ADD,
    [string]$to_update_path = $env:TO_UPDATE,
    [string]$to_delete_path = $env:TO_DELETE
)

try {
    $to_add = Get-Content -Path $to_add_path | ConvertFrom-Json
    $to_update = Get-Content -Path $to_update_path | ConvertFrom-Json
    $to_delete = Get-Content -Path $to_delete_path | ConvertFrom-Json
} catch {
    Write-Error "Step 5: Failed to read or parse input state files. $_"
    exit 1
}

# ------------------------------
# CREATE or UPDATE SUBSCRIPTIONS
# ------------------------------
Write-Output "`nStep 5: Creating or updating subscriptions..."

foreach ($entry in $to_add + $to_update) {
    $is_add = $false
    foreach ($add in $to_add) {
        if ($add.Name -eq $entry.Name) {
            $is_add = $true
            break
        }
    }
    $action = $is_add ? "Created" : "Updated"
    $auth_type = $entry.Authentication

    if ($auth_type -eq "EntraId") {
        az eventgrid system-topic event-subscription create `
            --name $entry.Name `
            --resource-group $target_resource_group `
            --system-topic-name $target_system_topic `
            --endpoint $entry.Url `
            --endpoint-type webhook `
            --aad-tenant-id $tenant_id `
            --azure-active-directory-application-id-or-uri $application_id_or_uri `
            --included-event-types Microsoft.Storage.BlobCreated Microsoft.Storage.BlobDeleted `
            --subject-begins-with $entry.SubjectBeginsWith

        if ($LASTEXITCODE -eq 0) {
            Write-Output "Step 5:  ${action} (EntraId): $($entry.Name)"
        } else {
            Write-Output "Step 5: Failed to  ${action} (EntraId): $($entry.Name)"
        }
    } else {
        az eventgrid system-topic event-subscription create `
            --name $entry.Name `
            --resource-group $target_resource_group `
            --system-topic-name $target_system_topic `
            --endpoint $entry.Url `
            --endpoint-type webhook `
            --included-event-types Microsoft.Storage.BlobCreated Microsoft.Storage.BlobDeleted `
            --subject-begins-with $entry.SubjectBeginsWith

        if ($LASTEXITCODE -eq 0) {
            Write-Output "Step 5:  ${action}: $($entry.Name)"
        } else {
            Write-Output "Step 5: Failed to  ${action}: $($entry.Name)"
        }
    }
}

# ------------------------------
# DELETE SUBSCRIPTIONS
# ------------------------------
Write-Output "`nStep 5: Deleting outdated subscriptions..."

foreach ($entry in $to_delete) {
    if ($entry.Name -eq "StorageAntimalwareSubscription") {
        Write-Output "Step 5: Skipping deletion of protected subscription: $($entry.Name)"
        continue
    }

    az eventgrid system-topic event-subscription delete `
        --name $entry.Name `
        --resource-group $target_resource_group `
        --system-topic-name $target_system_topic `
        --yes

    if ($LASTEXITCODE -eq 0) {
        Write-Output "Step 5: Deleted: $($entry.Name)"
    } else {
        Write-Output "Step 5: Failed to delete: $($entry.Name)"
    }
}
