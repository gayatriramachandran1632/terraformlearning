# This script fetches the Azure Event Grid System Topic name associated with a given storage account.
# The name of the system topic is then used for the creation of an Event Subscription.

[CmdletBinding()]
param (
    [string]$target_resource_group = $env:TGT_RG_NAME,
    [string]$target_storage_account = $env:TGT_ST_NAME
)

# part 1: start
Write-Output "step 1: starting the script..."

# fetch system topics from Azure for the given storage account
$system_topics = az eventgrid system-topic list --resource-group $target_resource_group `
    | ConvertFrom-Json `
    | Where-Object { $_.source -like "*$target_storage_account*" }

# handle case where no system topic is found
if (-not $system_topics) {
    Write-Error "step 1: no event grid system topic found for storage account '$target_storage_account' in resource group '$target_resource_group'."
    exit 1
}

# extract system topic name
$target_system_topic = $system_topics.name

# set output for GitHub Actions
"target-system-topic=$target_system_topic" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8

# output result to console
Write-Output "`nstep 1: --- name of system topic: $target_system_topic ---"
