[CmdletBinding()]
param (
    [string]$target_resource_group = $env:TGT_RG_NAME,
    [string]$target_storage_account = $env:TGT_ST_NAME,
    [string]$target_system_topic = $env:TGT_SYS_TOPIC_NAME,
    [string]$source_folder_path = $env:SRC_FOLDER_PATH
)

Write-Output "step 2: fetching event grid subscriptions from azure portal..."
Write-Output "step 2: resource group name: $target_resource_group"
Write-Output "step 2: storage account name: $target_storage_account"
Write-Output "step 2: system topic name: $target_system_topic"

# fetch details from the portal
$es_from_target_raw = az eventgrid system-topic event-subscription list --resource-group $target_resource_group --system-topic-name $target_system_topic
$event_subscriptions = $es_from_target_raw | ConvertFrom-Json

# initialize result arrays
$container_name_from_path = $null
$source_files = @()

if ($source_folder_path -match '[\\/](.+?)\.yaml$') {
    $container_name_from_path = [System.IO.Path]::GetFileNameWithoutExtension($source_folder_path)
    Write-Output "step 2: container name from path: $container_name_from_path"
    Write-Output "step 2: folder path: $source_folder_path"
    
    if ($container_name_from_path) {
        if (Test-Path -Path $source_folder_path) {
            $source_files = @(Get-Item -Path $source_folder_path | ForEach-Object { $_.FullName })
        } else {
            Write-Output "step 2: source file $container_name_from_path not found."
            $source_files = @()
        }
    }
} else {
    if (Test-Path -Path $source_folder_path) {
        $source_files = @(Get-ChildItem -Path $source_folder_path -Filter *.yaml | ForEach-Object { $_.FullName })
    } else {
        Write-Output "step 2: folder path $source_folder_path does not exist."
        $source_files = @()
    }
}

$processed_subscriptions = @()

if ($container_name_from_path) {
    Write-Output "step 2: fetching event subscriptions for container: $container_name_from_path"

    foreach ($subscription in $event_subscriptions) {
        $destination = $subscription.destination
        $subject_path = $subscription.filter?.subjectBeginsWith

        if ($destination.endpointType -eq "WebHook" -and $subject_path -match "/blobServices/default/containers/([^/]+)" -and $matches[1] -eq $container_name_from_path) {
            $processed_subscriptions += [PSCustomObject]@{
                Name                = $subscription.name
                Url                 = $destination.endpointBaseUrl
                ApplicationIdorUri  = $destination.azureActiveDirectoryApplicationIdOrUri
                TenantId            = $destination.azureActiveDirectoryTenantId
                EndpointType        = $destination.endpointType
                SubjectBeginsWith   = $subject_path
            }
        }
    }
} else {
    Write-Output "step 2: no container name found in path. processing all source files."
    Write-Output "step 2: fetching all event subscriptions in the event grid system topic."

    foreach ($subscription in $event_subscriptions) {
        $destination = $subscription.destination
        $filter = $subscription.filter

        if ($destination.endpointType -eq "WebHook") {
            $processed_subscriptions += [PSCustomObject]@{
                Name                = $subscription.name
                Url                 = $destination.endpointBaseUrl
                ApplicationIdorUri  = $destination.azureActiveDirectoryApplicationIdOrUri
                TenantId            = $destination.azureActiveDirectoryTenantId
                EndpointType        = $destination.endpointType
                SubjectBeginsWith   = $filter.subjectBeginsWith
            }
        }
    }
}

$target_event_subs = Join-Path -Path $PSScriptRoot -ChildPath "target-event-subs.json"
$processed_subscriptions | ConvertTo-Json -Depth 30 | Out-File -FilePath $target_event_subs -Encoding utf8
"target-event-subs=$target_event_subs" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8

$source_files_path = Join-Path -Path $PSScriptRoot -ChildPath "source-files.json"
$source_files | ConvertTo-Json -Depth 30 | Out-File -FilePath $source_files_path -Encoding utf8
"source-files=$source_files_path" | Out-File -FilePath $env:GITHUB_OUTPUT -Append -Encoding utf8

Write-Output "`nstep 2: --- contents of processed_subscriptions ---"
$processed_subscriptions | ConvertTo-Json -Depth 30
Write-Output "step 2: --- end of processed_subscriptions ---`n"

Write-Output "`nstep 2: --- contents of source_files ---"
$source_files | ConvertTo-Json -Depth 30
Write-Output "step 2: --- end of source_files ---`n"
