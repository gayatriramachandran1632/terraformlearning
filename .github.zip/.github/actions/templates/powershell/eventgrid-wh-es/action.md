# Deploy Event Subscriptions � PowerShell GitHub Action

Composite GitHub Action to deploy Azure Event Grid subscriptions using PowerShell automation.

---

## Overview

This action:
- Authenticates to Azure using OIDC.
- Reads event subscription definitions from source files.
- Compares the current Azure state with the desired state.
- Applies changes if whatif is set to false.

---

## Workflow Steps

1. Install PowerShell-YAML module � Required to parse input source files.
2. Login to Azure � Using azure/login@v2 with federated credentials (OIDC).
3. Get existing system topic � Fetch metadata related to the system topic and storage.
4. Fetch current Azure state � Collect event subscriptions from the Azure portal.
5. Parse source configurations � Load desired state from source files.
6. Compare target and source state � Generate delta (what to add/update/delete).
7. Apply changes to Azure � Applies only if whatif != 'true'.

---

## Inputs

| Name                          | Description                                         | Required | Example                                  |
|-------------------------------|-----------------------------------------------------|----------|------------------------------------------|
| environment                   | Environment name                                    | Yes      | innovation                               |
| folderPath                    | Path to folder containing input source files          | Yes      | /innovation/pxsicdmftdwest01/mba-phone   |
| clientId                      | Azure AD application client ID                      | Yes      | GUID                                     |
| tenantId                      | Azure AD tenant ID                                  | Yes      | GUID                                     |
| location                      | Azure location                                      | Yes      | westeurope                               |
| subscription_id               | Azure subscription ID                               | Yes      | GUID                                     |
| storageaccountname            | Storage account name linked to system topic         | Yes      | pxsicdmftdwest01                         |
| filetransferresourcegroupname | Resource group name where infra is deployed         | Yes      | pxsicdmftdwest01-RG                      |
| applicationIdorUri            | Application ID or URI (used in webhook scenarios)   | Yes      | http://someurl                           |
| systemtopicname               | Event Grid system topic name                        | Yes      | pxsicdmftdwest01-system-topic            |
| whatif                        | If 'true', skips applying changes                   | No       | 'true' or 'false' (default: 'false')     |

---

## Conditional Execution

Changes will only be applied if:  
whatif != 'true'  
This helps in dry runs and previewing the impact without modifying Azure resources.

---

## Example Usage

```yaml
uses: ./.github/actions/templates/eventsubscription-powershell-creation
with:
  environment: 'innovation'
  folderPath: '/innovation/pxsicdmftdwest01/mba-phone'
  clientId: ${{ secrets.AZURE_CLIENT_ID }}
  tenantId: ${{ secrets.AZURE_TENANT_ID }}
  location: 'westeurope'
  subscription_id: ${{ secrets.AZURE_SUBSCRIPTION_ID }}
  storageaccountname: 'pxsicdmftdwest01'
  filetransferresourcegroupname: 'pxsicdmftdwest01-RG'
  applicationIdorUri: 'http://someurl'
  systemtopicname: 'pxsicdmftdwest01-system-topic'
  whatif: 'false'
