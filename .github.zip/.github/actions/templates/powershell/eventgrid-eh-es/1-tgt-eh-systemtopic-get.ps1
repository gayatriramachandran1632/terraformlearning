# This script fetches the Azure Event Grid System Topic name associated with a given storage account.
# The name of the system topic is then used for the creation of an Event Subscription.

param (
    [string]$target_resource_group = $env:TGT_RG_NAME,
    [string]$target_storage_account = $env:TGT_ST_NAME
)

# PART 1: Start
Write-Output "Step 1: Starting the script..."

# Fetch system topics from Azure for the given storage account
$system_topics = az eventgrid system-topic list --resource-group $target_resource_group `
    | ConvertFrom-Json `
    | Where-Object { $_.source -like "*$target_storage_account*" }

# Handle case where no system topic is found
if (-not $system_topics) {
    Write-Error "Step 1: No Event Grid System Topic found for storage account '$target_storage_account' in resource group '$target_resource_group'."
    exit 1
}

# Extract system topic name
$target_system_topic = $system_topics.name

# Set output for GitHub Actions
"target-system-topic=$target_system_topic" >> $env:GITHUB_OUTPUT

# Output result to console
Write-Output "`nStep 1: --- Name of system topic: $target_system_topic ---"
