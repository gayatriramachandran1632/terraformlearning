<#
    Description:
    This script parses source configuration files to extract Event Grid subscriptions and Event Hub details.

    Output:
    - source-event-subs: List of Event Grid subscriptions (filtered by consumer events).
    - source-event-hubs: List of Event Hub details (with role assignments).
#>

param (
    [string]$subscription_id = $env:TGT_SUB_ID,
    [string]$target_resource_group = $env:TGT_RG_NAME,
    [string]$source_files = $env:SRC_FILES,
    [string]$target_eventhub_namespace = $env:TGT_EH_NAME
)

Write-Output "Step 3: Parsing source configuration files..."

$event_subs_from_source = @()
$event_hubs_from_source = @()

$source_file_paths = Get-Content -Path $source_files | ConvertFrom-Json
if (-not $source_file_paths) {
    Write-Output "Step 3: No source files found in the provided path."
    return
} else {
    Write-Output "Step 3: Found source files: $($source_file_paths -join ', ')"
}

foreach ($file in $source_file_paths) {
    if (-not (Test-Path $file)) {
        Write-Output "Step 3: source file $file not found, skipping."
        continue
    }

    $source_content = Get-Content -Path $file | Out-String | ConvertFrom-Yaml
    $container_name = [System.IO.Path]::GetFileNameWithoutExtension($file)
    $event_hub_name = "$container_name-eh"
    $event_subs_name = "$container_name-es"

    if ($source_content.consumers) {
        foreach ($consumer in $source_content.consumers) {
            if (
                $consumer.notifications -and
                $consumer.notifications.eventHub -and
                $consumer.notifications.eventHub.enabled -eq $true
            ) {
                if (-not ($event_subs_from_source | Where-Object { $_.Name -eq $event_subs_name })) {
                    $event_subs_from_source += [PSCustomObject]@{
                        Name              = $event_subs_name
                        SubjectBeginsWith = $container_name
                        EventHubName      = $event_hub_name
                    }
                }

                $consumer_principal_id = $consumer.principalId
                $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.EventHub/namespaces/$target_eventhub_namespace/eventhubs/$event_hub_name"

                if (-not ($event_hubs_from_source | Where-Object { $_.EventHubName -eq $event_hub_name -and $_.PrincipalId -eq $consumer_principal_id })) {
                    $event_hubs_from_source += [PSCustomObject]@{
                        EventHubName           = $event_hub_name
                        PrincipalId            = $consumer_principal_id
                        RoleDefinitionIdOrName = "Azure Event Hubs Data Receiver"
                        DisplayName            = $consumer.arisCode
                        Scope                  = $scope
                    }
                }
            }
        }
    }
}

$event_subs_source_path = Join-Path -Path $PSScriptRoot -ChildPath "source-event-subs.json"
$event_subs_from_source | ConvertTo-Json -Depth 5 | Out-File -FilePath $event_subs_source_path
"source-event-subs=$event_subs_source_path" >> $env:GITHUB_OUTPUT

Write-Output "`nStep 3: --- Contents of eventsubsfromsource ---"
$event_subs_from_source | ConvertTo-Json -Depth 10
Write-Output "Step 3: --- End of eventsubsfromsource ---`n"

$event_hubs_source_path = Join-Path -Path $PSScriptRoot -ChildPath "source-event-hubs.json"
$event_hubs_from_source | ConvertTo-Json -Depth 5 | Out-File -FilePath $event_hubs_source_path
"source-event-hubs=$event_hubs_source_path" >> $env:GITHUB_OUTPUT

Write-Output "`nStep 3: --- Contents of eventhubsfromsource ---"
$event_hubs_from_source | ConvertTo-Json -Depth 10
Write-Output "Step 3: --- End of eventhubsfromsource ---`n"
