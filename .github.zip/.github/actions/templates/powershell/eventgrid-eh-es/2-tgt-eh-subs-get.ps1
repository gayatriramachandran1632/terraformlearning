<#
    This script fetches Event Grid subscriptions and Event Hub role assignments from Azure, processes source files,
    and outputs the results for further use, such as in CI/CD pipelines like GitHub Actions.
#>

param (
    [string]$subscription_id = $env:TGT_SUB_ID,
    [string]$target_resource_group = $env:TGT_RG_NAME,
    [string]$target_system_topic = $env:TGT_SYS_TOPIC_NAME,
    [string]$source_folder_path = $env:SRC_FOLDER_PATH
)

# Step 2.1: Fetch Event Grid Subscriptions
Write-Output "Step 2.1: Fetching Event Grid subscriptions from Azure portal..."
Write-Output "Step 2.1: Resource Group Name: $target_resource_group"
Write-Output "Step 2.1: System Topic Name: $target_system_topic"

$max_retries = 3
$retry_delay = 3
$retry_count = 0
$event_subscriptions = @()

while ($retry_count -lt $max_retries) {
    Write-Output "Step 2.1: Fetching event subscriptions... (Attempt $($retry_count + 1)/$max_retries)"

    $raw_output = az eventgrid system-topic event-subscription list `
        --resource-group $target_resource_group `
        --system-topic-name $target_system_topic `
        --output json

    try {
        $event_subscriptions = $raw_output | ConvertFrom-Json
    } catch {
        Write-Output "Step 2.1: Failed to parse JSON output. Retrying..."
        $event_subscriptions = @()
    }

    if ($event_subscriptions.Count -gt 0) {
        $types = $event_subscriptions | Select-Object -ExpandProperty destination | Select-Object -ExpandProperty endpointType -Unique
        Write-Output "Step 2.1: Subscription endpoint types found: $($types -join ', ')"

        if ($types.Count -ge 2) {
            break
        }

        Write-Output "Step 2.1: Not all expected endpoint types found. Retrying in $retry_delay seconds..."
    } else {
        Write-Output "Step 2.1: No subscriptions returned. Retrying in $retry_delay seconds..."
    }

    Start-Sleep -Seconds $retry_delay
    $retry_count++
}

Write-Output "Step 2.1: Retrieved Event Grid subscriptions from Azure portal. $($event_subscriptions.Count) subscriptions found."

# Step 2.2: Process source Files from Folder
$container_name_from_path = $null
$eventhub_name_from_path = $null
$source_files = @()

if ($source_folder_path -match '[\\/](.+?)\.yaml$') {
    $container_name_from_path = [System.IO.Path]::GetFileNameWithoutExtension($source_folder_path)
    $eventhub_name_from_path = "$container_name_from_path-eh"
    Write-Output "Step 2.2: Container name from path: $container_name_from_path"
    Write-Output "Step 2.2: Folder path: $source_folder_path"

    if ($container_name_from_path) {
        if (Test-Path $source_folder_path) {
            $source_files = @(Get-Item $source_folder_path | ForEach-Object { $_.FullName })
        } else {
            Write-Output "Step 2.2: source file $container_name_from_path not found."
        }
    }
} else {
    if (Test-Path $source_folder_path) {
        $source_files = @(Get-ChildItem -Path $source_folder_path -Filter *.yaml | ForEach-Object { $_.FullName })
    } else {
        Write-Output "Step 2.2: Folder path $source_folder_path does not exist."
    }
}

# Step 2.3: Retrieve the name of Event Hub namespace
$eventhub_namespace_name = $null
foreach ($file in $source_files) {
    $source_content = Get-Content $file -Raw
    $parsed_source = ConvertFrom-Yaml $source_content
    if ($parsed_source.resource -and $parsed_source.resource.ehNamespace) {
        $eventhub_namespace_name = $parsed_source.resource.ehNamespace
        Write-Output "Step 2.3: Found ehNamespace $eventhub_namespace_name in file $file."
        break
    }
}
if (-not $eventhub_namespace_name) {
    Write-Error "Step 2.3: ERROR: 'ehNamespace' not found in any source file in the provided path."
    exit 1
}
"target-eventhub-namespace=$eventhub_namespace_name" >> $env:GITHUB_OUTPUT

Write-Output "`nStep 2.3: --- Contents of eventhub_namespace_name ---"
$eventhub_namespace_name | ConvertTo-Json -Depth 30
Write-Output "Step 2.3: --- End of eventhub_namespace_name ---`n"

# Step 2.4: Filter Event Grid Subscriptions
$event_subscriptions_from_target = @()

if ($container_name_from_path) {
    Write-Output "Step 2.4: Fetching event subscriptions for container: $container_name_from_path"
    foreach ($subscription in $event_subscriptions) {
        if ($subscription.name -eq "StorageAntimalwareSubscription") { continue }
        Write-Output "Step 2.4: Processing subscription: $($subscription.name)"
        $destination = $subscription.destination
        $subject_path = $subscription.filter?.subjectBeginsWith
        if ($destination.resourceId -match "/eventhubs/([^/]+)$") {
            $eventhub_name = $matches[1]
            Write-Output "Step 2.4: Event Hub Name: $eventhub_name"
        }
        if ($destination.endpointType -eq "EventHub" -and $subject_path -match "/blobServices/default/containers/([^/]+)" -and $matches[1] -eq $container_name_from_path) {
            $event_subscriptions_from_target += [PSCustomObject]@{
                Name = $subscription.name
                EventHubName = $eventhub_name
                SubjectBeginsWith = $subject_path
            }
        }
    }
} else {
    Write-Output "Step 2.4: No container name found in path. Fetching all subscriptions."
    foreach ($subscription in $event_subscriptions) {
        Write-Output "Step 2.4: Processing subscription: $($subscription.name)"
        $destination = $subscription.destination
        $filter = $subscription.filter
        if ($destination.endpointType -eq "eventhub") {
            $event_subscriptions_from_target += [PSCustomObject]@{
                Name = $subscription.name
                EndpointType = $destination.endpointType
                SubjectBeginsWith = $filter.subjectBeginsWith
            }
        }
    }
}

# Step 2.5: Output Results to File
$event_subs_target_path = Join-Path -Path $PSScriptRoot -ChildPath "target-event-subs.json"
$event_subscriptions_from_target | ConvertTo-Json -Depth 30 | Out-File -FilePath $event_subs_target_path
"target-event-subs=$event_subs_target_path" >> $env:GITHUB_OUTPUT

$source_files_path = Join-Path -Path $PSScriptRoot -ChildPath "source-files.json"
$source_files | ConvertTo-Json -Depth 30 | Out-File -FilePath $source_files_path
"source-files=$source_files_path" >> $env:GITHUB_OUTPUT

Write-Output "`nStep 2.5: --- Contents of eventsubscriptionsfromtarget ---"
$event_subscriptions_from_target | ConvertTo-Json -Depth 30
Write-Output "Step 2.5: --- End of eventsubscriptionsfromtarget ---`n"

Write-Output "`nStep 2.5: --- Contents of source_files ---"
$source_files | ConvertTo-Json -Depth 30
Write-Output "Step 2.5: --- End of source_files ---`n"

# Step 2.6: Fetch Event Hub Role Assignments
$eventhubs_from_target = @()

if (-not $eventhub_name_from_path) {
    Write-Output "Step 2.6: Fetching all event hubs in the namespace."
    $eventhubs_raw = az eventhubs eventhub list --namespace-name $eventhub_namespace_name --resource-group $target_resource_group
    $eventhubs = $eventhubs_raw | ConvertFrom-Json
    foreach ($eventhub in $eventhubs) {
        $eventhub_name = $eventhub.name
        $eventhub_check = az eventhubs eventhub show --namespace-name $eventhub_namespace_name --resource-group $target_resource_group --name $eventhub_name
        if ($eventhub_check) {
            $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.EventHub/namespaces/$eventhub_namespace_name/eventhubs/$eventhub_name"
            $role_assignments = az role assignment list --scope $scope --query "[?roleDefinitionName=='Azure Event Hubs Data Receiver']" | ConvertFrom-Json
            foreach ($assignment in $role_assignments) {
                if ($assignment.Scope -eq $scope) {
                    $eventhubs_from_target += [PSCustomObject]@{
                        EventHubName = $eventhub_name
                        PrincipalId = $assignment.principalId
                        RoleDefinitionIdOrName = $assignment.RoleDefinitionName
                        DisplayName = $assignment.DisplayName
                        Scope = $assignment.Scope
                    }
                }
            }
        }
    }
} else {
    Write-Output "Step 2.6: Checking role assignments for event hub: $eventhub_name_from_path"
    $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.EventHub/namespaces/$eventhub_namespace_name/eventhubs/$eventhub_name_from_path"
    $role_assignments = az role assignment list --scope $scope --query "[?roleDefinitionName=='Azure Event Hubs Data Receiver']" --Output json | ConvertFrom-Json
    foreach ($assignment in $role_assignments) {
        if ($assignment.Scope -eq $scope) {
            $eventhubs_from_target += [PSCustomObject]@{
                EventHubName = $eventhub_name_from_path
                PrincipalId = $assignment.principalId
                RoleDefinitionIdOrName = $assignment.RoleDefinitionName
                DisplayName = $assignment.DisplayName
                Scope = $assignment.Scope
            }
        }
    }
}

Write-Output "Step 2.6: Target state fetched successfully."

# Step 2.7: Final Output
$eventhubs_from_target_path = Join-Path -Path $PSScriptRoot -ChildPath "target-event-hubs.json"
$eventhubs_from_target | ConvertTo-Json -Depth 5 | Out-File -FilePath $eventhubs_from_target_path
"target-event-hubs=$eventhubs_from_target_path" >> $env:GITHUB_OUTPUT

Write-Output "`nStep 2.7: --- Contents of eventhubsfromtarget ---"
$eventhubs_from_target | ConvertTo-Json -Depth 10
Write-Output "Step 2.7: --- End of eventhubsfromtarget ---`n"
