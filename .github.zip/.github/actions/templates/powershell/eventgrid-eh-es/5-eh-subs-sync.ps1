param(
    [string]$subscription_id = $env:TGT_SUB_ID,
    [string]$target_resource_group = $env:TGT_RG_NAME,
    [string]$target_eventhub_namespace = $env:TGT_EH_NAME,
    [string]$target_system_topic = $env:TGT_SYS_TOPIC_NAME,
    [string]$to_add_eventhubs_path = $env:TO_ADD_EVENT_HUBS,
    [string]$to_add_subs_path = $env:TO_ADD_EVENT_SUBS,
    [string]$to_add_assignments_only_path = $env:TO_ADD_ASSNMTS_ONLY,
    [string]$to_remove_assignments_only_path = $env:TO_REMOVE_ASSNMTS_ONLY,
    [string]$to_remove_eventhubs_path = $env:TO_REMOVE_EVENT_HUBS,
    [string]$to_delete_subs_path = $env:TO_REMOVE_EVENT_SUBS
)

Write-Output "To Add eventhubs - $($to_add_eventhubs_path)"
Write-Output "Step 5: Starting Step 5: Add new containers & role assignments (from source state)"

$to_remove_assignments_only = @()
$to_remove_eventhubs = @()

# -----------------------------------
# Step 5.1: Load Data to Remove
# -----------------------------------

if (Test-Path $to_remove_assignments_only_path) {
    $to_remove_assignments_only = Get-Content -Path $to_remove_assignments_only_path | ConvertFrom-Json
    Write-Output "Loaded role assignments to remove: $($to_remove_assignments_only.Count)"
} else {
    Write-Output "No outdated role assignments to remove."
}

if (Test-Path $to_remove_eventhubs_path) {
    $to_remove_eventhubs = Get-Content -Path $to_remove_eventhubs_path | ConvertFrom-Json
    Write-Output "Loaded Event Hubs to remove: $($to_remove_eventhubs.Count)"
} else {
    Write-Output "No Event Hubs to remove."
}

# -----------------------------------
# Step 5.2: Removal Process (Role Assignments and Event Hubs)
# -----------------------------------

Write-Output "Step 5.2: Removing outdated containers and role assignments."

foreach ($remove_assignment in $to_remove_assignments_only) {
    Write-Output "Step 5.2: Removing outdated role assignment for Event Hub: $($remove_assignment.EventHubName), PrincipalId: $($remove_assignment.PrincipalId)"
    az role assignment delete --scope $remove_assignment.Scope --assignee $remove_assignment.PrincipalId --role $remove_assignment.RoleDefinitionIdOrName
    Write-Output "Step 5.2: Removing role assignment for Event Hub: $($remove_assignment.EventHubName), PrincipalId: $($remove_assignment.PrincipalId)"
}

if ($null -ne $to_remove_eventhubs) {
    foreach ($eventhub_name in $to_remove_eventhubs) {
        Write-Output "Step 5.2: Removing role assignments for Event Hub: $eventhub_name"

        $role_assignments = az role assignment list `
            --scope "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.EventHub/namespaces/$target_eventhub_namespace/eventhubs/$eventhub_name" `
            --query "[?roleDefinitionName=='Azure Event Hubs Data Receiver']" |
            ConvertFrom-Json

        if ($role_assignments.Count -gt 0) {
            foreach ($assignment in $role_assignments) {
                $role_id = $assignment.id
                az role assignment delete --ids $role_id
                Write-Output "Step 5.2: Removed role assignment for Event Hub: $eventhub_name, Role Assignment ID: $role_id"
            }
        } else {
            Write-Output "Step 5.2: No 'Azure Event Hubs Data Receiver' role assignments found for Event Hub: $eventhub_name."
        }

        Write-Output "Step 5.2: Removing Event Hub: $eventhub_name"
        az eventhubs eventhub delete --name $eventhub_name --namespace-name $target_eventhub_namespace --resource-group $target_resource_group
        Write-Output "Step 5.2: Completed the removal of Event Hub: $eventhub_name."
    }
} else {
    Write-Output "Step 5.2: Nothing to remove"
}

Write-Output "Step 5.2 Removal Completed."

# -----------------------------------
# Step 5.3: Addition of New Event Hubs and Role Assignments
# -----------------------------------

Write-Output "`nStep 5.3: Creating new eventhubs and assigning role assignments"

$eventhubs_to_create = @()
$roles_to_add_for_existing = @()

if (Test-Path $to_add_eventhubs_path) {
    $eventhubs_to_create = Get-Content $to_add_eventhubs_path | ConvertFrom-Json
    Write-Output "Loaded Event Hubs to create: $($eventhubs_to_create.Count)"
} else {
    Write-Output "No new Event Hubs to create."
}

if (Test-Path $to_add_assignments_only_path) {
    $roles_to_add_for_existing = Get-Content $to_add_assignments_only_path | ConvertFrom-Json
    Write-Output "Loaded role assignments for existing Event Hubs: $($roles_to_add_for_existing.Count)"
} else {
    Write-Output "No role assignments to add for existing Event Hubs."
}

foreach ($entry in $eventhubs_to_create) {
    Write-Output "Step 5.3: Creating Event Hub '$($entry.EventHubName)'..."
    $eventhub_name = $entry.EventHubName
    $principal_id = $entry.PrincipalId
    $role = $entry.RoleDefinitionIdOrName

    az eventhubs eventhub create `
        --name $eventhub_name `
        --namespace-name $target_eventhub_namespace `
        --resource-group $target_resource_group

    if ($LASTEXITCODE -eq 0) {
        Write-Output "Step 5.3: Created Event Hub '$eventhub_name'"

        $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.EventHub/namespaces/$target_eventhub_namespace/eventhubs/$eventhub_name"

        Write-Output "Step 5.3: Assigning role '$role' to principal '$principal_id' on '$eventhub_name'"
        az role assignment create `
            --assignee-object-id $principal_id `
            --role $role `
            --scope $scope `
            --assignee-principal-type ServicePrincipal
        Write-Output "Step 5.3: Completed role assignment for Event Hub '$eventhub_name'."
    } else {
        Write-Output "Step 5.3: Failed to create Event Hub '$eventhub_name'"
    }
}

# -----------------------------------
# Step 5.4: Assign Roles for Existing Event Hubs
# -----------------------------------

foreach ($entry in $roles_to_add_for_existing) {
    Write-Output "Step 5.4: Assigning role '$($entry.RoleDefinitionIdOrName)' to principal '$($entry.PrincipalId)' on existing Event Hub '$($entry.EventHubName)'..."
    $eventhub_name = $entry.EventHubName
    $principal_id = $entry.PrincipalId
    $role = $entry.RoleDefinitionIdOrName

    $scope = "/subscriptions/$subscription_id/resourceGroups/$target_resource_group/providers/Microsoft.EventHub/namespaces/$target_eventhub_namespace/eventhubs/$eventhub_name"

    az role assignment create `
        --assignee-object-id $principal_id `
        --role $role `
        --scope $scope `
        --assignee-principal-type ServicePrincipal

    Write-Output "Step 5.4: Completed role assignment for Event Hub '$eventhub_name'."
}

# -----------------------------------
# Step 5.5: Event Subscription Creation
# -----------------------------------

Write-Output "`nStep 5.5: Creating or updating subscriptions..."

$to_add_subs = Get-Content -Path $to_add_subs_path | ConvertFrom-Json
$to_delete_subs = Get-Content -Path $to_delete_subs_path | ConvertFrom-Json

function Get-EventHubId($namespace, $eventhub_name, $resource_group) {
    $eh = az eventhubs eventhub show `
        --resource-group $resource_group `
        --namespace-name $namespace `
        --name $eventhub_name `
        --query id `
        --output tsv
    return $eh
}

foreach ($entry in $to_add_subs) {
    Write-Output "Step 5.5: Creating new subscription for Event Hub '$($entry.EventHubName)' with Subscription Name '$($entry.Name)'"

    $eventhub_id = Get-EventHubId -namespace $target_eventhub_namespace -eventhub_name $entry.EventHubName -resource_group $target_resource_group

    if (-not $eventhub_id) {
        Write-Output "Step 5.5: Failed to retrieve Event Hub ID for: $($entry.EventHubName)"
        continue
    }

    az eventgrid system-topic event-subscription create `
        --name $entry.Name `
        --resource-group $target_resource_group `
        --system-topic-name $target_system_topic `
        --endpoint $eventhub_id `
        --endpoint-type eventhub `
        --included-event-types Microsoft.Storage.BlobCreated Microsoft.Storage.BlobDeleted `
        --subject-begins-with $entry.SubjectBeginsWith

    if ($LASTEXITCODE -eq 0) {
        Write-Output "Step 5.5: Created Subscription '$($entry.Name)'"
    } else {
        Write-Output "Step 5.5: Failed to create Subscription '$($entry.Name)'"
    }
}

# -----------------------------------
# Step 5.6: Delete Subscriptions
# -----------------------------------

Write-Output "`nStep 5.6: Deleting outdated subscriptions..."

foreach ($entry in $to_delete_subs) {
    Write-Output "Step 5.6: Deleting subscription '$($entry.Name)'..."

    az eventgrid system-topic event-subscription delete `
        --name $entry.Name `
        --resource-group $target_resource_group `
        --system-topic-name $target_system_topic `
        --yes

    if ($LASTEXITCODE -eq 0) {
        Write-Output "Step 5.6: Deleted Subscription '$($entry.Name)'"
    } else {
        Write-Output "Step 5.6: Failed to delete Subscription '$($entry.Name)'"
    }
}

Write-Output "Step 5.7 Process Completed"
