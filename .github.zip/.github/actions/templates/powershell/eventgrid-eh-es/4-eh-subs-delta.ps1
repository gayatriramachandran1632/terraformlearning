<#
    Description:
    Compares Event Hubs and Event Subscriptions between Azure target state and source configuration.
    Outputs JSON files listing what to add, update, or remove.
#>

param(
    [string]$event_hubs_from_target = $env:TGT_EH_STATE,
    [string]$event_hubs_from_source = $env:SRC_EH_STATE,
    [string]$event_subs_from_target = $env:TGT_ES_STATE,
    [string]$event_subs_from_source = $env:SRC_ES_STATE
)

Write-Output "Step 4.1: Starting comparison of target and source states..."

# Load JSON data
$target_eventhubs = Get-Content -Path $event_hubs_from_target | ConvertFrom-Json
$source_eventhubs = Get-Content -Path $event_hubs_from_source | ConvertFrom-Json
$target_eventsubs = Get-Content -Path $event_subs_from_target | ConvertFrom-Json
$source_eventsubs = Get-Content -Path $event_subs_from_source | ConvertFrom-Json

Write-Output "Step 4.2: target EventHubs count: $($target_eventhubs.Count)"
Write-Output "Step 4.2: source EventHubs count: $($source_eventhubs.Count)"
Write-Output "Step 4.2: target EventSubscriptions count: $($target_eventsubs.Count)"
Write-Output "Step 4.2: source EventSubscriptions count: $($source_eventsubs.Count)"

# Step 4.3: Determine Role Assignments and Event Hubs to Remove
$to_remove_assignments_only = @()
$to_remove_eventhubs = @()
$unique_eventhubs = @()

foreach ($target_assignment in $target_eventhubs) {
    $source_eventhub = $source_eventhubs | Where-Object { $_.EventHubName -eq $target_assignment.EventHubName }

    if ($source_eventhub) {
        $source_role_assignments = $source_eventhub | Where-Object {
            $_.PrincipalId -eq $target_assignment.PrincipalId -and
            $_.RoleDefinitionIdOrName -eq $target_assignment.RoleDefinitionIdOrName
        }

        if (-not $source_role_assignments) {
            Write-Output "Step 4.3: Marking outdated role assignment for removal - EventHub: $($target_assignment.EventHubName), PrincipalId: $($target_assignment.PrincipalId)"
            $to_remove_assignments_only += $target_assignment
        }
    } else {
        Write-Output "Step 4.3: Marking role assignments and EventHub for removal - EventHub: $($target_assignment.EventHubName), PrincipalId: $($target_assignment.PrincipalId)"
        $to_remove_assignments_only += $target_assignment
        $unique_eventhubs += $target_assignment.EventHubName
        $to_remove_eventhubs = $unique_eventhubs | Sort-Object -Unique
    }
}

# Save removal output files
$remove_assignments_path = Join-Path -Path $PSScriptRoot -ChildPath "to-remove-assignments-only.json"
$remove_eventhubs_path = Join-Path -Path $PSScriptRoot -ChildPath "to-remove-event-hubs.json"
$to_remove_assignments_only | ConvertTo-Json -Depth 5 | Out-File -FilePath $remove_assignments_path
$to_remove_eventhubs | ConvertTo-Json | Out-File -FilePath $remove_eventhubs_path

# Output to GitHub Action
"to-remove-assignments-only=$remove_assignments_path" >> $env:GITHUB_OUTPUT
"to-remove-event-hubs=$remove_eventhubs_path" >> $env:GITHUB_OUTPUT

Write-Output "Step 4.4: Removal lists saved."

# Step 4.5: Prepare lists for additions (Event Hubs and Role Assignments)
$eventhubs_to_create = @()
$roles_to_add_for_existing_eventhubs = @()

Write-Output "Step 4.5: Preparing deployment plan..."

foreach ($entry in $source_eventhubs) {
    $eventhub_exists = $target_eventhubs | Where-Object { $_.EventHubName -eq $entry.EventHubName }

    if (-not $eventhub_exists) {
        # Event Hub not present in target � create with role assignment
        $eventhubs_to_create += [PSCustomObject]@{
            EventHubName = $entry.EventHubName
            PrincipalId = $entry.PrincipalId
            RoleDefinitionIdOrName = $entry.RoleDefinitionIdOrName
        }
    } else {
        # Event Hub exists � check role assignment
        $role_exists = $eventhub_exists | Where-Object {
            $_.PrincipalId -eq $entry.PrincipalId -and
            $_.RoleDefinitionIdOrName -eq $entry.RoleDefinitionIdOrName
        }
        if (-not $role_exists) {
            $roles_to_add_for_existing_eventhubs += [PSCustomObject]@{
                EventHubName = $entry.EventHubName
                PrincipalId = $entry.PrincipalId
                RoleDefinitionIdOrName = $entry.RoleDefinitionIdOrName
            }
        }
    }
}

# Save addition output files
$add_eventhubs_path = Join-Path -Path $PSScriptRoot -ChildPath "to-add-event-hubs.json"
$add_assignments_path = Join-Path -Path $PSScriptRoot -ChildPath "to-add-assignments-only.json"
$eventhubs_to_create | ConvertTo-Json -Depth 5 | Out-File -FilePath $add_eventhubs_path
$roles_to_add_for_existing_eventhubs | ConvertTo-Json -Depth 5 | Out-File -FilePath $add_assignments_path

# Output to GitHub Action
"to-add-event-hubs=$add_eventhubs_path" >> $env:GITHUB_OUTPUT
"to-add-assignments-only=$add_assignments_path" >> $env:GITHUB_OUTPUT

Write-Output "Step 4.6: Additions lists saved."

# Step 4.7: Compare Event Subscriptions - Additions and Deletions
$to_add_subscriptions = @()
$to_delete_subscriptions = @()

Write-Output "Step 4.7: Comparing source and target subscriptions..."

foreach ($source_entry in $source_eventsubs) {
    $existing_subscription = $target_eventsubs | Where-Object { $_.Name -eq $source_entry.Name }
    $subject_begins_with = "/blobServices/default/containers/$($source_entry.SubjectBeginsWith)"

    if (-not $existing_subscription) {
        $to_add_subscriptions += [PSCustomObject]@{
            Name = $source_entry.Name
            EventHubName = $source_entry.EventHubName
            SubjectBeginsWith = $subject_begins_with
        }
    }
}

# Step 4.8: Detect Subscriptions to Delete (except StorageAntimalwareSubscription)
foreach ($target_entry in $target_eventsubs) {
    if ($target_entry.Name -eq "StorageAntimalwareSubscription") { continue }

    $exists_in_source = $source_eventsubs | Where-Object { $_.Name -eq $target_entry.Name }
    if (-not $exists_in_source) {
        $to_delete_subscriptions += $target_entry
    }
}

# Save subscription outputs
$to_add_path = Join-Path -Path $PSScriptRoot -ChildPath "to-add-event-subs.json"
$to_delete_path = Join-Path -Path $PSScriptRoot -ChildPath "to-remove-event-subs.json"

$to_add_subscriptions | ConvertTo-Json -Depth 5 | Out-File -FilePath $to_add_path
$to_delete_subscriptions | ConvertTo-Json -Depth 5 | Out-File -FilePath $to_delete_path

"to-add-event-subs=$to_add_path" >> $env:GITHUB_OUTPUT
"to-remove-event-subs=$to_delete_path" >> $env:GITHUB_OUTPUT

# Print final outputs for debugging
Write-Output "`nStep 4.9: --- Contents of to-add-event-subs ---"
$to_add_subscriptions | ConvertTo-Json -Depth 10
Write-Output "`nStep 4.10: --- Contents of to-remove-event-subs ---"
$to_delete_subscriptions | ConvertTo-Json -Depth 10
