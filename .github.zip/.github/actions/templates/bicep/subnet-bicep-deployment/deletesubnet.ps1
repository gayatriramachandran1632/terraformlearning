# Variables - set these to your environment

$resourceGroup = "pxs-azure-connectivity-dev-rg"
$vnetName = "pxs-entfta-dev-gwc-vnet1"
$subnetName = "pxs-azure-entfta-privendpoint-dev-gwc-snet"
$nsgName = "pxs-azure-entfta-privendpoint-dev-gwc-nsg"


# $LockName = "CanNotDelete"

# # Remove the lock
# Remove-AzResourceLock -ResourceGroupName $resourceGroup -LockName $LockName -Force
$vnet = Get-AzVirtualNetwork -ResourceGroupName $resourceGroup  -Name $vnetName

# Remove NSG from the subnet
Set-AzVirtualNetworkSubnetConfig `
  -VirtualNetwork $vnet `
  -Name $subnetName `
  -NetworkSecurityGroup $null `
  -RouteTable $null `
  -AddressPrefix "10.27.128.32/28"

# Apply the change
$vnet | Set-AzVirtualNetwork
Remove-AzVirtualNetworkSubnetConfig -Name $subnetName  -VirtualNetwork $vnetName
Remove-AzNetworkSecurityGroup -Name $nsgName -ResourceGroupName $resourceGroup
