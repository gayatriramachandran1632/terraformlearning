 ####################################### Initialisation ###########################################

 ## Set up environment
 Install-Module -Name Az -Scope CurrentUser -Repository PSGallery -Force
 Install-Module -Name Az.Purview -Scope CurrentUser -Repository PSGallery -Force
 
 ## Logging to the Azure Portal
 $clientSecret = ConvertTo-SecureString -AsPlainText $env:ARM_CLIENT_SECRET -Force
 $credential = New-Object System.Management.Automation.PSCredential ($env:ARM_CLIENT_ID, $clientSecret)
 Login-AzAccount -ServicePrincipal -TenantId $env:ARM_TENANT_ID -Credential $credential -Subscription $env:ARM_SUBSCRIPTION_ID

####################################### Token generation (REST API) ###########################################

#$tokenUrl = "https://login.microsoftonline.com/$env:ARM_TENANT_ID/oauth2/token"
#$tokenBody = @{
    #client_id = $env:ARM_CLIENT_ID
    #client_secret = $env:ARM_CLIENT_SECRET
    #grant_type = "client_credentials"
    #resource = "https://purview.azure.net"
#}
#$tokenresponse = Invoke-RestMethod -Method 'Post' -Uri $tokenUrl -Credential $credential -Body $tokenBody

# Retrieving the access token from Response JSON
#$accesstoken = $tokenresponse.access_token

$token = GetAzAccessToken
$accesstoken = $token.Token

####################################### Registration of Data Source  ###########################################

$Datasource_list = Import-Csv -Delimiter ',' -path  ./Purview/Sources/DataSourceList_dev.csv

foreach ($Datasource in $Datasource_list)
{
$DataSourceurl = "https://$env:pviewname.purview.azure.com/scan/Datasources/$($Datasource.DataSourceName)?api-version=2022-02-01-preview"
$DataSourceheaders = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$DataSourceheaders.Add("Authorization","Bearer $accesstoken")
$DataSourceBody = @"
{
  "kind": "$($Datasource.Kind)",
  "properties": {
    "endpoint": "$($Datasource.Endpoint)",
    "collection": {
      "referenceName": "$($Datasource.ReferenceCollectionName)",
      "type": "CollectionReference"
    }
  }
}
"@
try{
 $response = Invoke-RestMethod -Method 'Put' -Uri $DataSourceurl  -Body $DataSourceBody -ContentType 'application/json' -Headers $DataSourceheaders
}
catch{
 Write-Output "Datasource has been created" $($Datasource.ReferenceCollectionName) "---" $($Datasource.DataSourceName)
}
}
