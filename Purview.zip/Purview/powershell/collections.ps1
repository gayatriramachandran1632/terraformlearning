Set-StrictMode -Version 3.0

####################################### Initialisation ###########################################
## Set up environment
 Install-Module -Name Az -Scope CurrentUser -Repository PSGallery -Force
 Install-Module -Name Az.Purview -Scope CurrentUser -Repository PSGallery -Force
 
 ## Logging to the Azure Portal
 $clientSecret = ConvertTo-SecureString -AsPlainText $env:ARM_CLIENT_SECRET -Force
 $credential = New-Object System.Management.Automation.PSCredential ($env:ARM_CLIENT_ID, $clientSecret)
 Login-AzAccount -ServicePrincipal -TenantId $env:ARM_TENANT_ID -Credential $credential -Subscription $env:ARM_SUBSCRIPTION_ID
 
####################################### Token generation (REST API) ###########################################
  
#$tokenUrl = "https://login.microsoftonline.com/$env:ARM_TENANT_ID/oauth2/token"
#$tokenBody = @{
    #client_id = $env:ARM_CLIENT_ID
    #client_secret = $env:ARM_CLIENT_SECRET
    #grant_type = "client_credentials"
    #resource = "https://purview.azure.net"
#}
#$tokenresponse = Invoke-RestMethod -Method 'Post' -Uri $tokenUrl -Credential $credential -Body $tokenBody

# Retrieving the access token from Response JSON
#$accesstoken = $tokenresponse.access_token

$token = GetAzAccessToken
$accesstoken = $token.Token
 
####################################### Automated Collections ###########################################

 $collection_list = Import-Csv -Delimiter ';' -path  ./Purview/Sources/Collection_Hierarchy.csv 
 write-output $collection_list[0]
 
foreach ($collection in $collection_list)
{
    write-output "Collection  :" $collection
    write-output "Collection Child :" $($collection.ChildCollectionFName)
    $collectionUrl = "https://$env:pviewname.purview.azure.com/collections/$($collection.ChildCollectionAName)?api-version=2019-11-01-preview"
    $collectionheaders = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $collectionheaders.Add("Authorization","Bearer $accesstoken")
 
    $collectionBody = @"
    {
        "parentCollection": {
        "type": "CollectionReference",
        "referenceName": "$($collection.ParentCollectionAName)"
    },
    "friendlyName": "$($collection.ChildCollectionFName)"
    }
    
"@


write-output "-----------------------------------------------------------------------------"
 Invoke-RestMethod -Method 'Put' -Uri $collectionUrl  -Body $collectionBody -ContentType 'application/json' -Headers $collectionheaders
 
}
 