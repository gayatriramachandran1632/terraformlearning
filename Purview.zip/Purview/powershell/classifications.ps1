####################################### Initialisation ###########################################

## Set up environment
 Install-Module -Name Az -Scope CurrentUser -Repository PSGallery -Force
 Install-Module -Name Az.Purview -Scope CurrentUser -Repository PSGallery -Force
 
 ## Logging to the Azure Portal
 $clientSecret = ConvertTo-SecureString -AsPlainText $env:ARM_CLIENT_SECRET -Force
 $credential = New-Object System.Management.Automation.PSCredential ($env:ARM_CLIENT_ID, $clientSecret)
 Login-AzAccount -ServicePrincipal -TenantId $env:ARM_TENANT_ID -Credential $credential -Subscription $env:ARM_SUBSCRIPTION_ID


####################################### Token generation (REST API) ###########################################
 
#$tokenUrl = "https://login.microsoftonline.com/$env:ARM_TENANT_ID/oauth2/token"
#$tokenBody = @{
    #client_id = $env:ARM_CLIENT_ID
    #client_secret = $env:ARM_CLIENT_SECRET
    #grant_type = "client_credentials"
    #resource = "https://purview.azure.net"
#}
#$tokenresponse = Invoke-RestMethod -Method 'Post' -Uri $tokenUrl -Credential $credential -Body $tokenBody

# Retrieving the access token from Response JSON
#$accesstoken = $tokenresponse.access_token

$token = GetAzAccessToken
$accesstoken = $token.Token

####################################### Automated Classifications ###########################################

$classification_list = Import-Csv -Delimiter ',' -path  ./Purview/Sources/Classifications.csv

foreach ($classification in $classification_list)
{

$Classificationurl = "https://$env:pviewname.purview.azure.com/catalog/api/atlas/v2/types/typedefs"
$classificationheaders = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$classificationheaders.Add("Authorization","Bearer $accesstoken")
$classificationBody = @"
{
	"classificationDefs": [
		{
			"name": "$($classification.Name)",
			"description": "$($classification.Description)"
		}
	]
}
"@
$uri = "https://$env:pviewname.purview.azure.com/catalog/api/atlas/v2/types/classificationdef/name/$($classification.Name)"
try {
	$response = Invoke-RestMethod -Method 'GET' -Uri $uri -ContentType 'application/json' -Headers $classificationheaders
	Write-Host ("Classification $($classification.Name) already exists")
}
catch {
	$response = $null
	Write-Host("Classification $($classification.Name) does not exist")
}

if ([string]::IsNullOrEmpty($response))
{
	Write-Host ("Creating classification $($classification.Name)")
	Invoke-RestMethod -Method 'Post' -Uri $Classificationurl  -Body $classificationBody -ContentType 'application/json' -Headers $classificationheaders
} 
}


