 ####################################### Initialisation ###########################################

 ## Set up environment
 Install-Module -Name Az -Scope CurrentUser -Repository PSGallery -Force
 Install-Module -Name Az.Purview -Scope CurrentUser -Repository PSGallery -Force
 
 ## Logging to the Azure Portal
 $clientSecret = ConvertTo-SecureString -AsPlainText $env:ARM_CLIENT_SECRET -Force
 $credential = New-Object System.Management.Automation.PSCredential ($env:ARM_CLIENT_ID, $clientSecret)
 Login-AzAccount -ServicePrincipal -TenantId $env:ARM_TENANT_ID -Credential $credential -Subscription $env:ARM_SUBSCRIPTION_ID
 
####################################### Token generation (REST API) ###########################################

#$tokenUrl = "https://login.microsoftonline.com/$env:ARM_TENANT_ID/oauth2/token"
#$tokenBody = @{
    #client_id = $env:ARM_CLIENT_ID
    #client_secret = $env:ARM_CLIENT_SECRET
    #grant_type = "client_credentials"
    #resource = "https://purview.azure.net"
#}
#$tokenresponse = Invoke-RestMethod -Method 'Post' -Uri $tokenUrl -Credential $credential -Body $tokenBody

# Retrieving the access token from Response JSON
#$accesstoken = $tokenresponse.access_token

$token = GetAzAccessToken
$accesstoken = $token.Token

####################################### Creating Scan Instance ###########################################

$Datascan_list = Import-Csv -Delimiter ',' -path  ./Purview/Sources/Scan_List.csv

foreach ($Datascan in $Datascan_list)
{

$ScanInstanceUrl = "https://$env:pviewname.purview.azure.com/scan/Datasources/$($Datascan.DataSourceName)/scans/$($Datascan.ScanName)?api-version=2022-02-01-preview"

#Write-Host $DataSourceurl
$ScanSourceheaders = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$ScanSourceheaders.Add("Authorization","Bearer $accesstoken")
$ScanInstanceBody = @"
{
  "kind": "$($Datascan.DataSourceKind)",
  "properties": {
    "scanRulesetName": "$($Datascan.scanRulesetName)",
    "scanRulesetType": "$($Datascan.scanRulesetType)",
    "collection": {
      "referenceName": "$($Datascan.CollectionreferenceName)",
      "type": "CollectionReference"
    }
  }
}
"@

Invoke-RestMethod -Method 'Put' -Uri $ScanInstanceUrl  -Body $ScanInstanceBody -ContentType 'application/json' -Headers $ScanSourceheaders

####################################### Executing the scan ###########################################


$ScanUrl = "https://$env:pviewname.purview.azure.com/scan/Datasources/$($Datascan.DataSourceName)/scans/$($Datascan.ScanName)/run?api-version=2018-12-01-preview"
#Write-Host $ScanUrl
#$date = (Get-Date).AddSeconds(30).ToString("yyyy-MM-ddTHH:mm:ss")
#Write-Host $date

$Scanheaders = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$Scanheaders.Add("Authorization","Bearer $accesstoken")
$ScanBody = @"
{
    "scanLevel": "Full"
}
"@
#Write-Host $ScanBody

Invoke-RestMethod -Method 'Post' -Uri $ScanUrl  -Body $ScanBody -ContentType 'application/json' -Headers $Scanheaders

}

